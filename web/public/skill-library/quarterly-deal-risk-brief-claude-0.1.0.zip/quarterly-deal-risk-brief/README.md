# Quarterly deal risk brief

Produces a weekly brief for sales managers ranking their team's open deals closing this quarter by risk of going quiet or missing a decision-maker, with dated Backstory evidence and ready-made 1:1 questions per rep.

It answers one question:

> Which of my team's open deals closing this quarter have gone quiet or lack an engaged decision-maker, and what should I ask each rep about them in our 1:1?

Version 0.1.0.

## Install

- **Claude app:** Customize > Plugins > Add > Upload plugin, and choose this ZIP.
- **Claude Code:** a plugin uploaded to your Claude account syncs to Claude Code as `quarterly-deal-risk-brief@synced`. To try it for one session from an unzipped copy instead: `claude --plugin-dir ./quarterly-deal-risk-brief`.

## What you need

1. **The Backstory connector** in Claude (required): connect it under Customize > Connectors. The plugin doesn't bundle it.
2. The **Backstory connector**, authorized for the sales manager's own tenant.
3. **CRM fields synced into Backstory** for close date, stage, and deal owner (standard fields work out of the box; custom labels can be set in settings.fields).
4. **Manager-level visibility** in Backstory so the team's open deals, not only the user's own, are returned.
5. An optional **calendar or email connector**, used only if already connected, never required to run.
6. **Code execution turned on** in Claude's settings. Claude runs a small script that checks the data and builds the page from the fixed design.

## Running it

Ask Claude something like "Run the quarterly deal risk brief for my team now". It uses the settings in `skills/quarterly-deal-risk-brief/settings.json`.

The first run creates the page and gives you its link. Include the link when you ask for the next run so it updates the same page; the scheduled refresh carries it automatically.

## Scheduled refresh

The plugin is meant to run every week (Monday, 08:00). After the first good run, Claude offers to set this up and creates the scheduled task only if you say yes.

- The task runs under the account of whoever creates it, with their Backstory access.
- A task scheduled on a computer runs only while that computer is on and Claude is open.
- A scheduled run never creates a second page. If it can't finish, it leaves the last brief in place and says what stopped it.
- Use "Run now" on the task once to check it picks up the plugin before relying on the schedule.

If Claude can't schedule it where you're working, create a scheduled task yourself with this prompt:

```
Run the scheduled weekly run of the quarterly deal risk brief plugin. Update the output in place at <brief link>. Ask no questions. If anything blocks the run, publish nothing and report what blocked it.
```

## Before you rely on it

Six levels, in order; each is a gate. Don't start a level until the one before has passed, and re-run from the lowest level a change touches.

1. **Package and build** (done by the skill builder before download)
   - Each script's tests passed in Python; re-run them after any change with the commands under Testing.
   - The page kit builds the sample page from its fixed, fingerprinted template.
2. **Real tool output** (you, on saved samples)
   - Save one real fetch_records result and one activity call, with customer names and emails removed.
   - Run population.py on the saved records and check it keeps the records you expect: Backstory returns dates as display text ("Nov 28, 2026").
   - A fetch where nothing survives must stop the run, never publish an empty result.
3. **Canaries in your tenant** (whoever has access to the tenant, before any run on real data)
   - CloseDate / Close Date (key): mapped and Ready in Backstory, known to record search by that exact name, and returned with values on a small fetch.
   - StageName / Stage (key): mapped and Ready in Backstory, known to record search by that exact name, and returned with values on a small fetch.
   - OwnerName / Opportunity Owner / Owner (key): mapped and Ready in Backstory, known to record search by that exact name, and returned with values on a small fetch.
   - Amount: mapped and Ready in Backstory, known to record search by that exact name, and returned with values on a small fetch.
   - Type / Opportunity Type: mapped and Ready in Backstory, known to record search by that exact name, and returned with values on a small fetch.
   - `preview_records`, `fetch_records`, `get_opportunity_status`, `get_recent_opportunity_activity`, `get_opportunity_engaged_people`, `get_opportunity_scorecard`, `ask_sales_ai_about_opportunity` each answer on this tenant (no 403) with the parameters the skill passes.
   - Preview and fetch apply the filter plan you asked for.
   - The person who will run it sees the whole population (counts match your own).
   - Code execution works.
   - Publishing updates the same page by its link.
   - A scheduled task can be created where you run Claude.
4. **Staged runs** (tenant tester)
   - Run it in test-run mode (a new page, never the shared one): 2 to 5 items, then about 20, then the full population.
   - At each stage record what was fetched, kept and dropped (by reason), the fallbacks used, the spread of levels, and the time and tokens it took.
5. **Output quality** (you plus a second reviewer)
   - Score the run against evals/rubric.md: every gate criterion at full marks.
   - Spot-check the top 10 against the source activity: every name, date and figure.
   - Run the same data twice: outcomes for the same items must match.
   - A second reviewer (a person, or a fresh session with only the skill and the run) tries to break it.
6. **Acceptance** (the owner)
   - Reconcile the population and totals with your own report, or explain the differences.
   - The first scheduled run completes.
   - The owner confirms it answers the question, and names who runs it and who reads it.

## Settings

`skills/quarterly-deal-risk-brief/settings.json`:

- `client`: Optional display name, timezone, and currency used to label the brief.
- `scope`: How 'this quarter' is computed and which reps and stages are in or out of the book.
- `fields`: The CRM fields the plugin reads, with fallback names and whether each is required.
- `thresholds`: The numeric rules that decide quiet, decision-maker, and population-change checks.
- `calibration`: The expected spread of risk levels across the book, used to catch an off run.
- `moves`: Example actions and questions the brief draws on when recommending what to ask a rep.
- `output`: Where the published brief is written or hosted each run.
- `schedule`: When the weekly run fires and the fixed prompt it uses.

## What's inside

```
quarterly-deal-risk-brief/
├── .claude-plugin/plugin.json
├── README.md
├── evals/rubric.md                            # how to judge a run (kept outside the skill)
└── skills/quarterly-deal-risk-brief/
    ├── SKILL.md                               # the workflow Claude follows
    ├── settings.json                          # scope, thresholds, output and schedule
    ├── assets/brief-template.html             # the fixed page design; runs only change the data
    ├── examples/sample-data.json              # fictional data for previews and tests
    ├── references/actions.md                  # How 1:1 questions and actions are drafted
    ├── references/data-collection.md          # Exact sources and tool calls, with fallbacks and limits
    ├── references/data-schema.md              # the exact shape of data.json
    ├── references/evidence-guidelines.md      # How evidence is attributed and written honestly
    ├── references/framework.md                # The judgment standard for rating each deal
    ├── references/publishing.md               # building the page and updating the same brief
    ├── references/tool-inventory.md           # the Backstory tools it uses: parameters, behaviours, last verified
    ├── scripts/assemble.py                    # Turn population items and per-deal judgments into the fixed brief data file
    ├── scripts/build_brief.py                 # checks the data, ranks and counts, and builds the page
    ├── scripts/population.py                  # Resolve fields, apply scope, and fix the in-scope population of deals before any judgment happens
    ├── scripts/test_assemble.py               # tests for assemble.py
    └── scripts/test_population.py             # tests for population.py
```

## Testing

To see the page with fictional data:

```bash
python3 skills/quarterly-deal-risk-brief/scripts/build_brief.py skills/quarterly-deal-risk-brief/examples/sample-data.json sample-brief.html
```

To test the scripts after any change (standard library only, Python 3.8+):

```bash
python3 skills/quarterly-deal-risk-brief/scripts/test_population.py
python3 skills/quarterly-deal-risk-brief/scripts/test_assemble.py
```

Judge a few runs against `evals/rubric.md` before you rely on it, and again after any change to the instructions. It sits outside the skill folder so a run never reads it as instructions.
