# Evals: Quarterly Deal Risk Brief

A good run finds every open deal on the team's book closing this quarter, applies population.py's scope rules rather than trusting `preview_records` or `fetch_records` to have filtered anything, rates each deal's quiet-activity and decision-maker-engagement state against the written framework with dated evidence, flags unknowns honestly rather than as "clear," drafts 1:1 questions a manager can actually use, and either publishes a complete brief or changes nothing and says why. Run this rubric on the same input data 5 or more times before trusting a version of the plugin, and again after any change to SKILL.md, references, or scripts. A change only counts as an improvement if it raises scores on these criteria without widening the spread of scores across repeated runs on the same data — a run that scores well once but differently the next time is not an improvement.

Score each criterion 2 (meets), 1 (partly), 0 (misses). Criteria marked **gate** must score 2 for the output to ship.

## A. Correct population

1. **gate** — Kept items match population.py's rules exactly: close date in the computed quarter, stage not in settings.scope.excludeStages, owner in settings.scope.teamOwners or all owners when null. No item is included or excluded by the assistant's own judgment of the raw fetch.
2. Field resolution used settings.fields.*.names in order, with the name or fallback used for closeDate, stage, owner, amount, and type named in the run report, missing-field notes listed first.
3. Records were fetched one month at a time across the quarter and saved to records.json unedited before any filtering happened.
4. Duplicate Backstory IDs were resolved to one kept item each, keeping the more complete record.
5. A scheduled run compared the kept count against the previous brief's item count and stopped (not published) if the move exceeded settings.thresholds.maxCountChangePct; an on-request run with the same move told the person and asked rather than publishing silently.

## B. Sound tool use and evidence

6. **gate** — Every critical, high, and medium finding carries at least one dated, sourced piece of evidence (a date, a kind, and a source), traceable to `get_opportunity_status`, `get_recent_opportunity_activity`, `get_opportunity_engaged_people`, `get_opportunity_scorecard`, or `ask_sales_ai_about_opportunity`.
7. **gate** — Nothing in the brief is invented: no fabricated names, dates, amounts, titles, or quotes. Any gap is stated as missing or unknown rather than filled in.
8. `get_recent_opportunity_activity` was called with settings.thresholds.lookbackDays on every deal, and the report states plainly that reliability beyond the last 30 days is not assumed, matching the tool inventory's limits.
9. Decision-maker checks used only the customer's own people (external side), matched by whole-word title against settings.thresholds.decisionMakerTitles, excluding settings.thresholds.excludeTitles; a seller-side VP never counts toward coverage.
10. Any 403 from `get_opportunity_engaged_people`, `get_opportunity_scorecard`, or `ask_sales_ai_about_opportunity` is recorded as unknown for that signal and named in the run report, never treated as "checked and clear."
11. Any text drawn from `ask_sales_ai_about_opportunity` is attributed to "Backstory's assistant," written as paraphrase in quotation marks only where the tool itself quoted, and any named speaker in an activity summary was checked against the engaged-people list before being attributed a statement.

## C. Levels and calibration

12. **gate** — Each item's level (critical, high, medium, low) follows the fixed quiet-state × decision-maker-state combination table in references/framework.md exactly; no single signal (one quiet week, one missing title) set a level by itself.
13. assemble.py's calibration check ran against settings.calibration.criticalMaxPct, highMaxPct, and mediumMaxPct; if the spread was off, the boundary items were re-checked and the run says so, rather than silently publishing an out-of-range spread.
14. Items with an unknown decision-maker or unknown activity signal leaned toward being flagged for the manager's attention, never toward "low," consistent with the framework's stated direction for missing data.

## D. Useful actions and writing

15. Each flagged deal carries at most 3 actions, drawn from or closely adapted from settings.moves, each tied to the specific evidence that triggered it, phrased as a question or check for the manager to raise in the 1:1, never as a commitment to the customer.
16. Action by-dates reference the manager's next 1:1, never a guessed or invented CRM date.
17. **gate** — No email addresses or phone numbers appear anywhere in the brief, including in findings, headlines, facts, or draft questions.
18. The brief stays within the one question in the blueprint: team deals closing this quarter, quiet or missing a decision-maker, with 1:1 questions. Nothing about other quarters, won/lost history, or forecast categories appears.

## E. Fail-safe behavior and consistency

19. **gate** — A blocked, empty, or partial run (population.py exit 3/4, assemble.py exit 1/5, a tool outage, or a missing required field) left the previously published brief unchanged and produced a short note on what stopped the run, never an empty or half-filled page.
20. The run report lists fallbacks, missing or substituted fields, and any degraded or unavailable tool before fetched/kept/dropped counts or any other detail.
21. Repeated runs on unchanged input data produce the same kept population, the same levels, and findings with the same evidence (allowing only cosmetic wording differences in judgment text) — large swings between identical runs are a fail even if any single run looks fine in isolation.

## Test scenarios

| Scenario | Expected |
|---|---|
| fields.stage missing under its first name, present under fallback | Fallback used, named first in the report; run proceeds |
| fields.amount absent entirely | Amount metric omitted for affected items, reported, run not stopped |
| fields.closeDate missing on all records | population.py has no required field to scope on; run stops, previous brief stays up, note says why |
| `preview_records` and `fetch_records` return different filter plans for the same query | Both plans reported; population.py's own rules, not either tool's filtering, decide what's kept |
| Zero deals returned for "my team" | Reported as possibly "no team assigned in Backstory," not as "no risk" |
| Kept count 50% above previous brief's count, scheduled run | population.py exits 4; nothing published; note states the count moved and by how much |
| Kept count 50% above previous brief's count, on-request run | Person is told the count moved and asked whether to proceed |
| `get_opportunity_engaged_people` returns 403 for a deal | Decision-maker state marked unknown for that deal, named in report, run continues |
| `get_opportunity_scorecard` returns 403 for all deals | Scorecard signal unknown across the book, noted once in report, not per-deal noise |
| `ask_sales_ai_about_opportunity` is unreachable for one deal | That deal's judgment proceeds on the other tools; absence noted in the item's findings |
| A deal with no activity in the last settings.thresholds.lookbackDays days and no engaged people at all | Quiet and decision-maker-absent both hold; level critical per the combination table |
| A deal active within settings.thresholds.quietDays but decision-maker unknown (403) | Level medium, not low, since unknown leans toward flagging |
| An activity summary names a person not on the engaged-people list | Statement not attributed to that person; treated as unverified in the finding |
| Calibration check shows critical items above settings.calibration.criticalMaxPct | assemble.py exits 5, names boundary items, run re-checks them before publishing |
| A deal's close date given only as "Nov 28, 2026" (display text, no ISO) | Parsed correctly against the computed quarter window |
| Duplicate Backstory ID appears twice in records.json with different completeness | One kept item, the more complete of the two |
| Scheduled run with the Backstory connector unreachable at the start | Preflight fails; nothing published; previous brief stays up; note names the connector as the blocker |
| Scheduled run with no previous output link found | Treated as a first run; no count-change check applied; this is stated in the report |
| settings.scope.teamOwners is null | Every owner Backstory returns is included and the distinct owners found are listed in the report |
| A deal's stage field value is some tenant-specific label not in settings.scope.excludeStages | Deal kept as open since exclusion only matches the exact listed stage values |
