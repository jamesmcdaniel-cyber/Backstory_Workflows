---
name: quarterly-deal-risk-brief
description: "Produces a ranked weekly brief of the team's open deals closing this quarter, flagging quiet deals and deals with no engaged decision-maker, with 1:1 questions for each rep. Use when asked to run, refresh, build, update, or check the deal risk brief, pipeline risk review, quiet deals, no-decision-maker deals, this quarter's open opportunities, or 1:1 prep for the team."
metadata:
  version: "0.1.0"
---

# Quarterly deal risk brief

> Which of my team's open deals closing this quarter have gone quiet or lack an engaged decision-maker, and what should I ask each rep about them in our 1:1?

The output is a weekly brief, ranked by risk level, of the team's open deals closing this quarter, flagging quiet deals and deals missing an engaged decision-maker, with dated evidence and draft 1:1 questions for each rep. The sales manager reads it before their weekly 1:1s.

Run with the scope in settings.json without asking the user for filters. Ask only when something blocks the run.

**Scheduled runs.** On the weekly scheduled run: ask nothing, including the preview_records confirmation — compare the fetched count against the previous brief's item count instead of waiting for a person. If the Backstory connector isn't reachable, a required field is missing, or any script exits with an error, don't publish anything; leave the previous brief in place and report what stopped the run. Never create a second output file or page for a scheduled run. In the report, compare the new count and level spread against the previous output. Don't offer to create the schedule again once it exists.

## Read first

| File | Gives |
|---|---|
| settings.json | scope, field names and fallbacks, thresholds, calibration, moves, output target, schedule |
| references/tool-inventory.md | current shipped description, parameters and known limits of each tool used |
| references/framework.md | the judgment standard: quiet-activity and decision-maker states, combination rules to levels, how unknowns lean |
| references/data-collection.md | exact tool calls, parameters, date parsing, fallbacks when a tool errors |
| references/evidence-guidelines.md | how to attribute, date and phrase evidence honestly; naming Backstory's assistant correctly |
| references/actions.md | how to draft 1:1 questions/actions from settings.moves and evidence |
| references/data-schema.md | exact shape of data.json |
| references/publishing.md | where the brief goes, how to read the previous brief, what to report |

### 0. Preflight

Load settings.json. Confirm the Backstory connector responds. Re-read the current description of each tool this skill uses (`preview_records`, `fetch_records`, `get_opportunity_status`, `get_recent_opportunity_activity`, `get_opportunity_engaged_people`, `get_opportunity_scorecard`, `ask_sales_ai_about_opportunity`) against references/tool-inventory.md and report any difference first — a changed parameter, a new limit, a 403 where none was expected — following that tool's fallback from the inventory. Run a small fetch_records call and confirm fields.closeDate, fields.stage, and fields.owner come back under one of their configured names; report any missing required field first, since the run cannot scope deals without closeDate, stage, and owner resolved.

**Test runs.** When the request asks for a test run or a narrower scope, apply that scope for this run only and publish to a new file or page, never over the shared brief.

## Workflow

### 0. Preflight
As above.

### 1. Preview the list
Call `preview_records` with object_type "opportunity" and a plain-language query for open deals closing this quarter. Read back the filter plan it reports (it may rewrite the quarter as "next 90 days" or similar — note this) and the count. On a request run, relay the plan and count to the user and wait for confirmation before fetching. On a scheduled run, skip waiting: compare the previewed count against the previous brief's item count (from references/publishing.md's reading of the prior output) and proceed, noting the comparison for the report.

### 2. Fetch the records
Call `fetch_records` with the same object_type and query text used in preview, fetching one calendar month at a time across the quarter to avoid output overflow. Do not trust that the query filtered correctly — save every record exactly as returned. Write the full combined set to records.json: `{"records": [...]}`.

### 3. Build the population
Run:
```
python3 <skill>/scripts/population.py records.json --out population.json --as-of <today>
```
Write the input first as `{"records": [...], "previousCount": <number or null, from the previous brief, or null on a first run>}`. The script resolves fields.closeDate, fields.stage, and fields.owner (and optional fields.amount, fields.type) by settings.fields.*.names with fallbacks, computes the current quarter from scope.fiscalYearStartMonth, applies scope.excludeStages and scope.teamOwners (null keeps every owner, reported by name), de-duplicates by Backstory ID, and groups by owner. Read population.json's counts (fetched, kept, dropped), fieldMap, and report lines.
- Exit 0: continue with items in population.json.
- Exit 1: invalid input — fix the records.json shape and rerun.
- Exit 3: nothing kept — stop, do not publish, report that no in-scope deals were found this quarter.
- Exit 4: kept count moved from previousCount by more than settings.thresholds.maxCountChangePct — on a scheduled run, publish nothing and report the swing; on a request run, tell the person the count moved sharply and ask whether to proceed.

### 4. Judge each deal
For each item kept in population.json, in batches of about 10, using subagents in parallel where available: call `get_opportunity_status`, `get_recent_opportunity_activity` with days=settings.thresholds.lookbackDays (explicitly, up to 90, noting if the server still returns only 30), `get_opportunity_engaged_people` (keep only the customer/external side, filter titles by settings.thresholds.decisionMakerTitles with whole-word matching, excluding settings.thresholds.excludeTitles), `get_opportunity_scorecard`, and up to two targeted `ask_sales_ai_about_opportunity` questions only where the activity or people signal is unclear. Check any named speaker in an activity summary against the engaged-people list before attributing a statement, per references/evidence-guidelines.md. Refer to the open-ended tool's output as "Backstory's assistant," never "Sales AI." If `get_opportunity_engaged_people`, `get_opportunity_scorecard`, or `ask_sales_ai_about_opportunity` return 403, mark that signal unknown in the judgment — never "clear" or "no risk." Each subagent writes one items/<id>.json: quiet-activity rating, decision-maker rating, dated evidence per references/framework.md, and draft 1:1 questions per references/actions.md. Return one line per record to the main thread.

### 5. Assemble the brief data
Run:
```
python3 <skill>/scripts/assemble.py assemble_input.json --out data.json --as-of <today>
```
Write assemble_input.json as `{"population": [items population.py kept], "judgments": [the items/<id>.json contents]}` first. The script matches every population item to its judgment, derives quiet-state and decision-maker-state against settings.thresholds, applies the fixed combination rules from references/framework.md to set each item's level, computes totals and metrics, and checks the level spread against settings.calibration.
- Exit 0: data.json written per references/data-schema.md.
- Exit 1: one or more items missing a judgment — go back to step 4 for those ids and rerun.
- Exit 5: level spread off calibration — re-check the named boundary items' evidence and judgments, then rerun assemble.py.

### 6. Build and publish
Run:
```
python3 <skill>/scripts/build_brief.py data.json brief.html
```
Fix anything it lists (exit 1) and rerun. Publish per references/publishing.md: read the previous brief first for comparison, write to settings.output.artifactUrl or settings.output.filePath (whichever is set; if both are null, write to the default location the plugin has used before and report that neither was configured), and never create a second output on a scheduled run.

### 7. Report back
Tell the manager, in this order: any fallback field names used or missing optional fields (fields.amount, fields.type), any tool that returned 403 or an unexpected description change, fetched/kept/dropped counts from population.json, the level spread and whether a calibration re-check happened, and where the brief now lives, comparing against the previous brief's count and levels. Take every number from data.json or the scripts' output — never estimate. Keep run notes (which batches ran, retries) in chat only, never in the published brief.

**Offer to schedule.** After the first successful run, if no schedule exists yet, offer once: running weekly on settings.schedule.day at settings.schedule.time (settings.schedule.timezone or the manager's default if null), using settings.schedule.promptTemplate, under the manager's own Claude account and Backstory access. Create the scheduled task only on a clear yes. Never offer again once a schedule exists.

## Non-negotiables

- Critical, high, and medium findings carry at least one dated, sourced piece of evidence; no evidence, no flag.
- Decision-maker checks count only the customer's own people, matched by whole-word title, excluding Owner, Lead, Head, and Manager unless settings say otherwise.
- Read-only on Backstory and the CRM: the plugin never updates records, sends anything, or commits to terms; it only drafts questions for the manager to ask.
- No email addresses or phone numbers appear anywhere in the brief.
- A 403 or missing tool result is reported as unknown, never treated as "no risk found" or "checked and clear."
- The in-scope population always comes from population.py's fixed rules on the raw fetched records, never from record search's own filtering.
- A blocked, empty, or partial run never publishes; the previous brief stays up with a short note on what stopped the run.

## Red flags

| Thought | Reality | Instead |
|---|---|---|
| "I can eyeball which deals are quiet instead of running population.py and assemble.py" | Hand-counting and hand-ranking drift from the fixed rules and won't repeat the same way next week | Always run the scripts; read their output, don't recompute it |
| "preview_records said closing this quarter, I'll trust fetch_records filtered it" | Record search can rewrite the date range silently and preview/fetch can disagree | Fetch broadly, save every record, let population.py apply the scope |
| "The manager's VP shows up in every meeting, so decision-makers are covered" | Engaged-people includes the seller's own team; only the customer side counts | Filter to external people only, by the configured titles |
| "get_opportunity_engaged_people 403'd, I'll mark the deal low risk" | A 403 means unknown, not absent or healthy | Mark the signal unknown and lean the rating toward flagging per references/framework.md |
| "Last week's brief is close enough, I'll publish anyway even though assemble.py exited 5" | Publishing past a calibration failure or any script error risks an empty, partial, or miscalibrated brief | Fix what the exit code names, rerun, and only publish a clean result |
| "I'll skip the scheduled run's count check since it's just automation" | A scheduled run has no person to confirm the list; the count check against the previous brief is its only safeguard | Always compare against previousCount and stop per settings.thresholds.maxCountChangePct when it moves too far |

Any of these: stop and follow the workflow.
