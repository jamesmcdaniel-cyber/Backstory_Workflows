# References: Actions

How the assistant drafts the `actions` on each deal's `items/<id>.json` judgment, for `assemble.py` to carry through unchanged into `data.json`. This file governs drafting only; `assemble.py` sets levels and totals from fixed rules and is never second-guessed here.

## What an action is

An action is a question or check for the manager to raise with the rep in their 1:1 — never a commitment, message, or action aimed at the customer. The plugin is read-only on Backstory and the CRM: it drafts text for a person to use, nothing more.

## Source: settings.moves

Every action starts from an entry in `settings.json → moves` (key, label, defaultWho) or a close adaptation of one. Do not invent a new category of action outside the intent of `confirm_decision_maker`, `re_engage`, or `escalate` unless the evidence genuinely doesn't fit any of the three — and even then, keep the same shape (title, who, by, why, steps).

| moves key | Use when | Typical trigger |
|---|---|---|
| `confirm_decision_maker` | decision-maker-state is absent or unknown | No external contact matched `thresholds.decisionMakerTitles`, or `get_opportunity_engaged_people` returned 403 |
| `re_engage` | quiet-state is quiet | Last dated activity older than `thresholds.quietDays` |
| `escalate` | quiet-state is quiet AND decision-maker-state is absent, or risk has persisted across runs | Combination driving a critical or high level |

## Pairing an action with evidence

Every action must name the specific dated evidence that triggered it — the same evidence already written into the judgment's `findings`. An action with no backing finding is not written. Phrase the `why` field as the fact, not the inference:

- Good: "No activity logged since [date]; last recorded touch was a demo recap."
- Bad: "Deal seems stalled."

Never state an amount, date, or name not present in the tool output. If the evidence is a 403 or missing data, say so plainly in `why` ("Engaged-people data unavailable for this deal — decision-maker presence unknown") and use `confirm_decision_maker` anyway: unknown leans toward flagging, not toward skipping the action.

## Who: rep or manager

Use `settings.moves[key].defaultWho` unless the evidence clearly calls for the other:

- Default to **rep**: the rep has the relationship and the access to get the answer (confirm a contact, chase a reply, update next steps).
- Override to **manager**: the deal has been quiet for more than one cycle running (compare against the previous brief if available), the risk is `critical`, or the action is explicitly `escalate` — these need the manager's involvement, not another rep follow-up.

Never assign an action to the customer or to "Backstory." The only two valid values for `who` are the rep's name (from the resolved owner field) and "manager."

## By-dates

`by` is always the date of the manager's next scheduled 1:1 with that rep, as given in the brief's context (or, if no cadence is known, left as the generic "next 1:1" rather than a guessed calendar date). Never invent or infer a CRM close date, a "by end of week," or any date not grounded in the manager's own cadence. If no 1:1 date is known, write `by` as null and let the brief render "next 1:1" — do not fabricate a date to fill the field.

## Steps: questions, not commitments

Each action's `steps` are phrased as things the manager asks or checks in the conversation with the rep — never as promises, discounts, or outreach to the customer. Examples of correct phrasing:

- "Ask [rep] who, if anyone, above the champion has seen the proposal."
- "Ask whether the quiet period reflects a real pause or a missed follow-up."
- "Check whether the rep has a specific next step scheduled, and with whom."

Never write a step like "Offer a discount to re-engage" or "Have the rep email the CFO directly" — those commit to terms or instruct contact with the customer, both out of scope. The output drafts manager-facing prep, not customer-facing messaging.

## Limit and ranking

At most 3 actions per deal. When more than 3 plausible actions exist, keep the ones that would most change the deal's risk level if resolved — not the ones with the most evidence or the easiest fix. A missing decision-maker on an otherwise active deal usually outranks a minor scorecard gap; a quiet deal with no decision-maker (the `escalate` case) outranks either alone. Order the kept actions by this same priority, most level-changing first, so the first action listed is the one the manager should raise first.

## What belongs elsewhere

- The rating that makes an action urgent (quiet-state, decision-maker-state, the resulting level) is `assemble.py`'s fixed combination rule, read from `references/framework.md` — this file never re-derives or overrides a level.
- The underlying evidence write-up (dated, sourced, attributed) is `references/evidence-guidelines.md`'s job; this file only tells you how to turn written evidence into an action.
- Scorecard or activity interpretation itself (what counts as decisive vs. early evidence) lives in `references/framework.md`, not here.
