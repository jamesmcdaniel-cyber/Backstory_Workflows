# Data Collection

Exact sources, parameters, fallbacks and limits for this skill. Read on demand during a run; never substitute judgment for the rules below.

## 1. List query: finding the population

Two-step call, never skipped, never collapsed into one:

| Step | Tool | object_type | query wording |
|---|---|---|---|
| 1 | `preview_records` | `opportunity` | plain language: open deals with a close date in this quarter |
| 2 | `fetch_records` | `opportunity` | same wording as the preview |

Rules:
- Read the filter plan returned by `preview_records` and by `fetch_records` separately — they can read the same query differently. Report any difference, do not assume they agree.
- On a scheduled run, never wait for confirmation. Instead compare the count against the previous brief's item count: that comparison is `population.py`'s job (`thresholds.maxCountChangePct`), not something decided here.
- Fetch one month at a time across the quarter (three calls for a calendar quarter) to avoid overflowing tool output. Save every record from every call, exactly as returned, into `records.json`. Never drop or pre-filter a record because the query "should" have excluded it.
- Only fields in the connector's record-search schema come back. A field named in `settings.fields` that is not in that schema will be silently absent — this is a `population.py` field-mapping concern, not something to fix by rewording the query.
- Record search reliably handles only broad filters like a close-date range. It does not reliably handle stage, renewal type, owner groupings, or other words — those tokens may be silently dropped or mis-mapped. Treat every fetched record as unscoped raw input; all scoping (open stage, owner, quarter boundaries, de-duplication) happens in `population.py` on the raw records, never trusted to the query.

## 2. Per-deal tool calls

For each kept item (from `population.py`'s output), call:

| Tool | Parameters | Notes |
|---|---|---|
| `get_opportunity_status` | — (fixed 30-day window) | Default risks/next steps; check dates on any risk, since it can repeat stale ones. Next steps usually name an owner, no date. |
| `get_recent_opportunity_activity` | `days` = `thresholds.lookbackDays`, explicitly passed, up to 90 | Returns AI summaries (often weekly digests), not verbatim text. Check named speakers against `get_opportunity_engaged_people` before attributing a statement. Activity is sometimes matched to the wrong opportunity — use as supplement, not replacement, for account-level activity. |
| `get_opportunity_engaged_people` | — (fixed 30-day window) | Returns both sides. Keep only the customer (external) side for decision-maker checks. Strip email addresses before writing anything to a judgment file. Apply `thresholds.decisionMakerTitles` (whole-word match) and `thresholds.excludeTitles` here, in the judgment write-up — the actual leveling rule lives in `assemble.py`. |
| `get_opportunity_scorecard` | — | Read the answers returned as-is; never assume a MEDDIC/MEDDPICC/SPICED or any other framework or picklist. |
| `ask_sales_ai_about_opportunity` | `question` (one of up to 2 targeted questions per deal, asked only where the signal from the above tools is unclear) | 10–30 seconds per call. Call this "Backstory's assistant" in anything a person reads, never "Sales AI." Treat its text as paraphrase of summaries, never as the customer's own words, even when quoted. |

## 3. Date parsing

- `fetch_records` returns dates as display text (example: "Nov 28, 2026"), not ISO. Parse both forms: ISO strings where present, and the display text format elsewhere. Never assume one format for a whole batch.
- All date-window math (quarter boundaries, quiet-days comparisons) is done in `population.py` / `assemble.py`, not by eye. When writing a judgment file, record the evidence date exactly as found and let the script compare it to `thresholds.quietDays`.
- Never invent or infer a date not present in the source tool's output.

## 4. 403s and tenant limits

`get_opportunity_engaged_people`, `get_opportunity_scorecard`, and `ask_sales_ai_about_opportunity` can return 403 on some tenants.

- On a 403 (or any error) from any of these three tools: mark the corresponding signal (decision-maker engagement, scorecard answer, or assistant analysis) as **unknown** in the item's judgment file. Keep going — never stop the run for one deal's 403.
- Unknown is not the same as "checked and absent" or "healthy." It must be stated plainly in the judgment and carried through to the report (named first, per the skill's reporting order).
- `ask_sales_ai_about_opportunity` 403s do not block the run: the skill must produce a judgment using `get_opportunity_status`, `get_recent_opportunity_activity`, and whatever of the other two tools succeeded.

## 5. Reliability window

- `get_opportunity_status`, `get_opportunity_engaged_people`, and `ask_sales_ai_about_opportunity` only ever see the last 30 days, regardless of other settings.
- `get_recent_opportunity_activity` accepts `days` up to 90 (`thresholds.lookbackDays`), but Backstory is only reliable for the last 30 days. Any activity (or lack of it) reported beyond 30 days back must be labeled unverifiable in the judgment write-up, never treated as confirmed history.
- If the server returns a shorter window than requested, state the actual window returned, not the one requested.
- Never conclude "no activity happened" beyond the last 30 days from an absence in these tools — absence of a summary is not evidence of silence that far back.

## 6. What stays out of data collection

- No counting, filtering, ranking, or date-threshold decisions happen while collecting data — those are `population.py` and `assemble.py`'s job, applied to what is collected here.
- No invented names, dates, amounts, or quotes. If a tool returns nothing usable for a deal, say so in the judgment file instead of filling a gap.
- No email addresses or phone numbers are carried into any judgment file, ever, even temporarily.
