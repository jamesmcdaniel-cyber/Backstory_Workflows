# Evidence Guidelines

How evidence collected from Backstory is written into judgment files (`items/<id>.json`) and, from there, into the brief. These rules apply to every finding, headline, assessment, and 1:1 question written for this skill.

## 1. Source types and how to write them

| Source (kind) | Where it comes from | How to write it |
|---|---|---|
| `meeting` / `email` | `get_recent_opportunity_activity`, `get_opportunity_status` | Paraphrase only. These tools return AI-generated summaries (often weekly digests), never transcript or message text. |
| `call` | Same as above, when a summary identifies a call | Paraphrase only, same rule as meeting/email. |
| `score` | `get_opportunity_scorecard` | Quote the answer field value as returned; do not infer a framework or picklist meaning not stated. |
| `other` | `ask_sales_ai_about_opportunity` | Paraphrase; see Section 3. |
| `crm` / `note` | Resolved opportunity fields (stage, amount, type) from `population.py` output | State the field name and value exactly as resolved; never a value the tool didn't return. |

**Never write a verbatim quote attributed to the customer.** `get_recent_opportunity_activity` and `get_opportunity_status` return summaries, not raw email or transcript text. Any text that looks quotable is Backstory's paraphrase, not the customer's words — write it as a paraphrase ("the summary describes the buyer as asking for budget sign-off") not as dialogue ("the buyer said: ...").

## 2. Naming "Backstory's assistant"

- `ask_sales_ai_about_opportunity` output is called **"Backstory's assistant"** in every finding, headline, assessment, action, or report line a person reads. Never "Sales AI," never the underlying model name.
- Treat its answers as analysis, not fact: it reads the same 30-day summaries other tools read, can misattribute a statement, and has described filing content as something the client said. Any claim it makes about what a person said must be cross-checked per Section 3 before being written as evidence; if it can't be checked, attribute it explicitly to Backstory's assistant ("Backstory's assistant suggested the champion has gone cold") rather than to the customer.
- Use at most the number of questions set for this step in the workflow (2 per deal); do not write more calls than were actually made.

## 3. Checking named speakers

- Before attributing any statement, concern, or question to a named person, check that name against `get_opportunity_engaged_people` for that opportunity (customer side, per Section 4).
- `get_recent_opportunity_activity` summaries sometimes swap buyer and seller. If a name in a summary doesn't appear in the engaged-people list, or the side (internal/external) is ambiguous, do not assert who said it — write the finding without a named speaker ("a stakeholder raised pricing concerns, per the activity summary dated Nov 12") or mark the attribution as unverified.
- Never invent a name, title, or role not returned by a tool.

## 4. Customer-side only for decision-maker evidence

- `get_opportunity_engaged_people` returns both the customer's people (external) and the seller's own team (internal). Decision-maker findings use **external people only**.
- Match titles whole-word against `thresholds.decisionMakerTitles`, excluding anyone matching `thresholds.excludeTitles` even if their title contains a matched word (e.g., "Product Owner" is not "Owner" the title, but still excluded by the whole-word rule for "Owner").
- If `get_opportunity_engaged_people` returns a 403, the decision-maker signal is **unknown**, not absent. Write this plainly in the finding and in the run report; never treat it as evidence of no decision-maker engaged.

## 5. Evidence requirements by level

- Every finding rated **critical, high, or medium** must carry at least one evidence entry with a `date`, a `kind`, a `text` paraphrase, and a `source` tool name.
- An evidence entry with no date is not usable to support a critical, high, or medium finding. If no dated evidence exists, the finding cannot be rated above **low** regardless of suspicion or inference.
- **Low**-level findings and informational context may note the absence of evidence without requiring a dated citation, but must say so explicitly (see Section 6) rather than being silent.
- Dates must come from a tool's own returned date field or display text, parsed as given (see `references/data-collection.md`); never estimate or back-calculate a date not returned.

## 6. Missing or unknown data

- State missing or unknown data plainly in the finding or in the item's top-level notes: "engaged-people data unavailable (403) — decision-maker engagement unknown," not silence and not a guess.
- Unknown is a distinct state from "checked and absent." Never collapse the two. The combination rules in `references/framework.md` and `assemble.py` treat unknown and absent differently; the judgment file must preserve that distinction by stating which one applies.
- An empty or missing result from any tool used in this skill is never evidence of health or of risk — write "no data returned" rather than inferring either way.
- Never fill a gap with an assumed CRM value, title, or activity date not actually returned by a tool.

## 7. Privacy and prohibited content

- No email addresses anywhere in a finding, headline, assessment, action, or question, even if a tool returns one — strip it before writing.
- No phone numbers anywhere, under any circumstance.
- No invented amounts, dates, titles, or names. If `fields.amount` or another optional field is missing for a deal, say "amount not available" rather than omitting it silently or estimating one.

## 8. What belongs elsewhere

- Counting, scope decisions, de-duplication, and level assignment are not evidence-writing tasks — they belong to `population.py` and `assemble.py` per their fixed rules. This file governs only how the assistant describes and sources what it found, not how the brief counts or ranks it.
- Drafting the 1:1 questions themselves (wording, who they're addressed to, which `moves` entry they map to) is covered in `references/actions.md`; this file only governs the evidence those questions must be grounded in.
