# Framework: Rating Deal Risk

This is the judgment standard for every deal in the quarterly deal risk brief. It covers two areas only. Everything else (scoring rules, totals, calibration checks) is decided by `scripts/assemble.py`; this file defines the inputs the assistant hands to it, not the levels themselves.

## Area 1: Quiet activity

**Covers:** whether the deal has had real, recent forward motion.
**Question it answers:** Has anything happened on this deal recently that moves it toward close?

### Evidence by strength

| Strength | What it looks like | Example |
|---|---|---|
| Strong (active) | A dated meeting, call, or email exchange within `thresholds.quietDays`, with substance tied to the deal (pricing discussion, next step scheduled, objection raised) | "Oct 14 — call summary: customer requested revised pricing" |
| Early | Dated activity within `thresholds.quietDays` but thin — a scheduling email, a one-line check-in, internal-only activity with no customer reply confirmed | "Oct 12 — summary notes an email sent to the account; no reply recorded" |
| No evidence (quiet) | No activity dated within `thresholds.quietDays` in `get_recent_opportunity_activity` or `get_opportunity_status`'s next steps/risks | Last dated item is older than `thresholds.quietDays`, or no items at all |

Use `get_opportunity_status` and `get_recent_opportunity_activity` (days = `thresholds.lookbackDays`) together. `get_opportunity_status` can repeat stale risks from older activity — always check the date on each risk or next step before counting it as recent. If the most recent dated item is older than `thresholds.quietDays`, the deal is quiet regardless of what the status summary currently lists as a "next step," since next steps carry no date of their own.

Where the activity signal is unclear (e.g., status and activity disagree, or the only activity is ambiguous), ask `ask_sales_ai_about_opportunity` one targeted question such as "What is the most recent dated customer interaction on this deal?" Treat its answer as Backstory's assistant's paraphrase, never as the customer's own words, and still require a date before treating it as evidence.

**quiet-state values:** `active`, `early` (treated as `active` for the combination table — see below), `quiet`, `unknown`.

### Unknown activity signal

If `get_recent_opportunity_activity` and `get_opportunity_status` both return nothing usable (empty, or a 403 from a related call blocking context), rate quiet-state `unknown`. Never default an unknown activity signal to `active`. State plainly in the item's judgment file that activity could not be verified and why.

## Area 2: Decision-maker engagement

**Covers:** whether someone with buying authority on the customer side is actually engaged with the deal, not just aware of it.
**Question it answers:** Is a real decision-maker in the loop, evidenced by recent contact?

### Evidence by strength

| Strength | What it looks like | Example |
|---|---|---|
| Strong (present) | `get_opportunity_engaged_people` lists an external (customer-side) person whose title whole-word matches an entry in `thresholds.decisionMakerTitles`, with a nonzero meeting or email count, and the title does not match `thresholds.excludeTitles` | External contact titled "VP, Procurement," 2 meetings |
| Early | A decision-maker title appears but with no recorded meetings/emails in the window (name-only presence, e.g. copied on an old thread), or the only external contact with a matching title is ambiguous (title string partially overlaps an excluded word and is not clearly resolvable) | External contact titled "VP" listed with 0 meetings and 0 emails |
| No evidence (absent) | No external person with a matching title appears at all | Engaged people list contains only "Owner, IT" and "Lead, Ops" — matched words belong to `thresholds.excludeTitles` |

Match titles whole-word, including abbreviations (CEO, CFO, COO, CRO, CIO, CTO, SVP, EVP, VP) from `thresholds.decisionMakerTitles`. Apply `thresholds.excludeTitles` (Owner, Lead, Head, Manager, or whatever settings hold) to strip false matches like "Product Owner" or "VP" embedded in "MVP" — title rules match whole words only. Use only external (customer-side) people from `get_opportunity_engaged_people`; the seller's own VP attending every meeting is not evidence. Strip emails before writing anything to the judgment file.

Where the engaged-people signal is sparse (one contact, unclear seniority, title string is unusual), ask `ask_sales_ai_about_opportunity` one targeted question such as "Who on the customer side has approval authority for this deal?" Treat the answer as Backstory's assistant's paraphrase, confirm any named person appears in `get_opportunity_engaged_people` as external before counting them, and never add a decision-maker to the record on the assistant's word alone.

**decision-maker-state values:** `present`, `early` (treated as `present` for the combination table if there is at least a named contact; treat as `absent` if the title cannot be confirmed as genuinely decision-maker-level — judgment calls land on the stricter side), `absent`, `unknown`.

### Unknown decision-maker signal

If `get_opportunity_engaged_people` returns a 403 or no data, rate decision-maker-state `unknown`. Never treat an unknown as `present` or `absent`; state it was not checkable and why (403, no data returned).

## Unknown always leans toward flagging

An unknown signal in either area is a reason for the manager to look, not a clean bill of health. It never resolves to the lowest-risk option in the combination table. See the table below: any `unknown` input produces at least `medium`, never `low`.

## Fixed combination rules (owned by `scripts/assemble.py`)

The assistant does not set the level directly — it writes quiet-state and decision-maker-state (with dated evidence) per deal, and `assemble.py` applies this table exactly:

| quiet-state \ decision-maker-state | present | absent | unknown |
|---|---|---|---|
| **active** | low | high | medium |
| **quiet** | high | critical | high |
| **unknown** | medium | high | medium |

No single signal sets the level alone: a deal with a confirmed decision-maker but gone quiet is still `high`, not `low`, because silence from an otherwise-engaged buyer is itself a risk signal; a deal with recent activity but no decision-maker is `high`, not `low`, because activity with the wrong person doesn't move a deal to close. Only the combination of both signals reaching their worst state (`quiet` × `absent`) reaches `critical`.

This table is final. A reference, prompt, or judgment file that assigns a level directly, or that argues for a different cell, is wrong — fix the evidence written to quiet-state/decision-maker-state, not the table.

## How the thresholds feed the rules

- `thresholds.quietDays`: the cutoff date for the most recent dated activity; anything older makes quiet-state `quiet`. This is a day count from today, computed by the script, not estimated by the assistant.
- `thresholds.lookbackDays`: how many days of activity history to request from `get_recent_opportunity_activity` on every call (explicit, up to 90). Only the most recent `thresholds.quietDays` window within that history is reliable; anything beyond 30 days is not Backstory-verified, so a gap in older activity is never treated as proof of inactivity for quiet-state — only the absence of activity within `thresholds.quietDays`, drawn from data Backstory actually returned, counts.
- `thresholds.decisionMakerTitles` / `thresholds.excludeTitles`: the exact whole-word match list and exclusion list used to classify each external contact's title. Do not add or infer titles not on these lists; a title not listed and not clearly a close synonym is not a match.

## Checking names before attributing a statement

Activity summaries are AI-generated digests, not transcripts, and have been observed to swap buyer and seller. Before writing any finding that attributes a statement, concern, or question to a named person:

1. Confirm that name appears in `get_opportunity_engaged_people` as an external (customer-side) contact.
2. If the name cannot be confirmed as external, write the finding without naming an individual (e.g., "the customer raised pricing concerns") rather than risk misattributing an internal statement to the customer or vice versa.
3. Never present a paraphrase from `get_recent_opportunity_activity`, `get_opportunity_status`, or `ask_sales_ai_about_opportunity` in quotation marks as the customer's own words.

## Calibration check

`calibration.criticalMaxPct`, `calibration.highMaxPct`, and `calibration.mediumMaxPct` set expected ceilings on the share of kept deals landing in each level in a normal week. `assemble.py` computes the actual spread and exits 5 if any ceiling is exceeded, naming the boundary items (deals whose quiet-state or decision-maker-state evidence was early/ambiguous rather than clear-cut). On that exit, re-examine only those named boundary items against this framework — re-check whether early evidence was correctly distinguished from strong or no evidence, and whether an unknown was genuinely unconfirmable rather than evidence the assistant didn't look hard enough for — then re-run assemble. Do not loosen the thresholds or the combination table to pass calibration; calibration flags the run for a second look, it does not change the standard.
