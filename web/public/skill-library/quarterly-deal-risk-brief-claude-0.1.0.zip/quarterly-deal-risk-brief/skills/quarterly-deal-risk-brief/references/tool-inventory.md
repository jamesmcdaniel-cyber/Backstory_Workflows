# Backstory tool inventory

The Backstory connector tools this skill uses: what each is for, the parameters that matter, and how each behaves in practice. From Backstory Studio's inventory, last full review 2026-11-19. **The connector evolves:** at the start of each run, re-read each tool's current description, and report any difference first (a parameter, a limit, a 403), following the fallback the skill gives for it.

| Tool | Used for | Parameters that matter | Behaviours to design around | Last verified |
|---|---|---|---|---|
| `preview_records` | Count and check a list query before fetching | object type; plain-language query | Rewrites queries it can't map, without saying so: date ranges became "next 90 days" or "this year"; renewal type and forecast category became a Stage filter; a tier was matched to Account Name. Always read the filter plan it returns. Its description tells the assistant to stop and wait for the user to confirm, so unattended (scheduled) runs need a scripted alternative: a count check against the last run. | 2026-11-18 |
| `fetch_records` | Pull the records | the same object type and query as the preview; a limit above the count | Same rewriting, and preview and fetch can apply different plans to the same query. Only fields in the connector's record-search schema can be filtered or returned: a newly mapped custom field can take 24 hours or more to appear, may not appear at all, and unknown fields are dropped silently. Dates come back as display text ("Nov 28, 2026"), not ISO. Large results can overflow the tool output: fetch one month at a time. | 2026-11-18 |
| `get_recent_opportunity_activity` | Activity logged against one opportunity | days: as for account activity | Same as account activity, and activity is sometimes matched to the wrong opportunity (a renewal meeting under a new-sale opportunity): use it to supplement account activity, not replace it. | 2026-11-17 |
| `get_opportunity_status` | Current risks, topics and next steps for a deal | fixed 30 days | Can repeat stale risks from older activity: check the dates. Next steps usually name an owner but no date. | 2026-11 |
| `get_opportunity_engaged_people` | Contacts on a deal and how engaged they are | fixed 30 days | As for account engaged people: emails to strip, both sides returned, 403 on some tenants. | 2026-11 |
| `ask_sales_ai_about_opportunity` | Targeted questions about a deal | question; 10–30 seconds per call | As for the account version. Returned 403 on some tenants: the skill must work without it. | 2026-10 |
| `get_opportunity_scorecard` | A deal's qualification scorecard | — | Returned 403 on some tenants: the skill must work without it. Read the answers returned; never assume a framework or picklist. | 2026-10 |

## How to verify a tool

1. Read the tool's current description in the session: parameters, defaults, limits.
2. Make one call on a known account or query and look at the raw output: format, dates, fields present.
3. For record search: run the same query through preview and fetch and compare the filter plans; request each custom field the skill needs and confirm it comes back with values.
4. Update the date and any change here.

## Known gaps

What the connector can't do today, so the skill never relies on it:

- Raw text (or excerpts) of a given email or transcript, for verbatim quotes.
- Who sent and who replied, per message, for two-way contact.
- Custom fields in the record-search schema as soon as they are mapped, and an error instead of silently dropping unknown fields.
- ISO dates in record output.
- Field history (previous values), for trends.
- A non-interactive mode for record search (no "stop and wait"), for scheduled runs.
