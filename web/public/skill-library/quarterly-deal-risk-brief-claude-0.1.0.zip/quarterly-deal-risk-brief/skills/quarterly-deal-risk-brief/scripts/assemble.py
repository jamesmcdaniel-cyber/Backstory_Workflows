"""
scripts/assemble.py

Turns population.py's kept opportunities and the per-deal judgment files
(items/<id>.json, written by the assistant) into the fixed brief data file
(data.json) consumed by scripts/build_brief.py.

Usage:
    python3 assemble.py input.json --out data.json [--as-of YYYY-MM-DD] [--settings settings.json]

Where input.json is a JSON object:
    {"population": [items population.py kept], "judgments": [one object per item]}

Judgment shape (written by the assistant per item, items/<id>.json):
    {
      "id": ...,
      "lastActivityDate": "YYYY-MM-DD" or display text or null,
      "activityUnknown": bool (true when the activity tool returned no usable
          result, e.g. a 403 or an error; this overrides lastActivityDate),
      "engagedPeople": [{"name", "title", "side": "external"/"internal"}, ...],
      "peopleUnknown": bool (true when the engaged-people tool returned no
          usable result, e.g. a 403),
      "headline", "assessment", "subtitle": strings,
      "findings": [...], "actions": [...]
    }

Exit codes:
    0 - success, data.json written
    1 - invalid input, or a population item has no matching judgment
    5 - the level spread failed the calibration check; nothing is written
"""

import argparse
import json
import os
import re
import sys
from collections import Counter
from datetime import date, datetime

LEVELS = ["critical", "high", "medium", "low"]

# Minimum number of kept items before the calibration check is meaningful.
# Percentages computed from a tiny population (for example, a single deal)
# swing wildly and would trigger spurious re-checks.
MIN_ITEMS_FOR_CALIBRATION = 5

# Fixed combination table: (quiet-state, decision-maker-state) -> level.
# No single signal sets the level alone.
COMBINATION_TABLE = {
    ("quiet", "absent"): "critical",
    ("quiet", "unknown"): "high",
    ("quiet", "present"): "high",
    ("active", "absent"): "high",
    ("active", "unknown"): "medium",
    ("active", "present"): "low",
    ("unknown", "absent"): "high",
    ("unknown", "unknown"): "medium",
    ("unknown", "present"): "medium",
}


def get_setting(settings, dotted_path, default=None):
    """Navigate settings by a dotted path; a missing key or a null value
    both return default."""
    node = settings
    for part in dotted_path.split("."):
        if not isinstance(node, dict) or part not in node:
            return default
        node = node[part]
    if node is None:
        return default
    return node


def parse_date(value):
    """Parse an ISO date/datetime string or Backstory's display text
    ("Nov 28, 2026", "November 28, 2026") into a date. Returns None for
    anything that doesn't parse (never guesses)."""
    if value is None or not isinstance(value, str):
        return None
    text = value.strip()
    if not text:
        return None

    iso_match = re.match(r"^(\d{4}-\d{2}-\d{2})", text)
    if iso_match:
        try:
            return datetime.strptime(iso_match.group(1), "%Y-%m-%d").date()
        except ValueError:
            return None

    for fmt in ("%b %d, %Y", "%B %d, %Y"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue

    return None


def title_matches(title, word_list):
    """Whole-word, case-insensitive match of any word in word_list against title."""
    if not title or not word_list:
        return False
    for word in word_list:
        if not word:
            continue
        pattern = r"\b" + re.escape(word) + r"\b"
        if re.search(pattern, title, re.IGNORECASE):
            return True
    return False


def determine_quiet_state(judgment, quiet_days, as_of_date):
    """Derive quiet / active / unknown from the judgment's dated activity evidence."""
    if not isinstance(judgment, dict):
        return "unknown"
    if judgment.get("activityUnknown"):
        return "unknown"
    last = parse_date(judgment.get("lastActivityDate"))
    if last is None:
        # No usable activity date recorded: leans flagged, not healthy.
        return "quiet"
    days = (as_of_date - last).days
    if days < 0:
        days = 0
    if days >= quiet_days:
        return "quiet"
    return "active"


def determine_decision_maker_state(judgment, decision_titles, exclude_titles):
    """Derive present / absent / unknown from the judgment's external engaged
    people, filtered by thresholds.decisionMakerTitles and thresholds.excludeTitles."""
    if not isinstance(judgment, dict):
        return "unknown"
    if judgment.get("peopleUnknown"):
        return "unknown"
    people = judgment.get("engagedPeople")
    if not isinstance(people, list):
        return "unknown"
    for person in people:
        if not isinstance(person, dict):
            continue
        if person.get("side") != "external":
            continue
        title = person.get("title") or ""
        if title_matches(title, exclude_titles):
            continue
        if title_matches(title, decision_titles):
            return "present"
    return "absent"


def normalize_evidence(evidence):
    if not isinstance(evidence, list):
        return []
    out = []
    for e in evidence:
        if not isinstance(e, dict):
            continue
        out.append({
            "date": e.get("date"),
            "kind": e.get("kind"),
            "text": e.get("text"),
            "source": e.get("source"),
        })
    return out


def normalize_findings(findings):
    if not isinstance(findings, list):
        return []
    out = []
    for f in findings[:6]:
        if not isinstance(f, dict):
            continue
        out.append({
            "area": f.get("area"),
            "status": f.get("status"),
            "finding": f.get("finding"),
            "evidence": normalize_evidence(f.get("evidence")),
            "explanation": f.get("explanation"),
        })
    return out


def normalize_actions(actions):
    if not isinstance(actions, list):
        return []
    out = []
    for a in actions[:3]:
        if not isinstance(a, dict):
            continue
        out.append({
            "title": a.get("title"),
            "who": a.get("who"),
            "by": a.get("by"),
            "why": a.get("why"),
            "steps": a.get("steps"),
        })
    return out


def as_number(value):
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return value
    return None


class CalibrationError(Exception):
    """Raised when the level spread exceeds a calibration ceiling (exit 5)."""

    def __init__(self, message, report_lines):
        super().__init__(message)
        self.report_lines = report_lines


def run(data, settings, as_of):
    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object with 'population' and 'judgments' keys.")

    population = data.get("population")
    judgments = data.get("judgments")

    if not isinstance(population, list):
        raise ValueError("'population' must be a list of items.")
    if not isinstance(judgments, list):
        raise ValueError("'judgments' must be a list of judgment objects.")

    as_of_date = parse_date(as_of)
    if as_of_date is None:
        raise ValueError("as_of must be a parseable YYYY-MM-DD date.")

    quiet_days = get_setting(settings, "thresholds.quietDays", 14)
    decision_titles = get_setting(settings, "thresholds.decisionMakerTitles", [])
    exclude_titles = get_setting(settings, "thresholds.excludeTitles", [])
    critical_max_pct = get_setting(settings, "calibration.criticalMaxPct", None)
    high_max_pct = get_setting(settings, "calibration.highMaxPct", None)
    medium_max_pct = get_setting(settings, "calibration.mediumMaxPct", None)
    client_name = get_setting(settings, "client.name", None)
    client_currency = get_setting(settings, "client.currency", None)
    artifact_url = get_setting(settings, "output.artifactUrl", None)
    file_path = get_setting(settings, "output.filePath", None)

    report = []

    # Index judgments by id; require every population item to have one.
    judgments_by_id = {}
    for j in judgments:
        if isinstance(j, dict) and j.get("id") is not None:
            judgments_by_id[j.get("id")] = j

    missing = []
    for item in population:
        if not isinstance(item, dict):
            continue
        item_id = item.get("id")
        if item_id not in judgments_by_id:
            missing.append(item_id)

    if missing:
        raise ValueError(
            "Missing judgment file(s) for item(s): " + ", ".join(str(m) for m in missing)
        )

    assembled_items = []
    unknown_activity_count = 0
    unknown_engaged_count = 0
    amount_present_count = 0
    amount_missing_count = 0

    for item in population:
        item_id = item.get("id")
        judgment = judgments_by_id.get(item_id, {})

        quiet_state = determine_quiet_state(judgment, quiet_days, as_of_date)
        dm_state = determine_decision_maker_state(judgment, decision_titles, exclude_titles)

        if quiet_state == "unknown":
            unknown_activity_count += 1
        if dm_state == "unknown":
            unknown_engaged_count += 1

        level = COMBINATION_TABLE.get((quiet_state, dm_state), "medium")

        amount = as_number(item.get("amount"))
        if amount is not None:
            amount_present_count += 1
        else:
            amount_missing_count += 1

        assembled_items.append({
            "id": item_id,
            "name": item.get("name"),
            "level": level,
            "headline": judgment.get("headline") if isinstance(judgment, dict) else None,
            "assessment": judgment.get("assessment") if isinstance(judgment, dict) else None,
            "subtitle": judgment.get("subtitle") if isinstance(judgment, dict) else None,
            "group": item.get("owner"),
            "value": amount,
            "date": item.get("closeDate"),
            "facts": [
                {"label": "Owner", "value": item.get("owner")},
                {"label": "Stage", "value": item.get("stage")},
                {"label": "Close date", "value": item.get("closeDate")},
                {"label": "Amount", "value": amount},
            ],
            "findings": normalize_findings(judgment.get("findings")) if isinstance(judgment, dict) else [],
            "actions": normalize_actions(judgment.get("actions")) if isinstance(judgment, dict) else [],
            "_quietState": quiet_state,
        })

    total_kept = len(assembled_items)
    level_counts = Counter(i["level"] for i in assembled_items)

    # Calibration check: each level's share of kept items against its ceiling.
    # Only meaningful once the population is large enough that a single item
    # doesn't blow past every ceiling on its own.
    ceilings = {
        "critical": critical_max_pct,
        "high": high_max_pct,
        "medium": medium_max_pct,
    }
    boundary_levels = []
    if total_kept >= MIN_ITEMS_FOR_CALIBRATION:
        for level_name, ceiling in ceilings.items():
            if ceiling is None:
                continue
            pct = (level_counts.get(level_name, 0) / total_kept) * 100
            if pct > ceiling:
                boundary_levels.append((level_name, pct, ceiling))

    if boundary_levels:
        boundary_ids = [
            i["id"] for i in assembled_items if i["level"] in [b[0] for b in boundary_levels]
        ]
        calib_report = []
        for level_name, pct, ceiling in boundary_levels:
            calib_report.append(
                "Calibration check failed: {} deals are {} ({:.1f}%), above the {}% ceiling. "
                "Re-check boundary items: {}".format(
                    level_counts.get(level_name, 0), level_name, pct, ceiling,
                    ", ".join(str(b) for b in boundary_ids) if boundary_ids else "none"
                )
            )
        raise CalibrationError(
            "Level spread exceeds calibration ceiling(s): " + "; ".join(
                "{} {:.1f}% > {}%".format(l, p, c) for l, p, c in boundary_levels
            ),
            report_lines=calib_report,
        )

    # Report fallbacks and degraded-tool signals first.
    if unknown_activity_count:
        report.append(
            "{} of {} deals have unknown activity data (tool returned no usable result); "
            "treated as unknown, never as healthy.".format(unknown_activity_count, total_kept)
        )
    if unknown_engaged_count:
        report.append(
            "{} of {} deals have unknown decision-maker data (tool returned no usable result "
            "or a 403); treated as unknown, never as healthy.".format(unknown_engaged_count, total_kept)
        )

    # Metrics (up to 4).
    metrics = [
        {"label": "Critical deals", "value": level_counts.get("critical", 0)},
        {"label": "High risk deals", "value": level_counts.get("high", 0)},
        {"label": "Deals reviewed", "value": total_kept},
    ]
    if amount_present_count > 0:
        value_at_risk = sum(
            i["value"] for i in assembled_items
            if i["level"] in ("critical", "high") and i["value"] is not None
        )
        metrics.append({"label": "Value at risk", "value": value_at_risk})
        if amount_missing_count:
            report.append(
                "Amount is missing on {} of {} deals; value at risk reflects only the deals "
                "where it was present.".format(amount_missing_count, total_kept)
            )
    else:
        report.append(
            "Amount field returned no values for any deal; the value-at-risk metric is omitted."
        )

    # Summary lines (up to 4).
    summary = [
        "{} of {} open deals closing this quarter are rated critical or high.".format(
            level_counts.get("critical", 0) + level_counts.get("high", 0), total_kept
        ),
        "{} deals are quiet past the {}-day threshold.".format(
            sum(1 for i in assembled_items if i["_quietState"] == "quiet"),
            quiet_days,
        ),
    ]

    report.append(
        "Level spread: {}.".format(
            ", ".join("{} {}".format(l, level_counts.get(l, 0)) for l in LEVELS)
        )
    )
    if artifact_url:
        report.append("Brief published to: {}".format(artifact_url))
    elif file_path:
        report.append("Brief written to: {}".format(file_path))
    else:
        report.append("No output.artifactUrl or output.filePath configured; brief location not recorded.")

    # Strip internal helper key before writing the final shape.
    for i in assembled_items:
        i.pop("_quietState", None)

    data_json = {
        "meta": {
            "title": "Quarterly deal risk brief",
            "question": (
                "Which of my team's open deals closing this quarter have gone quiet or lack "
                "an engaged decision-maker, and what should I ask each rep about them in our 1:1?"
            ),
            "asOf": as_of,
            "org": client_name,
            "shownLevels": ["critical", "high", "medium", "low"],
            "listTitle": "Open deals closing this quarter",
            "groupLabel": "Owner",
            "valueLabel": "Amount",
            "dateLabel": "Close date",
            "currency": client_currency,
            "scope": [],
            "sources": [
                "get_opportunity_status",
                "get_recent_opportunity_activity",
                "get_opportunity_engaged_people",
                "get_opportunity_scorecard",
                "ask_sales_ai_about_opportunity",
            ],
        },
        "summary": summary[:4],
        "metrics": metrics[:4],
        "items": assembled_items,
        "output": {
            "artifactUrl": artifact_url,
            "filePath": file_path,
        },
        "report": report,
    }

    return data_json


def main(argv):
    parser = argparse.ArgumentParser(description="Assemble the quarterly deal risk brief data.json.")
    parser.add_argument("input", help="Path to the input JSON file.")
    parser.add_argument("--out", required=True, help="Path to write the output JSON file.")
    parser.add_argument("--as-of", default=None, help="YYYY-MM-DD (default: today).")
    parser.add_argument("--settings", default=None, help="Path to settings.json.")
    args = parser.parse_args(argv)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    settings_path = args.settings or os.path.join(script_dir, "..", "settings.json")

    try:
        with open(args.input, "r") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        print("Could not read input file: {}".format(exc), file=sys.stderr)
        return 1

    try:
        with open(settings_path, "r") as f:
            settings = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        print("Could not read settings file: {}".format(exc), file=sys.stderr)
        return 1

    as_of = args.as_of or date.today().isoformat()

    try:
        result = run(data, settings, as_of)
    except CalibrationError as exc:
        for line in exc.report_lines:
            print(line)
        print(str(exc), file=sys.stderr)
        return 5
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    with open(args.out, "w") as f:
        json.dump(result, f, indent=2)

    for line in result.get("report", []):
        print(line)

    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
