"""Resolve fields, apply scope rules, and produce the in-scope population of
quarter opportunities before any judgment happens.

Usage:
    python3 population.py records.json --out population.json [--as-of YYYY-MM-DD] [--settings settings.json]

Input JSON shape:
    {"records": [records exactly as fetch_records returned them], "previousCount": number or null}
"""

import argparse
import calendar
import json
import os
import re
import sys
from datetime import date, datetime, timedelta


class KeptEmptyError(Exception):
    """Raised when the kept population is empty (valid input, nothing to report)."""


class CountChangeError(Exception):
    """Raised when the kept count moved too much from the previous run's count."""


# ---------------------------------------------------------------------------
# small settings helpers
# ---------------------------------------------------------------------------

def dig(settings, path):
    """Walk a dotted path in a dict; a missing key or an explicit null both
    return None."""
    parts = path.split(".")
    cur = settings
    for p in parts:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(p)
        if cur is None:
            return None
    return cur


# ---------------------------------------------------------------------------
# date parsing
# ---------------------------------------------------------------------------

_ISO_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})")


def parse_date(value):
    """Parse an ISO date (with or without a time) or Backstory's display
    text ("Nov 28, 2026" / "November 28, 2026"). Returns a date or None."""
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    m = _ISO_RE.match(s)
    if m:
        try:
            return datetime.strptime(m.group(1), "%Y-%m-%d").date()
        except ValueError:
            pass
    for fmt in ("%b %d, %Y", "%B %d, %Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


def add_months(d, months):
    month_index = d.month - 1 + months
    year = d.year + month_index // 12
    month = month_index % 12 + 1
    day = min(d.day, calendar.monthrange(year, month)[1])
    return date(year, month, day)


def compute_quarter(as_of_date, fiscal_year_start_month):
    """Return (quarter_start, quarter_end) dates containing as_of_date,
    given the month (1-12) the fiscal year starts."""
    fy_month = fiscal_year_start_month
    if not isinstance(fy_month, int) or fy_month < 1 or fy_month > 12:
        fy_month = 1

    fy_start = date(as_of_date.year, fy_month, 1)
    if as_of_date < fy_start:
        fy_start = date(as_of_date.year - 1, fy_month, 1)

    months_elapsed = (as_of_date.year - fy_start.year) * 12 + (as_of_date.month - fy_start.month)
    quarter_index = months_elapsed // 3
    q_start = add_months(fy_start, quarter_index * 3)
    q_end = add_months(fy_start, quarter_index * 3 + 3) - timedelta(days=1)
    return q_start, q_end


# ---------------------------------------------------------------------------
# field resolution
# ---------------------------------------------------------------------------

ID_KEYS = ("Id", "ID", "id", "OpportunityId", "Opportunity Id", "CRM ID", "crmId")


def get_record_id(rec):
    for key in ID_KEYS:
        if key in rec and rec[key] not in (None, ""):
            return str(rec[key])
    return None


def resolve_field_map(records, settings):
    """For each field in settings.fields, find the first name (in order)
    that appears with a non-null value on at least one record. Returns
    (field_map, field_specs, report_lines)."""
    field_names = ["closeDate", "stage", "owner", "amount", "type"]
    field_map = {}
    field_specs = {}
    report = []

    for field_name in field_names:
        spec = dig(settings, "fields." + field_name) or {}
        names = spec.get("names") or []
        required = bool(spec.get("required", False))
        field_specs[field_name] = {"names": names, "required": required}

        resolved_name = None
        for name in names:
            for rec in records:
                if isinstance(rec, dict) and name in rec and rec[name] is not None:
                    resolved_name = name
                    break
            if resolved_name:
                break

        field_map[field_name] = resolved_name

        if resolved_name is None:
            if required:
                report.append(
                    "Required field '%s': no matching name found among %s." % (field_name, names)
                )
            else:
                report.append(
                    "Optional field '%s': no matching name found among %s; omitted." % (field_name, names)
                )
        elif names and resolved_name != names[0]:
            report.append(
                "Field '%s': used fallback name '%s' (primary '%s' not found)."
                % (field_name, resolved_name, names[0])
            )

    return field_map, field_specs, report


# ---------------------------------------------------------------------------
# main population logic
# ---------------------------------------------------------------------------

def dedupe_records(records):
    """De-duplicate by Backstory ID, keeping the most complete record
    (most non-null top-level values) when duplicates appear. Records with
    no resolvable id are kept as their own unique entries."""
    by_id = {}
    order = []
    unidentified = []

    def completeness(rec):
        return sum(1 for v in rec.values() if v is not None)

    for rec in records:
        if not isinstance(rec, dict):
            continue
        rid = get_record_id(rec)
        if rid is None:
            unidentified.append(rec)
            continue
        if rid not in by_id:
            by_id[rid] = rec
            order.append(rid)
        else:
            if completeness(rec) > completeness(by_id[rid]):
                by_id[rid] = rec

    deduped = [(rid, by_id[rid]) for rid in order]
    for rec in unidentified:
        deduped.append((None, rec))
    return deduped


def run(data, settings, as_of):
    if not isinstance(data, dict):
        raise ValueError("Input must be a JSON object with a 'records' key.")

    if "records" not in data:
        raise ValueError("Input is missing required key 'records'.")
    records = data["records"]
    if not isinstance(records, list):
        raise ValueError("Input 'records' must be a list.")

    previous_count = data.get("previousCount", None)
    if previous_count is not None and not isinstance(previous_count, (int, float)):
        raise ValueError("Input 'previousCount' must be a number or null.")

    try:
        as_of_date = datetime.strptime(as_of, "%Y-%m-%d").date()
    except (ValueError, TypeError):
        raise ValueError("as_of must be a YYYY-MM-DD date string.")

    fetched = len(records)
    report = []

    # resolve fields and report fallbacks/missing fields first
    field_map, field_specs, field_report = resolve_field_map(
        [r for r in records if isinstance(r, dict)], settings
    )
    report.extend(field_report)

    fiscal_start_month = dig(settings, "scope.fiscalYearStartMonth")
    if not isinstance(fiscal_start_month, int):
        fiscal_start_month = 1
    q_start, q_end = compute_quarter(as_of_date, fiscal_start_month)
    report.append(
        "Scoped to current quarter: %s to %s (fiscal year starts month %s)."
        % (q_start.isoformat(), q_end.isoformat(), fiscal_start_month)
    )

    exclude_stages = dig(settings, "scope.excludeStages")
    if not isinstance(exclude_stages, list):
        exclude_stages = []
    exclude_stages_norm = {str(s).strip().lower() for s in exclude_stages}

    team_owners = dig(settings, "scope.teamOwners")
    team_owners_set = None
    if isinstance(team_owners, list):
        team_owners_set = {str(o).strip() for o in team_owners}

    deduped = dedupe_records(records)
    dropped_as_dupe = fetched - len(deduped)

    items = []
    drops = []
    owners_seen = set()

    for rid, rec in deduped:
        if not isinstance(rec, dict):
            drops.append({"id": rid, "reason": "record was not an object"})
            continue

        if rid is None:
            drops.append({"id": None, "reason": "missing Backstory id"})
            continue

        close_field_name = field_map.get("closeDate")
        stage_field_name = field_map.get("stage")
        owner_field_name = field_map.get("owner")
        amount_field_name = field_map.get("amount")
        type_field_name = field_map.get("type")

        raw_close_date = rec.get(close_field_name) if close_field_name else None
        raw_stage = rec.get(stage_field_name) if stage_field_name else None
        raw_owner = rec.get(owner_field_name) if owner_field_name else None
        raw_amount = rec.get(amount_field_name) if amount_field_name else None
        raw_type = rec.get(type_field_name) if type_field_name else None

        if raw_close_date is None:
            drops.append({"id": rid, "reason": "missing closeDate"})
            continue
        parsed_close = parse_date(raw_close_date)
        if parsed_close is None:
            drops.append({"id": rid, "reason": "unparseable closeDate '%s'" % raw_close_date})
            continue

        if raw_stage is None:
            drops.append({"id": rid, "reason": "missing stage"})
            continue
        if str(raw_stage).strip().lower() in exclude_stages_norm:
            drops.append({"id": rid, "reason": "excluded stage '%s'" % raw_stage})
            continue

        if raw_owner is None:
            drops.append({"id": rid, "reason": "missing owner"})
            continue

        if not (q_start <= parsed_close <= q_end):
            drops.append({"id": rid, "reason": "closeDate not in current quarter"})
            continue

        owner_str = str(raw_owner).strip()
        owners_seen.add(owner_str)

        if team_owners_set is not None and owner_str not in team_owners_set:
            drops.append({"id": rid, "reason": "owner '%s' not in scope.teamOwners" % owner_str})
            continue

        items.append(
            {
                "id": rid,
                "name": rec.get("Name") or rec.get("Opportunity Name"),
                "owner": owner_str,
                "stage": raw_stage,
                "closeDate": raw_close_date,
                "amount": raw_amount,
                "type": raw_type,
                "record": rec,
            }
        )

    if dropped_as_dupe:
        report.append("De-duplicated %d record(s) sharing a Backstory id." % dropped_as_dupe)

    if team_owners_set is None:
        report.append(
            "scope.teamOwners is null: every owner Backstory returned is included: %s."
            % ", ".join(sorted(owners_seen)) if owners_seen else "none found"
        )

    groups = {}
    for item in items:
        groups.setdefault(item["owner"], []).append(item["id"])

    kept = len(items)
    dropped = fetched - kept
    counts = {"fetched": fetched, "kept": kept, "dropped": dropped}
    report.append("Fetched %d, kept %d, dropped %d." % (fetched, kept, dropped))

    result = {
        "items": items,
        "drops": drops,
        "counts": counts,
        "fieldMap": field_map,
        "groups": groups,
        "report": report,
    }

    if kept == 0:
        raise KeptEmptyError("No deals kept in scope out of %d fetched." % fetched)

    max_pct = dig(settings, "thresholds.maxCountChangePct")
    if not isinstance(max_pct, (int, float)):
        max_pct = 30

    if previous_count is not None:
        if previous_count == 0:
            if kept != 0:
                raise CountChangeError(
                    "Kept count moved from previous 0 to %d; cannot compute a percentage change." % kept
                )
        else:
            change_pct = abs(kept - previous_count) / float(previous_count) * 100.0
            if change_pct > max_pct:
                raise CountChangeError(
                    "Kept count %d differs from previous count %s by %.1f%%, "
                    "more than the allowed %.1f%%." % (kept, previous_count, change_pct, max_pct)
                )

    return result


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _default_settings_path():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(here, "..", "settings.json")


def main(argv):
    parser = argparse.ArgumentParser(description="Resolve fields and apply scope to fetched opportunities.")
    parser.add_argument("input", help="path to the input JSON file")
    parser.add_argument("--out", required=True, help="path to write the output JSON file")
    parser.add_argument("--as-of", default=None, help="YYYY-MM-DD, default today")
    parser.add_argument("--settings", default=None, help="path to settings.json")
    args = parser.parse_args(argv)

    as_of = args.as_of or date.today().isoformat()
    settings_path = args.settings or _default_settings_path()

    try:
        with open(args.input, "r") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        sys.stderr.write("Could not read input file: %s\n" % exc)
        return 1

    try:
        with open(settings_path, "r") as f:
            settings = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        sys.stderr.write("Could not read settings file: %s\n" % exc)
        return 1

    try:
        result = run(data, settings, as_of)
    except KeptEmptyError as exc:
        sys.stderr.write(str(exc) + "\n")
        return 3
    except CountChangeError as exc:
        sys.stderr.write(str(exc) + "\n")
        return 4
    except ValueError as exc:
        sys.stderr.write(str(exc) + "\n")
        return 1

    with open(args.out, "w") as f:
        json.dump(result, f, indent=2)

    for line in result.get("report", []):
        print(line)

    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
