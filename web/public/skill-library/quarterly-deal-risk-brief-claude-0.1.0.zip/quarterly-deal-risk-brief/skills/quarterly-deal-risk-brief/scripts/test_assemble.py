import datetime
import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(__file__))

from assemble import run, main  # noqa: E402

SETTINGS_PATH = os.path.join(os.path.dirname(__file__), "..", "settings.json")
with open(SETTINGS_PATH) as f:
    SETTINGS = json.load(f)

AS_OF = "2026-12-01"
AS_OF_DATE = datetime.date(2026, 12, 1)
QUIET_DAYS = SETTINGS["thresholds"]["quietDays"]

OLD_DATE = (AS_OF_DATE - datetime.timedelta(days=QUIET_DAYS + 5)).isoformat()
RECENT_DATE = (AS_OF_DATE - datetime.timedelta(days=max(QUIET_DAYS - 5, 1))).isoformat()


def make_population_item(id_, owner="Jane Rep", amount=50000, name=None):
    return {
        "id": id_,
        "name": name or ("Deal " + id_),
        "owner": owner,
        "amount": amount,
        "closeDate": "2026-12-15",
        "stage": "Negotiation",
    }


def make_judgment(id_, last_activity_date=None, activity_unknown=False,
                   engaged_people=None, people_unknown=False):
    return {
        "id": id_,
        "lastActivityDate": last_activity_date,
        "activityUnknown": activity_unknown,
        "engagedPeople": engaged_people if engaged_people is not None else [],
        "peopleUnknown": people_unknown,
    }


def run_main_with_temp(data, settings=None):
    with tempfile.TemporaryDirectory() as d:
        input_path = os.path.join(d, "input.json")
        out_path = os.path.join(d, "output.json")
        settings_path = os.path.join(d, "settings.json")
        with open(input_path, "w") as f:
            json.dump(data, f)
        with open(settings_path, "w") as f:
            json.dump(settings if settings is not None else SETTINGS, f)
        argv = [input_path, "--out", out_path, "--as-of", AS_OF, "--settings", settings_path]
        code = main(argv)
        output = None
        if os.path.exists(out_path):
            with open(out_path) as f:
                output = json.load(f)
        return code, output


class TestAssembleRun(unittest.TestCase):

    def test_missing_judgment_raises_value_error_naming_item(self):
        population = [make_population_item("OPP1")]
        judgments = []
        with self.assertRaises(ValueError) as cm:
            run({"population": population, "judgments": judgments}, SETTINGS, AS_OF)
        self.assertIn("OPP1", str(cm.exception))

    def test_main_exits_1_for_missing_judgment(self):
        data = {"population": [make_population_item("OPP1")], "judgments": []}
        code, _ = run_main_with_temp(data)
        self.assertEqual(code, 1)

    def test_empty_judgments_with_nonempty_population_raises(self):
        population = [make_population_item("OPP1"), make_population_item("OPP2")]
        with self.assertRaises(ValueError):
            run({"population": population, "judgments": []}, SETTINGS, AS_OF)

    def test_empty_judgments_with_nonempty_population_exits_1(self):
        data = {
            "population": [make_population_item("OPP1"), make_population_item("OPP2")],
            "judgments": [],
        }
        code, _ = run_main_with_temp(data)
        self.assertEqual(code, 1)

    def test_quiet_and_absent_decision_maker_is_critical(self):
        population = [make_population_item("OPP1")]
        judgments = [
            make_judgment(
                "OPP1",
                last_activity_date=OLD_DATE,
                engaged_people=[{"name": "Bob", "title": "Manager", "side": "external"}],
            )
        ]
        result = run({"population": population, "judgments": judgments}, SETTINGS, AS_OF)
        item = next(i for i in result["items"] if i["id"] == "OPP1")
        self.assertEqual(item["level"], "critical")

    def test_active_and_present_decision_maker_is_low(self):
        population = [make_population_item("OPP1")]
        judgments = [
            make_judgment(
                "OPP1",
                last_activity_date=RECENT_DATE,
                engaged_people=[{"name": "Alice", "title": "VP of Sales", "side": "external"}],
            )
        ]
        result = run({"population": population, "judgments": judgments}, SETTINGS, AS_OF)
        item = next(i for i in result["items"] if i["id"] == "OPP1")
        self.assertEqual(item["level"], "low")

    def test_active_and_unknown_decision_maker_is_medium_not_low(self):
        population = [make_population_item("OPP1")]
        judgments = [
            make_judgment(
                "OPP1",
                last_activity_date=RECENT_DATE,
                people_unknown=True,
            )
        ]
        result = run({"population": population, "judgments": judgments}, SETTINGS, AS_OF)
        item = next(i for i in result["items"] if i["id"] == "OPP1")
        self.assertEqual(item["level"], "medium")
        self.assertNotEqual(item["level"], "low")

    def test_quiet_and_unknown_decision_maker_is_high(self):
        population = [make_population_item("OPP1")]
        judgments = [
            make_judgment(
                "OPP1",
                last_activity_date=OLD_DATE,
                people_unknown=True,
            )
        ]
        result = run({"population": population, "judgments": judgments}, SETTINGS, AS_OF)
        item = next(i for i in result["items"] if i["id"] == "OPP1")
        self.assertEqual(item["level"], "high")

    def test_calibration_breach_exits_5_naming_boundary_items(self):
        ids = ["OPP1", "OPP2", "OPP3", "OPP4", "OPP5"]
        population = [make_population_item(i) for i in ids]
        judgments = [
            make_judgment(
                i,
                last_activity_date=OLD_DATE,
                engaged_people=[{"name": "Bob", "title": "Manager", "side": "external"}],
            )
            for i in ids
        ]
        data = {"population": population, "judgments": judgments}
        code, _ = run_main_with_temp(data)
        self.assertEqual(code, 5)

    def test_missing_amount_does_not_stop_run_and_is_reported(self):
        population = [make_population_item("OPP1", amount=None)]
        judgments = [
            make_judgment(
                "OPP1",
                last_activity_date=RECENT_DATE,
                engaged_people=[{"name": "Alice", "title": "VP", "side": "external"}],
            )
        ]
        result = run({"population": population, "judgments": judgments}, SETTINGS, AS_OF)
        item = next(i for i in result["items"] if i["id"] == "OPP1")
        self.assertIsNotNone(item)
        self.assertTrue(
            any("amount" in line.lower() for line in result["report"]),
            "expected a report line mentioning the missing amount",
        )

    def test_output_is_json_serializable(self):
        population = [make_population_item("OPP1")]
        judgments = [
            make_judgment(
                "OPP1",
                last_activity_date=RECENT_DATE,
                engaged_people=[{"name": "Alice", "title": "VP", "side": "external"}],
            )
        ]
        result = run({"population": population, "judgments": judgments}, SETTINGS, AS_OF)
        serialized = json.dumps(result)
        self.assertIsInstance(serialized, str)


if __name__ == "__main__":
    unittest.main()
