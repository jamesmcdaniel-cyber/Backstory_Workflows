import os
import sys
import json
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from population import run, main  # noqa: E402

SETTINGS_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "settings.json"
)


def load_settings():
    with open(SETTINGS_PATH) as f:
        return json.load(f)


def run_main(data, as_of="2026-11-15", settings_path=SETTINGS_PATH):
    with tempfile.TemporaryDirectory() as d:
        input_path = os.path.join(d, "input.json")
        output_path = os.path.join(d, "output.json")
        with open(input_path, "w") as f:
            json.dump(data, f)
        argv = [
            input_path,
            "--out",
            output_path,
            "--as-of",
            as_of,
        ]
        if settings_path:
            argv += ["--settings", settings_path]
        rc = main(argv)
        output = None
        if os.path.exists(output_path):
            with open(output_path) as f:
                output = json.load(f)
        return rc, output


class TestPopulation(unittest.TestCase):
    def setUp(self):
        self.settings = load_settings()
        self.as_of = "2026-11-15"  # Q4 2026 under calendar fiscal year

    # 1. Empty records -> exit 3
    def test_empty_records_exit3(self):
        rc, output = run_main({"records": [], "previousCount": None})
        self.assertEqual(rc, 3)

    # 2. Stage field absent under first name, present under fallback
    def test_stage_fallback_used(self):
        record = {
            "Id": "OPP-001",
            "Stage": "Open",
            "CloseDate": "2026-11-20",
            "OwnerName": "Alice",
        }
        result = run(
            {"records": [record], "previousCount": None}, self.settings, self.as_of
        )
        self.assertEqual(result["counts"]["kept"], 1)
        # the fallback name "Stage" must appear somewhere in fieldMap
        field_map_str = json.dumps(result["fieldMap"])
        self.assertIn("Stage", field_map_str)
        # and the fallback use should be reported
        report_str = " ".join(result["report"]).lower()
        self.assertIn("stage", report_str)
        self.assertIn("fallback", report_str)

    # 3. scope.teamOwners null -> every owner kept and listed in report
    def test_team_owners_null_keeps_all(self):
        settings = json.loads(json.dumps(self.settings))
        settings["scope"]["teamOwners"] = None
        records = [
            {
                "Id": "OPP-010",
                "StageName": "Open",
                "CloseDate": "2026-11-05",
                "OwnerName": "Alice",
            },
            {
                "Id": "OPP-011",
                "StageName": "Negotiation",
                "CloseDate": "2026-11-06",
                "OwnerName": "Bob",
            },
        ]
        result = run(
            {"records": records, "previousCount": None}, settings, self.as_of
        )
        self.assertEqual(result["counts"]["kept"], 2)
        report_str = " ".join(result["report"])
        self.assertIn("Alice", report_str)
        self.assertIn("Bob", report_str)

    # 4. Close date as display text ("Nov 28, 2026") parsed correctly
    def test_close_date_display_text_parsed(self):
        record = {
            "Id": "OPP-020",
            "StageName": "Open",
            "CloseDate": "Nov 28, 2026",
            "OwnerName": "Carol",
        }
        result = run(
            {"records": [record], "previousCount": None}, self.settings, self.as_of
        )
        self.assertEqual(result["counts"]["kept"], 1)
        ids = [item["id"] for item in result["items"]]
        self.assertIn("OPP-020", ids)

    # 5. Close date on the quarter's last day is kept
    def test_close_date_boundary_last_day_kept(self):
        record = {
            "Id": "OPP-030",
            "StageName": "Open",
            "CloseDate": "Dec 31, 2026",
            "OwnerName": "Dan",
        }
        result = run(
            {"records": [record], "previousCount": None}, self.settings, self.as_of
        )
        self.assertEqual(result["counts"]["kept"], 1)
        ids = [item["id"] for item in result["items"]]
        self.assertIn("OPP-030", ids)

    # 6. Kept count moved by more than maxCountChangePct -> exit 4
    def test_count_change_exceeds_threshold_exit4(self):
        pct = self.settings["thresholds"]["maxCountChangePct"]
        previous_count = 10
        # guarantee the change comfortably exceeds the configured threshold
        target_kept = int(previous_count * (1 + (pct + 20) / 100.0)) + 1
        records = []
        for i in range(target_kept):
            records.append(
                {
                    "Id": "OPP-C-{}".format(i),
                    "StageName": "Open",
                    "CloseDate": "2026-11-10",
                    "OwnerName": "Rep{}".format(i),
                }
            )
        rc, output = run_main(
            {"records": records, "previousCount": previous_count},
            as_of=self.as_of,
        )
        self.assertEqual(rc, 4)

    # 7. Input that isn't an object -> clear error, no partial output
    def test_non_object_input_raises_valueerror(self):
        with self.assertRaises(ValueError):
            run([], self.settings, self.as_of)

        rc, output = run_main([], as_of=self.as_of)
        self.assertEqual(rc, 1)
        self.assertIsNone(output)

    # 8. Duplicate Backstory IDs are de-duplicated
    def test_duplicate_ids_deduplicated(self):
        records = [
            {
                "Id": "OPP-040",
                "StageName": "Open",
                "CloseDate": "2026-11-12",
                "OwnerName": "Eve",
            },
            {
                "Id": "OPP-040",
                "StageName": "Open",
                "CloseDate": "2026-11-12",
                "OwnerName": "Eve",
                "Amount": 5000,
            },
        ]
        result = run(
            {"records": records, "previousCount": None}, self.settings, self.as_of
        )
        self.assertEqual(result["counts"]["kept"], 1)
        self.assertEqual(len(result["items"]), 1)

    # Extra: output must always be JSON-serializable
    def test_output_is_json_serializable(self):
        record = {
            "Id": "OPP-050",
            "StageName": "Open",
            "CloseDate": "2026-11-18",
            "OwnerName": "Frank",
        }
        result = run(
            {"records": [record], "previousCount": None}, self.settings, self.as_of
        )
        try:
            json.dumps(result)
        except (TypeError, ValueError) as exc:
            self.fail("Output is not JSON-serializable: {}".format(exc))


if __name__ == "__main__":
    unittest.main()
