# Actions: Guardrails for 1:1 Questions and Recommended Actions

## Contents
- Purpose and scope
- Who and by date
- Phrasing: questions for the manager, not instructions to the customer
- No commitments on the customer's behalf
- Evidence requirement: actions draw only from written findings
- Ranking and the 3-action limit
- Using settings.moves
- What belongs elsewhere

## Purpose and scope

This file governs how `items/<id>.json` judgments write their `actions` array (up to 3 per deal) before `assemble.py` carries them forward unchanged. Actions are 1:1 talking points for the sales manager to raise with the rep — never messages, emails, or tasks aimed at the customer. `assemble.py` does not alter, re-rank or re-word actions; whatever is written in the judgment file ships as-is. Get the wording right at judgment time.

## Who and by date

- `who` is always the rep who owns the deal (settings.moves[*].defaultWho is "Rep"). Never name a customer contact as `who`.
- `by` is a date, set only when one of these is known:
  - The deal's `closeDate` field (from population output), when the action concerns closing risk.
  - The deal's next scheduled status check (the weekly cadence of this brief) — phrase as the week of the next run, not a specific calendar date.
- If neither anchor is known, leave `by` null. Never invent a date, and never promise a date on behalf of the customer.
- `by` must never be a date the manager or rep would commit to the customer (e.g. "deal closes by X") — it is when the manager should expect the rep to have addressed the question, not a customer commitment.

## Phrasing: questions for the manager, not instructions to the customer

- Every action's `title` and `steps` must read as something the manager asks the rep, e.g. "Ask [Rep] who the economic buyer is on this deal and whether they've spoken directly." Never "Reach out to [contact]" or "Send [Account] a follow-up."
- Do not phrase an action as a task for the customer side at all. The skill is read-only and never contacts customers (see nonNegotiables); an action that implies customer outreach by the skill itself is out of bounds — rephrase it as a question for the rep to answer or a step for the rep to take.
- Acceptable step verbs: "ask," "confirm with," "have [Rep] walk through," "check whether [Rep] has." Unacceptable: "email," "call," "schedule a meeting with the customer," "tell the customer."

## No commitments on the customer's behalf

- No action text may state or imply a price, discount, term, SLA, or date offered to the customer. These tools and this skill are read-only; nothing here authorizes or drafts a customer-facing commitment.
- If a finding suggests the deal is stuck on pricing or terms, the action asks the rep what the current position is ("Ask [Rep] what pricing conversation has happened and what's outstanding") — it never states what price or term should be offered.
- Draft language the manager might use in the 1:1 is fine; draft language addressed to the customer is not. If a judgment produces customer-facing wording, drop it before writing the action.

## Evidence requirement: actions draw only from dated findings

- An action may only reference a finding already written in that same item's `findings` array (rated medium, high, or critical, each with dated evidence per `references/evidence-guidelines.md`).
- Do not write an action for a signal that has no corresponding finding. If the quietness or decision-maker judgment produced no dated evidence above low, write no action for that area — a low-level item may have zero actions.
- Each action should reference which finding it follows from (by `area`), so the manager can trace the question back to the evidence (e.g. a quiet-deal finding dated to the last activity date; a decision-maker finding citing the engaged-people split).
- Never write an action based on a stale risk from `get_opportunity_status` that predates the current window — check the finding's date before building an action on it, per `references/framework.md`.

## Ranking and the 3-action limit

- Write at most 3 actions per deal.
- Rank candidate actions by the level of the finding they come from: critical first, then high, then medium. Low-level findings do not generate actions.
- When a deal has more eligible findings than 3 slots, keep the 3 highest-level findings' actions; drop the rest. Ties within the same level are kept in the order the findings were written.
- `assemble.py` does not re-rank or trim actions — the judgment file must already respect the 3-action cap and the level ordering before it is written.

## Using settings.moves

- Each action should map to one of `settings.moves` (`reengage_decision_maker`, `reengage_quiet_deal`) when the underlying finding matches that move's purpose; use the move's `label` as the basis for the action's `title` and `defaultWho` for `who`.
- `settings.moves` are examples, not a fixed script: phrase the action naturally for the specific deal's evidence, within the guardrails above, rather than repeating the label verbatim.
- An action that doesn't fit either listed move (e.g. a scorecard gap) may still be written if it follows the same rules: rep-directed, dated where possible, evidence-backed, no customer commitment.

## What belongs elsewhere

- Rating whether a deal is quiet or lacks a decision-maker: `references/framework.md`.
- How evidence is sourced, dated and attributed before it reaches a finding: `references/evidence-guidelines.md`.
- Which tools are called to gather the evidence an action is based on: `references/data-collection.md`.
- Level assignment and calibration across all deals: handled by `scripts/assemble.py`, not by this file.
