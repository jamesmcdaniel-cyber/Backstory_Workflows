# Data Collection

## Contents
- List query: preview and fetch
- Date parsing
- Per-deal tool calls
- Fallbacks on 403
- 30-day reliability limits

## List query: preview and fetch

Call `preview_records` first, every run.
- object_type: `"opportunity"`
- query text: `"open opportunities closing this quarter"`
- Relay the count and the filter plan it reports. On an interactive run, stop and wait for confirmation. On a scheduled run, skip the wait: compare the returned count against the previous run's kept count instead, and let `population.py` apply `thresholds.maxCountChangePct`.
- Read the filter plan text exactly as returned. If it shows a rewritten date range (for example "next 90 days" instead of "this quarter") or a Stage filter standing in for a renewal/forecast word, note this first in the run report. Do not treat the plan as confirmation that scope is correct — scope is enforced in `population.py`, never trusted from the tool.

Call `fetch_records` with the same object_type and query text as the preview, one calendar month of the fiscal quarter at a time (three calls for a standard quarter), with limit set above each month's previewed count.
- object_type: `"opportunity"`
- query text: `"open opportunities closing this quarter"` (unchanged from preview)
- Save every record from every monthly call, exactly as returned, appended into one `records.json`. Do not de-duplicate or filter here — that is `population.py`'s job.
- Expect preview and fetch to read the same query text differently; report any mismatch between the two filter plans.
- If a field the skill needs is missing from a batch of returned records, note it; a newly mapped custom field can take a day or more to appear, and `population.py` reports fallbacks, never this step.

## Date parsing

CloseDate values arrive two ways:
- ISO format (e.g. `2026-11-28`)
- Backstory's display text (e.g. `"Nov 28, 2026"`)

`population.py` parses both formats explicitly; never assume one format across a run, and never compute the fiscal quarter window by hand — it is derived from `scope.fiscalYearStartMonth` and today's date, in code. Any CloseDate that fails to parse is dropped with a reason, not guessed.

## Per-deal tool calls (step 4)

For each kept deal, in batches of about 10:

| Tool | Parameters | Purpose |
|---|---|---|
| `get_opportunity_status` | — (fixed 30 days) | Default risks, next steps, topics |
| `get_recent_opportunity_activity` | days: `thresholds.activityLookbackDays` (explicit on every call, up to 90) | Supplement status with recent summaries |
| `get_opportunity_engaged_people` | — (fixed 30 days) | External/internal people, for decision-maker check |
| `get_opportunity_scorecard` | — | Qualification answers, read as returned, never assumed picklist |
| `ask_sales_ai_about_opportunity` | question: 2-3 targeted questions per deal, each naming the deal and asking about quietness or decision-maker engagement specifically (e.g. "What is the latest buyer-side engagement on this deal and when?") | Analysis the summary tools can't give |

Rules:
- Pass `days` explicitly on `get_recent_opportunity_activity`; if the server returns a shorter window than requested, state the shorter window actually covered in the item's judgment file, never report the requested window as if honored.
- Split `get_opportunity_engaged_people` results into external (customer) and internal (seller) before any decision-maker judgment. Strip every email address. Match titles against `thresholds.decisionMakerTitles` on whole words, excluding `thresholds.excludeTitles`, on external people only.
- Treat `get_opportunity_status`'s listed risks as possibly stale: check each risk's date before counting it as current evidence.
- Call `ask_sales_ai_about_opportunity` once per deal with 2-3 questions in a single call where possible; never more than 2-3 per deal. Report its text as "Backstory's assistant," never as the customer's own words, and never as "Sales AI."

## Fallbacks on 403

Any of `get_opportunity_engaged_people`, `get_opportunity_scorecard`, or `ask_sales_ai_about_opportunity` can return 403 on some tenants.

- On a 403 from `get_opportunity_engaged_people`: decision-maker presence is rated `unknown`, not `absent`. Note the 403 first in the run report and in that deal's judgment file.
- On a 403 from `get_opportunity_scorecard`: skip it for that deal; do not infer qualification from other tools. Note it in the report.
- On a 403 from `ask_sales_ai_about_opportunity`: proceed with status and activity evidence only; note the gap in the deal's judgment file as "assistant analysis unavailable," not as a finding.
- A 403 never stops the run for that deal or any other. It is reported once per affected tool, not per deal, unless the pattern differs by deal.

## 30-day reliability limits

- `get_opportunity_status`, `get_opportunity_engaged_people`, and `ask_sales_ai_about_opportunity` all see a fixed last-30-days window regardless of any setting.
- `get_recent_opportunity_activity` accepts `days` up to 90, but Backstory is only reliable for the last 30 days; never treat activity or silence beyond 30 days as evidence that something did or didn't happen.
- If the server returns fewer days of activity than `thresholds.activityLookbackDays` requested, the item's judgment file and the run report must state the shorter window actually covered, not the requested value.
- Absence of activity in the reliable window is evidence toward "quiet," per the quiet-days rule in `thresholds.quietDays`; absence of activity beyond 30 days is never evidence of anything and must not be cited.
