# Framework: Rating Open Deals for Quietness and Decision-Maker Engagement

## Contents
- Two judged areas
- Activity quietness: evidence and rating
- Decision-maker engagement: evidence and rating
- Handling 403s and missing signals
- Which way missing data leans
- Stale risks from status tools
- Fixed level rule table
- What belongs elsewhere

## Two judged areas

Rate each in-scope deal on exactly two areas. Do not invent a third area and do not fold other signals (amount, stage, scorecard content) into these two ratings; they are context, not inputs to the level.

1. **Activity quietness** — has the deal gone quiet, judged against `thresholds.quietDays`?
2. **Decision-maker engagement** — is an external decision-maker currently engaged, judged against `thresholds.decisionMakerTitles` and `thresholds.excludeTitles`?

Each area produces a rating that `scripts/assemble.py` combines using the fixed rule table below. The assistant writes the rating and its dated evidence into `items/<id>.json`; it never assigns the final critical/high/medium/low level itself — that is `assemble.py`'s output and is final.

## Activity quietness: evidence and rating

**Question it answers:** Has meaningful customer-facing activity on this deal stopped for at least `thresholds.quietDays`, within the window Backstory can see (`thresholds.activityLookbackDays`, reliable only for the last 30 days regardless of what is requested)?

**Rating values:** `quiet` or `not quiet`.

| Strength | What counts | Example |
|---|---|---|
| Decisive | `get_recent_opportunity_activity` shows the most recent dated item is older than `thresholds.quietDays` from today, with no newer item in `get_opportunity_status`'s next steps or risks | Last summarized email or meeting dated 20 days ago, quietDays = 14 |
| Strong | `get_opportunity_status` names a risk explicitly describing lack of engagement, dated within the last 30 days | Status risk: "no response since [date]" |
| Early | Only one weekly digest entry exists in the lookback window, with no clear date gap confirmed | A single vague summary with no specific date |
| Healthy | A dated email, meeting, or call inside `thresholds.quietDays` of today, naming a customer-side participant | Meeting summary dated 5 days ago referencing the buyer |

Use `get_opportunity_status` and `get_recent_opportunity_activity` together; treat the activity tool as supplementing status, not replacing it, since activity can be matched to the wrong opportunity. Never write a verbatim quote from either tool — paraphrase and attribute it as "per Backstory's activity summary."

## Decision-maker engagement: evidence and rating

**Question it answers:** Is at least one external (customer-side) person with decision-maker title currently engaged on the deal?

**Rating values:** `present`, `absent`, or `unknown`.

Apply title matching exactly as settings define it:
- Match whole words against `thresholds.decisionMakerTitles` (CEO, CFO, COO, CRO, CIO, CTO, SVP, EVP, VP, President, Chief). "VP" must not match "MVP."
- Exclude any title containing a word in `thresholds.excludeTitles` (Owner, Lead, Head, Manager), even if it also contains a matched word — e.g., "VP, Product Owner" is excluded.
- Only count people returned on the **external** side of `get_opportunity_engaged_people`. Internal (seller-side) titles, including the seller's own VP, never count.

| Strength | What counts | Example |
|---|---|---|
| Decisive | `get_opportunity_engaged_people` lists an external person whose title matches a decision-maker title, with a non-zero email or meeting count in the lookback window | External "VP, Finance" with 2 meetings in 30 days |
| Strong | `ask_sales_ai_about_opportunity` names a specific external decision-maker role as involved, cross-checked against the engaged-people list for the matching name | Backstory's assistant: "the CFO raised budget concerns," name matches an external person on the list |
| Early | A decision-maker title appears in `get_opportunity_status` next steps ("get CFO sign-off") but that person does not yet appear in engaged people | Next step names a title, not yet an engaged contact |
| Healthy | Decisive evidence present, dated within the current lookback window | As above, dated within 30 days |

If a named role or statement from Backstory's assistant cannot be matched to a person on the external engaged-people list, do not credit it as decision-maker presence; note the mismatch in the evidence instead.

## Handling 403s and missing signals

`get_opportunity_engaged_people`, `get_opportunity_scorecard`, and `ask_sales_ai_about_opportunity` can return 403 on some tenants. When any of these errors or returns nothing usable for decision-maker engagement:

- Rate decision-maker engagement `unknown`, never `absent`.
- Record in the item's judgment file which tool failed and that the signal is unknown.
- Continue the run; a 403 never stops processing of that deal or any other.
- Report the 403 first in the run's report back to the manager, not buried.

A missing or empty `get_opportunity_scorecard` answer is informational context only — it never feeds the quietness or decision-maker rating.

## Which way missing data leans

- **Quietness:** if the activity tools return nothing usable in the lookback window (not an error, just no summarized items), rate `quiet`. Silence is itself the signal this area is checking for.
- **Decision-maker engagement:** if `get_opportunity_engaged_people` returns an empty external list (not an error), rate `absent` — there is no external decision-maker evidence to point to. If it errors (403), rate `unknown` per above; do not conflate an empty result with an error.
- An empty or missing `get_opportunity_scorecard` result is never evidence of health for either area and must not shift a rating.

## Stale risks from status tools

`get_opportunity_status` can repeat risks carried over from older activity, and next steps usually name an owner but no date. Before counting any status-reported risk as evidence for quietness or decision-maker absence:

1. Find the risk's own underlying date (from the activity item it references), not the date the status tool was called.
2. If the underlying date is older than `thresholds.activityLookbackDays`, do not use it as decisive or strong evidence — treat it at most as early evidence, and say in the finding that it may be stale.
3. If no date can be recovered at all for a status-reported risk, do not use it above early strength, and say so explicitly in the finding's explanation.

## Fixed level rule table

This table is `scripts/assemble.py`'s rule, reproduced here for reference only. The script's output is final; this reference never overrides it.

| Quietness | Decision-maker | Level |
|---|---|---|
| quiet | absent | critical |
| quiet | unknown | high |
| not quiet | absent | high |
| quiet | present | medium |
| not quiet | unknown | medium |
| not quiet | present | low |

Every combination above medium (critical, high) requires at least one dated piece of evidence for each contributing area; a rating without one is not complete and `assemble.py` will exit 1 for that item.

## What belongs elsewhere

- Amount, stage, and close date are context for the brief's facts, not inputs to the level — they belong in `references/data-collection.md`'s field handling and `scripts/population.py`'s scope rules.
- How evidence is phrased, attributed, and stripped of emails/phone numbers belongs in `references/evidence-guidelines.md`.
- What to ask the rep in the 1:1 and how to phrase actions belongs in `references/actions.md`; this file only decides the level and documents the evidence standard behind it.
