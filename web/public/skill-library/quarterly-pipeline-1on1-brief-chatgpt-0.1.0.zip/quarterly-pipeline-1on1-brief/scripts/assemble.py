"""assemble.py - Combine population deals and per-deal judgments into the
leveled data.json for the quarterly pipeline 1:1 prep brief.

Usage:
    python3 assemble.py input.json --out data_out.json [--as-of YYYY-MM-DD] [--settings settings.json]

Input (input.json): {"population": [...], "judgments": [...]}
Output (data_out.json): {"data": {...per references/data-schema.md}, "report": [...]}

Exit codes:
    0  success
    1  invalid input, incomplete judgment, or missing judgment file
    5  calibration check failed (level distribution out of expected range)
"""

import argparse
import datetime
import json
import os
import sys

TITLE = "Quarterly pipeline 1:1 prep brief"
QUESTION = (
    "Which of my team's open deals closing this quarter have gone quiet or "
    "lack an engaged decision-maker, and what should I ask each rep about "
    "them in our 1:1?"
)
SOURCES = [
    "Backstory opportunity status",
    "Backstory recent opportunity activity",
    "Backstory opportunity engaged people",
    "Backstory opportunity scorecard",
    "Backstory's assistant",
]

DM_STATUSES = {"present", "absent", "unknown"}


class CalibrationError(Exception):
    """Raised when the level distribution falls outside calibration.expectedShare."""


def get_setting(settings, path, default):
    """Walk a dotted path of keys through settings; a missing or null value
    at any step falls back to default."""
    node = settings
    for key in path:
        if isinstance(node, dict) and key in node and node[key] is not None:
            node = node[key]
        else:
            return default
    return node


def compute_level(is_quiet, dm_status):
    """Fixed rule mapping quietness and decision-maker presence to a level."""
    if is_quiet and dm_status == "absent":
        return "critical"
    if (is_quiet and dm_status == "unknown") or (not is_quiet and dm_status == "absent"):
        return "high"
    if (is_quiet and dm_status == "present") or (not is_quiet and dm_status == "unknown"):
        return "medium"
    return "low"  # not quiet and decision-maker present


def run(data, settings, as_of):
    if not isinstance(data, dict):
        raise ValueError("input must be a JSON object")

    population = data.get("population")
    if not isinstance(population, list):
        raise ValueError("'population' must be a list")

    judgments = data.get("judgments")
    if not isinstance(judgments, list):
        raise ValueError("'judgments' must be a list")

    if not isinstance(settings, dict):
        settings = {}

    report = []

    if len(population) == 0:
        raise ValueError("population is empty; nothing to assemble")

    # Index judgments by id.
    judgments_by_id = {}
    for j in judgments:
        if not isinstance(j, dict):
            continue
        jid = j.get("id")
        if jid is not None:
            judgments_by_id[jid] = j

    population_ids = []
    missing_ids = []
    for item in population:
        if not isinstance(item, dict):
            raise ValueError("each population item must be an object")
        pid = item.get("id")
        if pid is None:
            raise ValueError("a population item is missing 'id'")
        population_ids.append(pid)
        if pid not in judgments_by_id:
            missing_ids.append(pid)

    if missing_ids:
        raise ValueError(
            "no judgment file found for item(s): "
            + ", ".join(str(i) for i in missing_ids)
        )

    extra_ids = [jid for jid in judgments_by_id if jid not in population_ids]
    if extra_ids:
        report.append(
            "Ignored judgment file(s) with no matching population item: "
            + ", ".join(str(i) for i in extra_ids)
        )

    quiet_days = get_setting(settings, ["thresholds", "quietDays"], 14)
    lookback_days = get_setting(settings, ["thresholds", "activityLookbackDays"], 30)
    expected_share = get_setting(settings, ["calibration", "expectedShare"], None)

    report.append(f"Quietness threshold used: {quiet_days} days without activity.")
    report.append(
        f"Activity lookback requested: {lookback_days} days "
        "(Backstory is only reliable for the last 30)."
    )

    level_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    quiet_items = []
    unknown_dm_items = []
    items_out = []

    for item in population:
        pid = item["id"]
        judgment = judgments_by_id[pid]

        # Completeness check: the judgment must carry a valid quietness flag.
        # Accept either a plain boolean under "quiet" or a nested
        # {"status": "quiet"/"not_quiet"} under "quietness".
        if "quiet" in judgment and isinstance(judgment.get("quiet"), bool):
            is_quiet = judgment["quiet"]
        else:
            quietness = judgment.get("quietness")
            if not isinstance(quietness, dict) or quietness.get("status") not in (
                "quiet",
                "not_quiet",
            ):
                raise ValueError(
                    f"judgment for item {pid} is missing a valid quietness status"
                )
            is_quiet = quietness["status"] == "quiet"

        # Completeness check: the judgment must carry a valid decision-maker
        # status. Accept either a plain string under "decisionMaker" or a
        # nested {"status": ...} under "decisionMaker".
        dm_raw = judgment.get("decisionMaker")
        if isinstance(dm_raw, str):
            dm_status = dm_raw
        elif isinstance(dm_raw, dict):
            dm_status = dm_raw.get("status")
        else:
            dm_status = None

        if dm_status not in DM_STATUSES:
            raise ValueError(
                f"judgment for item {pid} is missing a valid decisionMaker status"
            )

        level = compute_level(is_quiet, dm_status)
        level_counts[level] += 1

        if is_quiet:
            quiet_items.append(pid)
        if dm_status == "unknown":
            unknown_dm_items.append(pid)
            report.append(
                f"Decision-maker signal unknown for item {pid}: engaged-people "
                "data unavailable, not treated as absent."
            )

        findings = judgment.get("findings")
        findings = findings[:6] if isinstance(findings, list) else []

        actions = judgment.get("actions")
        actions = actions[:3] if isinstance(actions, list) else []

        facts = judgment.get("facts")
        facts = facts if isinstance(facts, list) else []

        items_out.append({
            "id": pid,
            "name": item.get("accountName", item.get("name")),
            "level": level,
            "headline": judgment.get("headline"),
            "assessment": judgment.get("assessment"),
            "subtitle": judgment.get("subtitle"),
            "group": item.get("owner"),
            "value": item.get("amount"),
            "date": item.get("closeDate"),
            "facts": facts,
            "findings": findings,
            "actions": actions,
        })

    total = len(items_out)

    # Calibration check: each level's observed share must fall within the
    # configured expected range, or the run stops short of publishing.
    if isinstance(expected_share, dict):
        out_of_range_levels = []
        boundary_items = []
        for level, rng in expected_share.items():
            if level not in level_counts:
                continue
            if not isinstance(rng, list) or len(rng) != 2:
                continue
            lo, hi = rng[0], rng[1]
            share = level_counts[level] / total if total else 0
            if share < lo or share > hi:
                out_of_range_levels.append(level)
                boundary_items.extend(it["id"] for it in items_out if it["level"] == level)
        if out_of_range_levels:
            raise CalibrationError(
                "Level distribution outside expected range for: "
                + ", ".join(out_of_range_levels)
                + ". Re-check boundary item(s): "
                + ", ".join(str(i) for i in boundary_items)
            )
    else:
        report.append("Calibration check skipped: no calibration.expectedShare configured.")

    report.append(
        f"Assembled {total} item(s): critical={level_counts['critical']}, "
        f"high={level_counts['high']}, medium={level_counts['medium']}, "
        f"low={level_counts['low']}."
    )
    report.append(f"{len(quiet_items)} deal(s) flagged quiet.")
    report.append(f"{len(unknown_dm_items)} deal(s) with unknown decision-maker signal.")

    data_out = {
        "meta": {
            "title": TITLE,
            "question": QUESTION,
            "asOf": as_of,
            "org": None,
            "shownLevels": ["critical", "high", "medium", "low"],
            "listTitle": "Deals to review",
            "groupLabel": "Rep",
            "valueLabel": "Amount",
            "dateLabel": "Close date",
            "currency": None,
            "scope": [],
            "sources": SOURCES,
        },
        "summary": [
            f"{total} open deal(s) closing this quarter reviewed.",
            f"{level_counts['critical']} critical, {level_counts['high']} high, "
            f"{level_counts['medium']} medium, {level_counts['low']} low.",
            f"{len(quiet_items)} deal(s) quiet for {quiet_days}+ days.",
            f"{len(unknown_dm_items)} deal(s) with unknown decision-maker signal.",
        ],
        "metrics": [
            {"label": "Deals reviewed", "value": total},
            {"label": "Critical", "value": level_counts["critical"]},
            {"label": "Quiet deals", "value": len(quiet_items)},
            {"label": "Unknown decision-maker signal", "value": len(unknown_dm_items)},
        ],
        "items": items_out,
    }

    return {"data": data_out, "report": report}


def main(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--out", required=True)
    parser.add_argument("--as-of", default=None)
    parser.add_argument("--settings", default=None)
    args = parser.parse_args(argv)

    as_of = args.as_of or datetime.date.today().isoformat()

    script_dir = os.path.dirname(os.path.abspath(__file__))
    settings_path = args.settings or os.path.join(script_dir, "..", "settings.json")

    try:
        with open(args.input) as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        print(f"Error reading input file: {e}", file=sys.stderr)
        return 1

    try:
        with open(settings_path) as f:
            settings = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        print(f"Error reading settings file: {e}", file=sys.stderr)
        return 1

    try:
        result = run(data, settings, as_of)
    except CalibrationError as e:
        print(str(e), file=sys.stderr)
        return 5
    except ValueError as e:
        print(str(e), file=sys.stderr)
        return 1

    with open(args.out, "w") as f:
        json.dump(result, f, indent=2)

    for line in result.get("report", []):
        print(line)

    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
