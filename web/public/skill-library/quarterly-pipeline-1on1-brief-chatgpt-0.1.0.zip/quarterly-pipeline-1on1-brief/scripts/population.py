"""
population.py — resolve fields, apply team/quarter scope, dedupe open opportunities
closing this quarter, and produce the in-scope deal list for the
quarterly-pipeline-1on1-brief skill.

Usage:
    python3 population.py input.json --out output.json [--as-of YYYY-MM-DD] [--settings settings.json]

Input JSON shape:
    {"records": [records exactly as fetch_records returned them],
     "previousCount": <int or null>}

Output JSON shape:
    {"items": [...], "dropped": [{"id","reason"}],
     "counts": {"fetched","kept","dropped"},
     "fieldMap": {field: nameUsed},
     "previousCount": <int or null>,
     "countChangeExceeded": bool,
     "report": [plain lines]}
"""

import argparse
import json
import os
import sys
from datetime import date, datetime, timedelta

# Candidate keys for a record's unique identifier; not customer-tunable.
ID_CANDIDATES = ["Id", "id", "CrmId", "crmId", "OpportunityId", "ID"]


def parse_date(value):
    """Parse an ISO date/datetime string or Backstory display text ("Nov 28, 2026").
    Returns a date object, or None if it can't be parsed."""
    if not isinstance(value, str):
        return None
    s = value.strip()
    if not s:
        return None

    # ISO date, with or without a time component.
    try:
        return datetime.strptime(s[:10], "%Y-%m-%d").date()
    except ValueError:
        pass

    # Display text, e.g. "Nov 28, 2026" or "November 28, 2026".
    for fmt in ("%b %d, %Y", "%B %d, %Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass

    return None


def resolve_field(record, field_conf):
    """Resolve a field's value from a record using settings.fields.<name>.names,
    in order. Returns (value, name_used, used_fallback)."""
    names = (field_conf or {}).get("names") or []
    for i, name in enumerate(names):
        if name in record:
            value = record[name]
            if value not in (None, ""):
                return value, name, i > 0
    return None, None, False


def resolve_id(record):
    """Resolve a record's identifier from common candidate keys."""
    for key in ID_CANDIDATES:
        if key in record and record[key] not in (None, ""):
            return str(record[key])
    return None


def fiscal_quarter_window(as_of, fy_start_month):
    """Compute the (start, end) dates of the fiscal quarter containing as_of,
    given the month (1-12) the fiscal year starts."""
    year = as_of.year
    month = as_of.month

    # Which fiscal year (identified by its start calendar year) contains as_of.
    if month >= fy_start_month:
        fy_year = year
    else:
        fy_year = year - 1

    fiscal_month_index = (month - fy_start_month) % 12
    quarter_index = fiscal_month_index // 3

    start_month = fy_start_month + quarter_index * 3
    start_year = fy_year
    while start_month > 12:
        start_month -= 12
        start_year += 1
    start_date = date(start_year, start_month, 1)

    end_month = start_month + 3
    end_year = start_year
    while end_month > 12:
        end_month -= 12
        end_year += 1
    end_date = date(end_year, end_month, 1) - timedelta(days=1)

    return start_date, end_date


def run(data, settings, as_of):
    if not isinstance(data, dict):
        raise ValueError("input must be a JSON object")

    records = data.get("records")
    if not isinstance(records, list):
        raise ValueError("input.records must be a list")

    previous_count = data.get("previousCount", None)
    if previous_count is not None and not isinstance(previous_count, (int, float)):
        raise ValueError("input.previousCount must be a number or null")

    if not isinstance(settings, dict):
        raise ValueError("settings must be a JSON object")

    fields_conf = settings.get("fields") or {}
    scope_conf = settings.get("scope") or {}
    thresholds_conf = settings.get("thresholds") or {}

    close_date_conf = fields_conf.get("closeDate") or {}
    amount_conf = fields_conf.get("amount") or {}
    stage_conf = fields_conf.get("stage") or {}
    owner_conf = fields_conf.get("owner") or {}
    account_name_conf = fields_conf.get("accountName") or {}

    team_owners = scope_conf.get("teamOwners", None)
    exclude_stages = scope_conf.get("excludeStages") or []
    fy_start_month = scope_conf.get("fiscalYearStartMonth", 1) or 1

    max_change_pct = thresholds_conf.get("maxCountChangePct", None)

    try:
        as_of_date = datetime.strptime(as_of, "%Y-%m-%d").date()
    except (ValueError, TypeError):
        raise ValueError("as_of must be a YYYY-MM-DD string")

    quarter_start, quarter_end = fiscal_quarter_window(as_of_date, fy_start_month)

    report = []
    field_map = {}
    fallback_notes = []

    # Field names used, recorded once for the report, based on the first record
    # that supplies each field (so the report reflects what was actually used).
    seen_field_names = {"closeDate": None, "amount": None, "stage": None,
                         "owner": None, "accountName": None}

    items = []
    dropped = []
    seen_ids = set()
    fetched = len(records)

    if team_owners is None:
        report.append("scope.teamOwners is null: all owners returned by Backstory are kept.")

    for idx, record in enumerate(records):
        if not isinstance(record, dict):
            dropped.append({"id": "unknown-index-%d" % idx, "reason": "record is not an object"})
            continue

        rec_id = resolve_id(record)
        if rec_id is None:
            rec_id = "unknown-index-%d" % idx

        close_date_val, close_name, close_fallback = resolve_field(record, close_date_conf)
        amount_val, amount_name, amount_fallback = resolve_field(record, amount_conf)
        stage_val, stage_name, stage_fallback = resolve_field(record, stage_conf)
        owner_val, owner_name, owner_fallback = resolve_field(record, owner_conf)
        account_val, account_name, account_fallback = resolve_field(record, account_name_conf)

        if close_name and seen_field_names["closeDate"] is None:
            seen_field_names["closeDate"] = close_name
            if close_fallback:
                fallback_notes.append("closeDate: used fallback field '%s'" % close_name)
        if amount_name and seen_field_names["amount"] is None:
            seen_field_names["amount"] = amount_name
            if amount_fallback:
                fallback_notes.append("amount: used fallback field '%s'" % amount_name)
        if stage_name and seen_field_names["stage"] is None:
            seen_field_names["stage"] = stage_name
            if stage_fallback:
                fallback_notes.append("stage: used fallback field '%s'" % stage_name)
        if owner_name and seen_field_names["owner"] is None:
            seen_field_names["owner"] = owner_name
            if owner_fallback:
                fallback_notes.append("owner: used fallback field '%s'" % owner_name)
        if account_name and seen_field_names["accountName"] is None:
            seen_field_names["accountName"] = account_name
            if account_fallback:
                fallback_notes.append("accountName: used fallback field '%s'" % account_name)

        # Required-field checks.
        if close_date_conf.get("required") and close_date_val is None:
            dropped.append({"id": rec_id, "reason": "missing required field closeDate"})
            continue
        if stage_conf.get("required") and stage_val is None:
            dropped.append({"id": rec_id, "reason": "missing required field stage"})
            continue
        if owner_conf.get("required") and owner_val is None:
            dropped.append({"id": rec_id, "reason": "missing required field owner"})
            continue
        if account_name_conf.get("required") and account_val is None:
            dropped.append({"id": rec_id, "reason": "missing required field accountName"})
            continue

        close_date_parsed = parse_date(close_date_val) if close_date_val is not None else None
        if close_date_parsed is None:
            dropped.append({"id": rec_id, "reason": "closeDate could not be parsed: %r" % (close_date_val,)})
            continue

        if stage_val in exclude_stages:
            dropped.append({"id": rec_id, "reason": "stage '%s' is excluded" % stage_val})
            continue

        if close_date_parsed < quarter_start or close_date_parsed > quarter_end:
            dropped.append({"id": rec_id, "reason": "closeDate %s outside quarter window %s to %s"
                             % (close_date_parsed.isoformat(), quarter_start.isoformat(), quarter_end.isoformat())})
            continue

        if team_owners is not None and owner_val not in team_owners:
            dropped.append({"id": rec_id, "reason": "owner '%s' not on team" % owner_val})
            continue

        if rec_id in seen_ids:
            dropped.append({"id": rec_id, "reason": "duplicate id, first occurrence kept"})
            continue
        seen_ids.add(rec_id)

        items.append({
            "id": rec_id,
            "owner": owner_val,
            "accountName": account_val,
            "closeDate": close_date_parsed.isoformat(),
            "stage": stage_val,
            "amount": amount_val,
            "record": record,
        })

    for key in ("closeDate", "amount", "stage", "owner", "accountName"):
        field_map[key] = seen_field_names[key]

    kept = len(items)
    dropped_count = len(dropped)

    # Group kept items by owner for reporting.
    by_owner = {}
    for item in items:
        by_owner.setdefault(item["owner"], []).append(item["id"])

    count_change_exceeded = False
    if previous_count is not None and previous_count > 0:
        change_pct = abs(kept - previous_count) / float(previous_count) * 100.0
        if max_change_pct is not None and change_pct > max_change_pct:
            count_change_exceeded = True

    report.append("Fiscal quarter window: %s to %s (fiscalYearStartMonth=%s)"
                   % (quarter_start.isoformat(), quarter_end.isoformat(), fy_start_month))
    report.append("Field map: %s" % json.dumps(field_map))
    for note in fallback_notes:
        report.append("Fallback used - %s" % note)
    report.append("Counts: fetched=%d kept=%d dropped=%d" % (fetched, kept, dropped_count))
    for owner, ids in sorted(by_owner.items(), key=lambda kv: (kv[0] or "")):
        report.append("Owner '%s': %d deal(s)" % (owner, len(ids)))
    if previous_count is not None:
        report.append("Previous run kept count: %s" % previous_count)
        if count_change_exceeded:
            report.append("Count change exceeded thresholds.maxCountChangePct (%s%%): run should not publish."
                           % max_change_pct)
    else:
        report.append("No previous count supplied: treated as a first run.")

    return {
        "items": items,
        "dropped": dropped,
        "counts": {"fetched": fetched, "kept": kept, "dropped": dropped_count},
        "fieldMap": field_map,
        "previousCount": previous_count,
        "countChangeExceeded": count_change_exceeded,
        "report": report,
    }


def main(argv):
    parser = argparse.ArgumentParser(description="Resolve fields and apply quarter/team scope.")
    parser.add_argument("input", help="path to input JSON file")
    parser.add_argument("--out", required=True, help="path to write output JSON")
    parser.add_argument("--as-of", default=None, help="YYYY-MM-DD, default today")
    parser.add_argument("--settings", default=None, help="path to settings.json")
    args = parser.parse_args(argv)

    as_of = args.as_of or date.today().isoformat()

    settings_path = args.settings
    if settings_path is None:
        here = os.path.dirname(os.path.abspath(__file__))
        settings_path = os.path.join(os.path.dirname(here), "settings.json")

    try:
        with open(args.input, "r") as f:
            data = json.load(f)
    except (IOError, OSError, json.JSONDecodeError) as e:
        sys.stderr.write("Could not read input file: %s\n" % e)
        return 1

    try:
        with open(settings_path, "r") as f:
            settings = json.load(f)
    except (IOError, OSError, json.JSONDecodeError) as e:
        sys.stderr.write("Could not read settings file: %s\n" % e)
        return 1

    try:
        result = run(data, settings, as_of)
    except ValueError as e:
        sys.stderr.write(str(e) + "\n")
        return 1

    with open(args.out, "w") as f:
        json.dump(result, f, indent=2)

    for line in result["report"]:
        print(line)

    if result["counts"]["kept"] == 0:
        return 3
    if result.get("countChangeExceeded"):
        return 4
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
