# Renewal risk brief

A Claude plugin that builds a weekly renewal risk brief for revenue and customer leadership, from the Backstory MCP. It answers one question:

> Which of our largest upcoming renewals are at risk, why, and where should leaders step in this week?

Each run reviews every renewal in scope using Backstory. When a Salesforce connector is available, it fills in what Backstory doesn't return. It publishes a single page with:

- **a monthly view of the renewal pool**, split by Backstory's risk level, with the value the team's own forecast flags at risk beside each month;
- **every renewal Backstory rates Critical or High**, ranked, with the team's forecast next to Backstory's risk level, and filters by month (and by region, when a region field is configured);
- **a side panel for each account.** It breaks the risk down across six areas of account health, names the churn drivers your team tracks where they apply, backs every finding with dated evidence, and suggests where a leader should step in, who should do it and by when.

Each run updates the same page, so everyone keeps one link. Version 0.6.0.

**How a run works.** Claude gathers the data and makes the judgment calls: which areas of an account show risk, the evidence, the actions. Small scripts do everything that can be counted, so every run treats the same data the same way. They build the renewal list from what Backstory returns, set each account's risk level, rank the accounts, add up the totals and build the page itself.

## What you need

1. **The Backstory connector** in Claude (required). It's the core of the brief: the renewal list, the CRM fields synced into Backstory, activity, people and news.
2. **Standard Salesforce opportunity fields synced into Backstory.** Every tenant has these:
   - **Core:** Type, Close Date, Amount, Stage, the opportunity owner and the account name. If one is missing, the brief uses a fallback (for example, other renewal signals when Type is missing) and says so first in its report. A missing field never stops the run.
   - **Optional, standard:** Forecast Category (shown as the team's forecast), Next Step, Created Date, Is Closed, Account Type.
   - **Optional, your own fields:** a renewal or subscription start date, a notice date, a tier or segment, a region and territory, a customer status, a test-account flag, the account's annual contract value, a sentiment rating with its date, an engagement or usage score, a manager note and a customer success owner. Each is `null` in `settings.json → fields` and is skipped until you set it.
3. **A Salesforce connector** (optional). When it's available, the brief uses it only to fill in fields Backstory doesn't return, check the renewal count, and read the notes and tasks executives log by hand. Without it, the brief runs on Backstory alone.
4. **Access to the whole book.** The brief sees what the person running it can see in Backstory. To cover every account, run it (and schedule it) from an account with access to all of them, such as Revenue Operations.
5. **Code execution turned on** in Claude's settings. Claude runs small scripts that check the data and build the page from the fixed design.

The brief runs best on Opus at medium effort or higher.

## Install

Install the plugin from a marketplace that lists it, or load a local copy of this folder:

```bash
claude plugin install renewal-risk-brief@<marketplace>
claude --plugin-dir ./renewal-risk-brief
```

Then open `skills/renewal-risk-brief/settings.json` and set at least `company.name` and `company.timezone`. Everything else has working defaults.

## Running it

Ask Claude to "run the renewal risk brief", "refresh the renewal risk brief" or "where should we step in this week on renewals". It uses the scope in `settings.json` and doesn't ask for filters. At the end, Claude shares the link and a short summary of the run.

The first run creates the page and gives you its link. Include the link when you ask for the next run ("refresh the renewal risk brief at <link>") so it updates the same page; the weekly refresh carries the link automatically.

## Weekly refresh

By default the brief refreshes every **Monday at 8:00** in `schedule.timezone`. Set the day, time and timezone in `settings.json → schedule` so it lands before your team's renewal review. After the first run, Claude offers to set this up and creates the weekly task only if you say yes.

- The task runs under the account of whoever creates it, with their Backstory access.
- A task scheduled on a computer runs only while that computer is on and Claude is open.
- A scheduled run never creates a second page. If it can't finish (for example, the Backstory connector isn't available), it leaves last week's brief in place and says what stopped it.

If Claude can't schedule it where you're working, create a weekly task yourself with this prompt, followed by the brief's link:

```
Run the renewal risk brief. This is the scheduled weekly run: update the brief at the link given here, don't ask questions, and if something blocks the run, don't publish; report what blocked it. Brief link:
```

## Settings

`skills/renewal-risk-brief/settings.json`:

- `company`: your company's name (shown on the page), the brief's title, timezone and currency.
- `fields`: the fields the brief reads. Each is `{names, required, note}`, with the Salesforce API name first and then the Backstory label. Required fields are standard. An optional field whose `names` is `null` is skipped; set it to your org's field to use it.
- `scope`: the renewal window (`windowDays` ahead, or a fixed `windowEnd`, plus how far back overdue renewals are kept), regions, tiers and excluded account types. Tiers, regions and exclusions apply only when their fields are set. Each run reads the actual values from your instance and reports which ones it used.
- `population`: the minimum renewal value when there's no tier filter, the renewal-created-ahead signal, the territory-to-region map and the weekly count check.
- `crmForecast`: which forecast values count as at risk (by default, every Forecast Category below Commit).
- `churnDrivers`: the churn drivers your team tracks, one per area. Edit the labels to your own.
- `thresholds`: the time windows and score levels the analysis uses, such as how long without customer contact counts as quiet.
- `calibration`: the expected spread of risk levels across the book (most renewals Medium, a few Critical). If a run lands far from it, Claude re-checks the ratings against the evidence.
- `moves`: examples of leadership levers. The brief uses them where they fit and suggests other actions when the evidence calls for it.
- `output`: where the brief lives, so each run updates it.
- `schedule`: the weekly refresh and the prompt it uses.

## What's inside

```
renewal-risk-brief/
├── .claude-plugin/plugin.json
├── README.md
└── skills/renewal-risk-brief/
    ├── SKILL.md                    # the workflow Claude follows
    ├── settings.json               # fields, scope, thresholds, churn drivers, example moves, output, schedule
    ├── references/
    │   ├── framework.md            # the six areas, churn drivers, risk levels, ranking
    │   ├── data-collection.md      # sources and how each run gathers data
    │   ├── actions.md              # how actions are chosen, who, by when
    │   ├── evidence-guidelines.md  # what good evidence and writing look like
    │   ├── data-schema.md          # the data behind the page
    │   ├── publishing.md           # building the page and updating the same brief
    │   └── ux-spec.md              # how the page and side panel behave
    ├── assets/brief-template.html  # the fixed page design; runs only change the data
    ├── assets/brief-template.sha256 # the approved template's hash, checked on every build
    ├── scripts/population.py       # builds the renewal list from the fetched records
    ├── scripts/assemble.py         # sets levels, ranks and counts, from one file per account
    ├── scripts/build_brief.py      # checks the data and builds the page
    ├── scripts/check_fixtures.py   # tests the scripts and the page with unusual and invalid data
    ├── examples/sample-data.json   # fictional data for previews and tests
    └── evals/rubric.md             # how to judge the quality of a run
```

## Previewing and testing

To see the page with fictional data:

```bash
python3 -I skills/renewal-risk-brief/scripts/build_brief.py skills/renewal-risk-brief/examples/sample-data.json sample-brief.html
```

To check the scripts and the page after any change:

```bash
python3 -I skills/renewal-risk-brief/scripts/check_fixtures.py --out fixtures
```

It runs 42 checks:

- 1 check of the risk level rules;
- 28 page cases: 13 that must render and 15 that must be rejected for the right reason;
- 13 end-to-end checks of the renewal list and assembly scripts. These include Backstory's display dates ("Nov 28, 2026"), a fetch where nothing is kept, and a run on the standard fields only.

Open the pages in `fixtures` at desktop and phone widths to review them. If you change the template on purpose, record it with `python3 -I skills/renewal-risk-brief/scripts/build_brief.py --accept-template`.
