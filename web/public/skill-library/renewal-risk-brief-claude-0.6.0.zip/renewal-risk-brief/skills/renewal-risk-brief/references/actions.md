# Leadership actions

Every Critical and High account gets **one primary action and up to two supporting actions**. Medium and Low accounts get none (they aren't shown).

## Start from the evidence

Work out what needs to happen at this account before reaching for a move. Read the evidence behind the level, and what's already in motion:

- **What drives the level:** the primary driver and its evidence, then the secondary drivers.
- **What's already planned:** upcoming meetings in the activity, next steps in Backstory's account status, a next step on the renewal opportunity, a renewal proposal already sent. **Build on these rather than duplicating them.** If the account owner is meeting the client on Thursday, the action is to prepare that meeting or bring the right person to it, not to ask a leader to call separately.
- **Who is involved:** client contacts by name and title, who has gone quiet or left, and the account owner and client services owner.
- **Time:** the client notice date and the team's next renewal or forecast review.

Then decide the most useful thing a leader or the account team can do this week to change the outcome. The primary action must deal with what drives the level; how is your judgment.

## Example moves

`settings.json → moves` lists common leadership levers. Use them as examples and labels, not as the only options; edit the list to match your own. When one fits, use its key. When none does, use `other` and let the title say what the action is.

| Move | Often fits when | Typical owner |
|---|---|---|
| Executive outreach (`executive_outreach`) | A champion or key user is gone, the client is merging or restructuring, or the account is Critical with no senior contact | CRO or VP of Customer Success |
| Specialist session (`expert_session`) | Value or dissatisfaction is the issue: show value with your own product (a session with a solutions specialist, a tailored usage review, an invitation to training) | Account owner, with a solutions specialist |
| Pricing or multi-year conversation (`pricing_multiyear`) | Commercial pushback, pushback on a price increase, or a chance to secure a multi-year term before the notice date | Account owner, with the sales leader |
| Re-engagement plan (`reengagement_plan`) | The relationship has gone quiet or is single-threaded | Account owner and customer success |
| Map new stakeholders (`map_stakeholders`) | A new decision-maker, a reorganization, or no contact with the budget holder | Account owner |
| Escalate to sales leader (`escalate_sales_leader`) | The renewal isn't being worked, ownership is unclear, or the account owner's actions haven't moved it | Sales leader |

Other actions are welcome when the evidence calls for them, for example joining a meeting already booked, asking a specialist the client trusts to reach out, offering a plan better suited to how the client now uses the product, or sending a summary of the value the client has had this year.

Prefer the smallest action that can change the outcome; keep executive time for accounts where seniority matters.

## Guardrails

- **Doable this week** by a named person or role. No vague intentions ("monitor the account").
- **Never commit your company** to a price, discount, contract term or product change. An action may open the conversation ("explore a two-year term with the sales leader's approval"); it never promises the outcome.
- **The brief recommends; people act.** Never contact the client, and never write to Backstory or Salesforce.
- **Spread people's time.** Before finishing, count the actions each role has due in the same week across all accounts (by `role`). If one has more than `brief.maxLeaderActionsPerWeek`, keep them on the accounts where they matter most (Critical first, then value) and move the rest to someone with room: the sales leader, then the account owner or client services. Check the person you move them to isn't over the limit too, and move deadlines to the following week where the notice date allows. The build warns when anyone is over the limit.
- **Grounded:** every action traces to the evidence in the account's breakdown. No generic advice.

## Each action is a small plan

The ranked table shows the primary action's title, who and by when; the Summary tab shows every action's title, who and by when. The Action plan tab shows the full plan, so each action needs:

- **Title:** the action as a one-line imperative, specific to this account. Not a move's name ("Map new stakeholders") but what to do: "Find J. Example's successor and the budget holder", "CRO reaches the CTO to find J. Example's successor before Dec 3". It's the heading leaders scan, so make it self-explanatory.
- **Goal (`objective`):** what a good outcome looks like, concretely and checkably ("A conversation with the successor before Dec 3, confirming who owns the budget").
- **Steps:** 2–5 concrete steps in order, each doable by a named person. Include the preparation (what to pull together first) as well as the contact itself.
- **Talking points:** what to say or ask, written in the voice of the person acting, grounded in the account's evidence. Reference what the client said where it helps. Include them only where they help; small supporting actions often don't need them.

Keep steps tight: the fewest that get the action done, each one line where possible.

The short form has four parts:

- **Move:** a key from settings, or `other`.
- **Who:** a role for leaders (CRO, VP of Customer Success, Sales leader, North America) and names from the account record (Backstory, or Salesforce when connected) for account and client services owners. Never invent a person.
- **Role:** the role or person whose time the action takes (`role`): "CRO", "VP of Customer Success", "Sales leader, North America", or the owner's name. It's how each person's weekly load is counted, so use the same wording for the same person across accounts.
- **By:** a date, never after the renewal date.
  - **Notice date still ahead:** a few business days before the **client notice date** (the optional notice date field where it's set, otherwise renewal minus `clientNoticeDays`).
  - **Notice date passed, or the renewal is overdue:** spread by rank instead of putting everything on one day. Critical primary actions within two business days; High primary actions within five business days (or by the team's next renewal review, when one is set); supporting actions two to five business days after the primary action they support, unless they prepare it (then before it). Say in the reason that the notice date has passed.
- **Why:** one line tying the action to the evidence ("Re-establish a senior contact before the Dec 3 notice date; the main user left in October.").

## Choosing
- The primary action deals with the primary driver.
- Supporting actions deal with secondary drivers, or prepare the primary action (mapping stakeholders before executive outreach, for example).
- Keep actions specific and doable this week.
