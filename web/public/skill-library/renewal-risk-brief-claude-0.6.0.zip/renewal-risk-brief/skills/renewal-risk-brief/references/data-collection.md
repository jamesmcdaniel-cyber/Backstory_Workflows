# Data collection

**Backstory is the core.** The renewal list, the CRM fields synced into Backstory, activity, people and news all come from the Backstory MCP, and every run follows that path.

**Salesforce complements it, if and only if a Salesforce connector is available** in this session. Use it only to fill what Backstory doesn't have (§0, §2, §4), never to replace what Backstory returns, and never ask the user to connect one. Without it, the run is complete on Backstory alone. Salesforce is read-only: never write to it. The Salesforce connector's tools vary by setup: look for a query (SOQL) tool and a describe or schema tool, and find every field by the names in `settings.json → fields` (Salesforce API name first, then the Backstory label), never by an assumed API name.

Batch independent calls in parallel. Tool names below are the Backstory MCP's.

## Sources at a glance

| Need | Backstory (core) | Salesforce (only if connected) | If neither has it |
|---|---|---|---|
| Renewal population | `preview_records` → `fetch_records` (opportunities) | Fills a **core** field Backstory doesn't return; cross-checks the count | The field's fallback (§0) |
| Optional CRM fields (forecast category, notice date, manager note, next step per renewal opportunity; tier, region, territory, sentiment and engagement score per account, when configured) | The same records | Fills an **optional** field Backstory doesn't return; the engagement score's prior reading from field history | Run without it; name it in the report only if it was configured |
| Executive contact logged by hand in the CRM | Activity, SalesAI | Recent notes and tasks on the account | Treat as a capture gap (evidence-guidelines.md, principle 7) |
| Activity, people, risks, news | Activity, status, SalesAI and news tools | — | — |
| Private-company news | `account_company_news` | — | Web search (pass 2 only) |

Record what was used in `meta.sources`: `renewalList` is `backstory`; `crmFields` is `backstory_fields`, `salesforce` (all of them from Salesforce), `mixed` (some from each) or `unavailable` (none could be read). Set each account's `crmView.source` the same way. Evidence that cites one of the CRM's field values (a score reading, a sentiment rating) uses the source `salesforce`: it's CRM data, whichever way it was read. If the Backstory MCP is unavailable, stop: there is nothing to analyse.

## 0. Check the fields, then read the instance's values

**Check the connectors.** Backstory is required. Note whether a Salesforce connector is available; if it isn't, carry on without it and don't mention it unless a field is missing.

**Check the fields** (`settings.json → fields`). Each entry is `{"names": [Salesforce API name, Backstory label], "required": true or false, "note": ...}`; an entry whose `names` is `null` isn't configured for this org and is skipped. Run a small `fetch_records` on open opportunities (a handful of records is enough) and confirm each configured field is returned with values. Look for each by its Salesforce API name first, then its Backstory label, then by meaning.

- **Core fields** (`required: true`): the standard fields every tenant has: opportunity `Type`, `CloseDate`, `Amount`, `StageName`, the opportunity owner (`OwnerName`) and the account name (`AccountName`). Activity, people and news come from Backstory's own tools. These define who is in the brief. For any that Backstory doesn't return, read it from Salesforce when connected (matching records by their Salesforce ids; `find_record_by_crm_id` maps a Salesforce id to the Backstory record). When neither source has it, **don't stop: use the fallback below**, and name the field and the fallback first in the report. On a scheduled run, publish as usual; the count check in §1 is the safety net.

  | Field | Fallback when it isn't available |
  |---|---|
  | Opportunity `Type` | Identify renewals from the other signals (§1a); at least two must agree |
  | Renewal date | The optional renewal date field (`renewalDate`) when it's configured and set; otherwise `CloseDate`, the standard. Using `CloseDate` is normal, not a fallback |
  | `Amount` | The optional annualized amount, then the account's optional annual contract value; with none, leave the renewal out and count it in the report |
  | Closed or open | `IsClosed` when returned; otherwise `StageName`, matched against `values.closedStages` (or any stage starting "Closed" when that list is empty) |
  | Tier or segment (optional) | Applied only when a tier field is configured and `scope.tiers` lists values. Otherwise no tier filter: `population.minRenewalValue` (0 by default) is the only size cut |
  | Region (optional) | When not configured, worked out from the optional territory field through `population.territoryRegionMap` if that map is filled in; with neither, no region: every account shows in one list, and the page hides the region filter |
  | Account status (optional) | Applied only when configured with the values meaning a paying customer; otherwise every account with an open renewal is kept (an open renewal opportunity already implies a current customer) |
  | Account type exclusions and test flag (optional) | Applied only when configured (`scope.excludeAccountTypes`, the test-account field). Otherwise renewals worth $0 and accounts whose name says internal or test are left out |

  **The only case where the run can't continue** is when no renewals can be identified by any signal: then there is nothing to analyse.
- **Optional fields** (`required: false`): the renewal date field, the notice date field, annualized amount, manager note and its date, next step, forecast category (`ForecastCategoryName`), at-risk reason, renewing products; on the account: tier, region, territory, status, type, test flag, annual contract value, sentiment and its date, engagement score, client services owner. Use the ones that are configured; fill any that Backstory doesn't return from Salesforce when connected. Otherwise run without them, and list configured-but-missing ones **first** in the report back. Without a forecast field, the page leaves out the team's forecast; without an engagement score, Value and satisfaction is rated from conversations only (framework.md §1); without a sentiment date, sentiment is shown but never changes a rating (framework.md §4).
- **The notice date** is the optional notice date field when it's configured and set on the renewal opportunity; otherwise the renewal date minus `thresholds.clientNoticeDays` (60 by default). The report says how many accounts used each.
- **Region and Territory:** when configured, Region drives the filter, the chart and the per-region counts. Territory is shown next to it for each account, and fills a missing region through `population.territoryRegionMap`. Never use Territory as the grouping itself. An account whose region can't be found goes under "No region", and its territory is listed in the report so the map can be completed.

Then **read the values in use**, never assuming them, and match them to the intent in `settings.json`:

- **Regions** (when a region field is configured and `scope.regions` is `"all"`): every region value in use. Order them with `scope.regionOrder` first, the rest as found. Record them in `meta.scope.regions`.
- **Tiers** (only when `scope.tiers` lists values): the tier values that match them.
- **Account status** (only when configured): the status value that means a paying customer. A status that is also true for trials isn't enough on its own.
- **Account types to exclude** (only when `scope.excludeAccountTypes` lists values): the type values that match them, such as partners or internal accounts. Exclude only those, never an ordinary business classification.
- **Closed stages:** the `StageName` values that mean closed, when `IsClosed` isn't returned. Record them in `values.closedStages`.
- **Forecast:** every forecast value in use on open renewal opportunities, from most to least confident, and which count as at risk (`crmForecast.atRiskRule`; with Salesforce's standard Forecast Category, Commit is not at risk, Best Case and Pipeline are). Record them in `meta.crmForecast`.

Read them from the Backstory records, or from Salesforce picklists for a field read there. Report the values you used in your chat message after the run.

## 1. Renewal population

**In scope:** open renewal opportunities, any region, with a renewal date from `scope.overdueDays` (90) days ago through the end of the window (`scope.windowEnd` when set, otherwise today plus `scope.windowDays`), narrowed by tier, account status and excluded account types only where those are configured. Renewals whose date has passed but are still open are **in**, marked overdue: they're often the riskiest. Closed opportunities, including renewals booked early, are out.

**Fetch broadly and let `population.py` filter.** Backstory's record search can rewrite queries it can't fully map, without saying so: it may turn a date range into "next 90 days" or "this year", give different filters on preview and fetch for the same query, match a field value against the wrong field (for example Account Name), or drop unknown fields silently. So never trust it with the scope:

1. **Ask only for what it handles reliably:** open opportunities, by close date (or the configured renewal date), **one month at a time** from `scope.overdueDays` ago through the window end (smaller pages also avoid output that's too long to read). Don't put renewal type, tier, region or status in the query.
2. **Check the plan on both `preview_records` and `fetch_records`.** If a page's plan changed the dates or added a filter you didn't ask for, re-run that page with a simpler query. Note it in the report.
3. **Save every record you got, as returned,** in one JSON list, `records.json`. Don't filter or edit them. Backstory's record tools return display dates ("Nov 28, 2026") rather than ISO dates; leave them as they are: `population.py` reads both.
4. **With Salesforce connected,** add to each record any core or optional field Backstory didn't return (under a key such as `sf`, matched by the opportunity's Salesforce id), and the renewing products. Also count the open renewals in Salesforce (for example `SELECT COUNT() FROM Opportunity WHERE IsClosed = false AND Type = '<renewal value>' AND CloseDate <= <window end>`); compare it with `population.py`'s count afterwards and report any difference. Fetch renewals missing from Backstory's list through `find_record_by_crm_id`.
5. **Write `field-map.json`** (data-schema.md): the dotted path to each field in the records, and the values that mean renewal, closed stages, the in-scope tiers, a paying customer, and the account types to exclude, plus the forecast scale. Leave a path `null` when the field isn't there or isn't configured: the script uses its fallback or skips it.
6. **Run `population.py`** (SKILL.md, step 1). It applies §0's fallbacks and §1a, groups by account and writes `population.json` with its report.
7. **Confirming the count.** On an interactive run, show the user the account count, the overdue count and what was dropped, and ask once before analysing. On a scheduled run, ask nothing: `--previous` compares with last week's brief, and the script exits 4 when the count moved by more than `population.maxCountChange`.

### 1a. Telling renewals apart from new business

Getting this wrong puts new-business or upsell deals in the brief, so never rely on one field alone. The signals:
- **The opportunity type.** Read the type field by meaning and pick the value that means "Renewal" (`fields.renewalTypeLabel`).
- **The created-date gap.** Many orgs create renewal opportunities automatically a fixed time before the subscription expires, often about a year ahead. A created date `population.autoCreatedGapDays` (300 to 400 days by default) before the renewal date counts as a renewal signal. Set it to `null` when your org doesn't do this: the signal is then skipped.
- **Renewing products** (renewal line items), when the records carry them; a new-sale opportunity usually has none.
- **"Renewal" in the opportunity name.**
- **One renewal per account is typical,** sometimes with a separate upsell opportunity next to it. The upsell is not a renewal.
- **Stages aren't a renewal signal.** They're used only to tell open from closed.
- **Region is not territory.** When an account has both, region is the broad grouping and territories sit inside it. Use region.

**How `population.py` applies it:**
1. It classifies by the type field when it's mapped, then **checks it against the other signals**: the created-date gap, renewing products, and a name containing "Renewal". When the type and the signals disagree on an opportunity (typed new business but created on the renewal schedule with renewing products, or typed renewal with neither), it keeps the type's answer and lists the opportunity. Name how many in your report.
2. **Without the type field,** an opportunity is a renewal when at least two of the measurable signals agree.
3. **Group by account:** one row per account, the earliest renewal date, the **sum of the renewal opportunities** (never an upsell or new sale: those aren't renewals and are dropped), each opportunity listed. Accounts with more than one renewal in the window are listed: check none is a mis-typed upsell.

Record split companies from the rollup field (when configured) as related accounts in the account file.

## 2. CRM fields
`population.py` reads them from the records through `field-map.json` (Backstory first; the Salesforce values you added when connected) into each account's `crm` block. A value empty in both is `null`, never guessed and never asked of SalesAI. Per account it gives the forecast (the least confident across the renewals), sentiment with note and date, the engagement score with one prior reading when Backstory or Salesforce field history has it, and the latest manager note, each only when configured.

## 3. Pass 1: screen every account

**Always ask for 90 days of activity.** Every Backstory tool that takes a lookback (`get_recent_account_activity`, `get_recent_opportunity_activity`) defaults to 30 days. Always pass `days` = `activityLookbackDays` (90) explicitly, on every call, in both passes and in subagents. Never rely on the default. The other tools (`get_account_status`, `get_engaged_people`, `ask_sales_ai_about_account`) are fixed at 30 days and can't be extended: use them to add detail, never to conclude that something didn't happen in the last 90 days.

Per account, in parallel:
- `get_recent_account_activity` with `days` = `activityLookbackDays` (90). Use it for recency, last two-way contact, one-way outreach, which client contacts appear or go silent, bounced emails, and renewal, pricing, competitor or cancellation language. If the server ignores `days`, note the shorter window.
- `account_company_news`: mergers, layoffs, leadership change, financial pressure. Public companies only; an empty result is not evidence of health.

Assess all six areas from this plus the CRM fields in `population.json`. Count the activities captured in the window (`activity.captured`); when it's 0, rate Engagement momentum and Relationship depth with framework.md §3, "No captured contact", and record any `captureGap`. Write the result to `accounts/<id>.json` (data-schema.md, "Account analysis file"). Most accounts end here as Low or Medium.

**Batching:** with more than ~15 accounts, split into batches of about 10 and run them in parallel subagents when available. Give each subagent its accounts from `population.json`, the run folder's path, `settings.json`, framework.md, evidence-guidelines.md and the account-file section of data-schema.md. Each subagent writes one file per account and returns only one line per account (id, provisional level, main reason). Subagents only read from Backstory and write their own account files.

## 4. Pass 2: where it matters

For each account provisionally Critical or High, and each Medium account on the boundary (a High area, or two or more Medium areas):
- `get_recent_account_activity` again with `days` = `activityLookbackDays` (90), when pass 1's summary doesn't carry the dated events, people or wording an insight needs.
- `get_recent_opportunity_activity` with `days` = `activityLookbackDays` (90) on each renewal opportunity in the window, for renewal and pricing conversations logged against the opportunity. Activity is sometimes matched to the wrong opportunity (a renewal meeting filed under a new-sale opportunity), so treat this as a supplement to the account's activity, not the base.
- `get_account_status`: current risks, topics, next steps (fixed 30-day window; may repeat stale risks, so check dates).
- **What's already planned**, for the actions (actions.md): upcoming meetings and promised follow-ups in the 90-day activity, next steps in the account status, and the renewal opportunity's next step (from Backstory, or Salesforce when connected). Note each with its date and owner.
- **With Salesforce connected:** the account's notes and tasks from the last 90 days, for executive contact logged by hand (evidence-guidelines.md, principle 7) and call notes stored there.
- `ask_sales_ai_about_account`, 2–3 targeted questions, for example:
  - "Has the renewal been discussed with the client recently? With whom, and what was said?" (SalesAI sees 30 days: take the 90-day answer from the activity calls)
  - "Who are the decision-makers and main users at this account, and are they still engaged?"
  - "Any pricing, budget, competitor or cancellation concerns raised by the client?"
- Web search, only for accounts with no company news: mergers, closures, layoffs or leadership changes in the last 6 months. Cite the source and date.
- `get_engaged_people`: try it; it may return an error on some tenants. If it does, skip it and infer people from activity.

For every flagged area, go back to the activity behind it and collect what evidence-guidelines.md asks for: the specific events, who was involved, the client's verbatim words where the summaries or notes carry them, and what each event tells us. Ask SalesAI for exact wording when a summary hints at a decisive remark ("What exactly did the client say about the renewal on Oct 27?"), and use it only if it reads as verbatim.

For every **Low** area, keep the one piece of evidence that shows why it looks healthy: a recent two-way reply, a meeting held, the engagement score reading, a renewal call with the decision-maker. When the area looks healthy only because something is absent, there's no event to keep: note what was looked at and over what window (the news search, 90 days of email, meetings and CRM notes) for the explanation. Pass 1 usually already holds this; note it then rather than searching again.

Then set the final level, drivers, assessment, the insights for every area (Low areas included), conflicts, people, recent activity and the full action plans.

Not used: `situation_search` (its match scores aren't reliable enough for this brief).

## Known limits to carry into the brief
- Status summaries, engaged people and SalesAI see only the last 30 days of activity; the activity calls reach 90 days because `days` is passed explicitly.
- **Summaries, not text.** The activity tools return AI summaries (often weekly digests), and SalesAI reads the same summaries: no email or transcript text, so no verbatim quotes, and no reliable record of who replied. Summaries and SalesAI sometimes swap buyer and seller, and SalesAI may describe a filing as something the client said: check names against the client's contacts and your own staff before using a claim.
- **Manual CRM notes aren't captured** by Backstory: executive contact logged that way is invisible without a Salesforce connector (framework.md §3).
- In-person meetings and chat tools Backstory doesn't connect to are never captured. Don't add a run note for these; mention a capture gap in an insight's explanation only when it weakens that conclusion.
