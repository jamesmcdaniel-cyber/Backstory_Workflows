# Data schema

The run's files, and the exact shape of `data.json`. `scripts/build_brief.py` checks structure (required keys, allowed values, ordering, action limits); it never checks how much evidence there is. See `examples/sample-data.json` for a complete example with fictional data.

Dates are `YYYY-MM-DD`. Money is a number in `company.currency`. Use `null` for unknown values, never a guess. Strings are plain text: the template escapes them.

## The run's files

| File | Written by | What it holds |
|---|---|---|
| `records.json` | Claude | Every opportunity record fetched, as returned, in one list (data-collection.md §1) |
| `field-map.json` | Claude | Where each field is in the records, and which values mean what (below) |
| `population.json` | `population.py` | The renewal accounts in scope, with renewal dates, values and each account's CRM fields (`crm`), plus `crmForecast` and the report (dropped, fallbacks, disagreements) |
| `accounts/<id>.json` | Claude or subagents | One **account analysis file** per account: the judgment (below) |
| `data.json` | `assemble.py` | What the page shows (the rest of this document). Never written by hand |

### field-map.json

```json
{
  "opportunity": {"id": "Id", "name": "Name", "accountId": "AccountId", "accountName": "AccountName",
                  "type": "Type", "stage": "StageName", "renewalDate": null, "closeDate": "CloseDate",
                  "createdDate": "CreatedDate", "amount": "Amount", "annualizedAmount": null,
                  "renewingProducts": null, "isClosed": "IsClosed", "owner": "OwnerName",
                  "forecast": "ForecastCategoryName", "forecastLabel": "Forecast Category", "atRiskReason": null,
                  "nextStep": "NextStep", "noticeDate": null, "managerNote": null, "managerNoteDate": null},
  "account": {"name": "AccountName", "tier": null, "region": null, "territory": null,
              "status": null, "type": "Account.Type", "testAccount": null, "annualContractValue": null,
              "owner": "Account.Owner.Name", "clientServices": null, "rollup": null,
              "sentiment": null, "sentimentNote": null, "sentimentDate": null,
              "engagementScore": null, "engagementScoreAsOf": null,
              "engagementScorePrevious": null, "engagementScorePreviousAsOf": null},
  "values": {"renewalType": ["Renewal"], "closedStages": ["Closed Won", "Closed Lost"], "tiers": [], "clientStatus": [],
             "excludeTypes": [], "territoryRegion": {},
             "forecastScale": [{"value": "Commit", "atRisk": false}, {"value": "Best Case", "atRisk": true}, {"value": "Pipeline", "atRisk": true}]},
  "crmFieldsSource": "backstory_fields"
}
```

Paths are dotted, as the records hold them: the prefix depends on how the records nest each field (for example `Owner.Name` or `OwnerName`). The example maps only standard Salesforce fields; set a path for an optional field only when `settings.json → fields` configures it for your org and the records return it. Use `null` for a field that isn't there: `population.py` applies its fallback or skips it (data-collection.md §0).

- **Opportunity keys:** `id`, `name`, `accountId`, `accountName`, `type`, `stage`, `renewalDate` (optional: a renewal or subscription start date; when null or empty, `closeDate` is the renewal date), `closeDate`, `createdDate`, `amount`, `annualizedAmount` (optional value fallback), `renewingProducts`, `isClosed` (when null, `stage` is matched against `values.closedStages`, or any stage starting "Closed" when that list is empty), `owner`, `forecast`, `forecastLabel` (the label shown for the forecast field, a string, not a path), `atRiskReason`, `nextStep`, `noticeDate` (optional: when null, the renewal date minus `thresholds.clientNoticeDays`), `managerNote`, `managerNoteDate`.
- **Account keys:** `name`, `tier`, `region` (when null, worked out from `territory` through `values.territoryRegion` or `settings.json → population.territoryRegionMap`; with neither, no region), `territory`, `status`, `type`, `testAccount`, `annualContractValue` (optional last value fallback), `owner`, `clientServices`, `rollup`, `sentiment`, `sentimentNote`, `sentimentDate`, `engagementScore`, `engagementScoreAsOf`, `engagementScorePrevious`, `engagementScorePreviousAsOf`.
- **Values:** `renewalType` (the type values meaning renewal), `closedStages`, `tiers` (empty: no tier filter), `clientStatus` (empty: no status filter), `excludeTypes` (empty: the $0 and internal-or-test-name fallback applies), `territoryRegion`, `forecastScale` (most confident first, each `{value, atRisk}`).
- **`crmFieldsSource`** is `backstory_fields`, `salesforce`, `mixed` or `unavailable`.

### Account analysis file (`accounts/<id>.json`)

Every account in `population.json` gets one, named by its `id`. The minimum, for every account:

| Key | Type | Notes |
|---|---|---|
| `id` | string | As in `population.json` |
| `areas` | array | Six areas in framework order, each at least `{key, status, finding}`; `clientStated` where it applies (Area, below) |
| `activity` | object | `captured` (int: email, meeting and call summaries captured in the 90-day window, plus executive notes from Salesforce when connected), `outreachSeen` (bool: your team's outreach visible, answered or not), `lastTwoWay` (date or null) |
| `captureGap` | string or null | Why Backstory may not see this account's contact: `personal_domain`, `executive_covered`, or a short reason. Null when none |

For an account whose areas give Critical or High (framework.md §5), the full write-up, in the shapes defined below for `accounts[]`: `areas` complete with insights, `primaryDriver`, `secondaryDrivers`, `assessment`, `actions`, `conflicts`, `recentActivity`, `people`, `relatedAccounts`, and `comparison` (the line shown under the team's forecast, framework.md §8). `assemble.py` adds everything else (level, region, owners, renewal, the CRM fields into `crmView`) from `population.json`, and refuses a Critical or High account without its write-up.

## Top level

```json
{
  "meta": { ... },
  "coverage": { ... },
  "accounts": [ ... ]
}
```

## meta

| Key | Type | Notes |
|---|---|---|
| `company` | string or null | Your company's name from `settings.json → company.name`, shown in the masthead; null shows none |
| `title` | string | "Renewal risk brief" |
| `asOf` | date | The run date in `company.timezone`. All day counts use it |
| `builtAt` | string | ISO timestamp with offset, for "Data as of" |
| `scope` | object | `regions` (array of the region values found in the instance, in display order; empty when region isn't configured or couldn't be read), `windowStart` (date), `windowEnd` (date), `tiers` (array, the values found; empty when no tier filter applies), `excludeAccountTypes` (array, optional). Shown in the page's "Scope of this analysis" section; `regions` also builds the region filter |
| `crmForecast` | object | `field` (the label found, or null) and `values`: the forecast values found in the instance, most confident first, each `{value, atRisk}` (framework.md §8). Empty list when no forecast field is configured or it couldn't be read |
| `sources` | object | `renewalList`: `backstory`; `crmFields`: `backstory_fields`, `salesforce` (all read from a Salesforce connector), `mixed` (some from each) or `unavailable` (none could be read) |

## coverage

| Key | Type | Notes |
|---|---|---|
| `reviewed` | int | Accounts analysed (all in scope) |
| `reviewedValue` | number | Their total renewal value |
| `shown` | int | Must equal `accounts.length` |
| `byLevel` | object | `critical`, `high`, `medium`, `low` counts across all reviewed |
| `atStakeValue` | number | Total renewal value of Critical and High accounts (all, not just shown) |
| `notFlaggedByForecast` | object | `count` and `value`: Critical and High accounts (all, not just shown) that the team's forecast doesn't flag, including those with no forecast |
| `byRegion` | object | Keyed by each value in `meta.scope.regions`: `reviewed`, `reviewedValue`, `critical`, `high`, `shown` (must equal the shown accounts in that region) |
| `pool` | array | **The whole renewal pool, for the monthly chart**, aggregated with no account names: one row per combination of `region` (a value in `meta.scope.regions`, or null when that list is empty), `month` (`YYYY-MM` of the renewal date), `level` (`critical`, `high`, `medium`, `low`) and `forecast` (a value in `meta.crmForecast.values`, or null when not set), with `count` (accounts) and `value` (renewal value). Covers every reviewed account, not just the listed ones |
| `topArea` | object or null | `key` (area key), `count`: the area that is most often the primary driver among Critical and High accounts; ties go to the area with more renewal value at stake. Null when no account is Critical or High |

## accounts[] (shown accounts only, in rank order)

| Key | Type | Notes |
|---|---|---|
| `id` | string | Backstory account id |
| `name` | string | Account name |
| `region`, `tier` | string or null | Null when not configured |
| `territory` | string or null | Optional: the account's sales territory, shown with the region |
| `owner` | string | Account owner name |
| `clientServicesOwner` | string or null | |
| `level` | `critical` or `high` | Only these are shown |
| `renewal` | object | `date` (earliest renewal date: the configured renewal date field when set, otherwise the close date), `noticeDate` (client notice date: the notice date field when configured and set, otherwise renewal date minus `clientNoticeDays`), `value` (number), `overdue` (bool, optional: the date has passed and the renewal is still open; shown as "overdue") |
| `primaryDriver` | object | `area` (area key), `label`, `tracked` (bool: one of `settings.json → churnDrivers`), `summary`: one short line (aim for 60 characters, warning above 70) saying what's wrong, shown under the area name in the ranked table, e.g. "Champion left; no senior contact since September". Required |
| `secondaryDrivers` | array | Up to 2 of `{area, label, tracked}` |
| `assessment` | string | 2–3 sentences |
| `actions` | array | 1–3 items, exactly one with `primary: true`, listed first. See **Action** below |
| `areas` | array | Exactly six, one per area key, in framework order. See **Area** below |
| `conflicts` | array of strings | CRM data versus evidence; may be empty |
| `recentActivity` | object | `mode`: `last7` or `mostRecent`; `note` (e.g. "No activity in the last 7 days. Most recent: Nov 6, 10 days ago"); `items`: array of `{date, text, kind}` (`email`, `meeting`, `call`, `news`, `other`) |
| `people` | array | `{name, title, lastTwoWay (date or null), status}`; status `engaged`, `quiet`, `one_way`, `left` |
| `relatedAccounts` | array | `{name, note}`; may be empty |
| `crmView` | object | `forecast` `{value}`: the forecast value shown in the table (one of `meta.crmForecast.values`, or null); `comparison`: up to three lines (about 250 characters) on where Backstory's read and the CRM fields align or diverge (framework.md §8; warning above 300 characters); `opportunities`: array of `{name, date, value, forecast, atRiskReason}`, one per renewal opportunity (listed in the Activity tab; their at-risk reasons fill the CRM view's card); `sentiment` `{value: green/amber/red or null, date, note}`; `engagementScore` `{value, asOf, previous, previousAsOf}`; `managerNote` `{text, date}` or null (the forecast owner's note on the renewal, when a manager note field is configured); `source` (as in `meta.sources.crmFields`) |

### Area

| Key | Type | Notes |
|---|---|---|
| `key` | string | Area key (below) |
| `status` | string | Area severity: `critical`, `high`, `medium`, `low` (framework.md §3). Every area is rated; `no_data` is no longer accepted |
| `clientStated` | boolean | Optional. `true` only on a `critical` area whose decisive evidence is the client's own words (cancelling, cutting, reviewing the subscription, another provider chosen, the product not used). Lets that area set a Critical level alone (framework.md §5) |
| `finding` | string | One line: the conclusion for this area. Shown in the collapsed row |
| `driver` | object or null | `{label, tracked}`: the driver this area represents when flagged. Not rendered as a badge in the breakdown: say it in the first insight's explanation |
| `insights` | array | **Why we believe this.** Required for every area: 1–3 insights for `critical`, `high` and `medium` (arguing the risk); exactly one for `low` (arguing the health; evidence-guidelines.md). Each insight: `headline` (the claim, one sentence), `explanation` (2–4 sentences of rationale and nuance: what the evidence shows, why it matters for this renewal, what's absent that should be there; for an absence, what was looked at and over what window), `evidence` (array of real events: at least one in a flagged area; in a `low` area, present when there's a real healthy event and empty when the conclusion rests on an absence) |

**Evidence event** (inside an insight), every field rendered the same way: `date` (date, month like `2026-10`, or a span like "90 days"); `kind` (`email`, `meeting`, `call`, `news`, `score`, `field`, `web`, `other`), shown as the icon; `title` (what happened, one line); `narrative` (one or two sentences: who was involved, what happened, and what it tells us; required); `quote` (`{text, speaker}`, optional, **verbatim text only**: Backstory's summaries and SalesAI answers never go here, so it's normally absent; evidence-guidelines.md); `source` (`activity`, `news`, `salesforce` for one of the CRM's field values, read through Backstory or a Salesforce connector, `salesai`, `web`).

### Action

| Key | Type | Notes |
|---|---|---|
| `title` | string | The action as a one-line imperative, specific to this account: who does what, to whom, and toward what ("Ask the CTO to introduce her successor before she steps back"). Shown as the action's heading in the ranked table (primary action), the Summary and the Action plan |
| `move` | string | Key from `settings.json → moves` when one fits, otherwise `other`; used for the icon only (the title says what the action is) |
| `who` | string | Role or named owner, as shown ("CRO", "Blake Example, with a solutions specialist") |
| `role` | string | Optional: the role or person whose time the action takes ("CRO", "Sales leader, North America", "Blake Example"), used to count each person's load per week |
| `by` | date | Deadline (see actions.md) |
| `primary` | bool | Exactly one true |
| `why` | string | One line tying the move to the evidence |
| `objective` | string | What a good outcome looks like, concretely ("A named senior contact confirms who owns the renewal") |
| `steps` | array of strings | Concrete steps in order. Required, non-empty |
| `talkingPoints` | array of strings | What to say or ask; optional |

### Area keys, in order
`business_health`, `value_satisfaction`, `relationship_depth`, `engagement_momentum`, `commercial`, `renewal_readiness`

### Rules the build script enforces
- All required keys present; enums valid; six areas, one per key, in order.
- `accounts` contains every `critical` and `high` account (their count equals `byLevel.critical` + `byLevel.high`) and nothing else, ordered by level, then renewal value (descending), then notice date. Above `brief.warnShownPerRegion` in one region, the build warns.
- Each account's region is one of `meta.scope.regions` (when that list isn't empty); `coverage.byRegion` matches the shown accounts.
- Forecast values are in `meta.crmForecast.values`; every account has a comparison; `coverage.notFlaggedByForecast.count` is at least the number of shown accounts the team's forecast doesn't flag.
- Each account's `level` follows from its area ratings by the corroboration rules (framework.md §5); `clientStated` is a boolean, true only on a `critical` area, and needs an evidence event from an email, meeting or call (source `activity`).
- **Warnings, not errors:** the level distribution across `coverage.byLevel` is checked against `settings.json → calibration` (Critical and High share, Critical share, Medium the largest group). The build also warns when one person or role has more than `brief.maxLeaderActionsPerWeek` actions due in the same week.
- The primary driver's area is rated `critical` or `high`; secondary driver areas are `critical`, `high` or `medium`; every driver carries `tracked` (true or false).
- 1–3 actions, exactly one primary, first in the list; `move` is a key in settings or `other`; `by` is a valid date; each has a title, an objective and at least one step.
- Every area has at least one insight, including `low` areas (exactly one there; more is an error); `no_data` is rejected; every insight has a headline and an explanation; every insight in a flagged area has at least one evidence event (a Low area's insight may have none when it rests on an absence); every event has a date, kind, title, narrative and source; quotes have text.
- `coverage.shown` equals the number of accounts.
- `coverage.pool` adds up to `reviewed` and `reviewedValue` (within 1%), matches `byLevel` and each region's `reviewed`, and its Critical and High rows match the listed accounts by region and renewal month.
