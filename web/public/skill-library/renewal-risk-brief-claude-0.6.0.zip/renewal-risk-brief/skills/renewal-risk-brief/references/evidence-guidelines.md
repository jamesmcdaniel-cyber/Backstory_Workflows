# Evidence guidelines

What a convincing risk breakdown looks like. These describe intent, not quotas: use judgment about how much each area needs. The build script checks only that the structure is there.

The bar: a CRO who opens an account should understand **why** each area is rated as it is, from specific, dated evidence, without having to go and look anything up. That holds for Low areas too: "low" is a conclusion, and it needs its evidence like any other.

## The shape of a flagged area (Critical, High or Medium)

1. **Finding**: one line, the conclusion. It's all a reader sees when the area is collapsed, so make it stand on its own: "The main user appears to have left; no other senior contact engaged."
2. **Why we believe this**: the depth layer, as 1–3 **insights**. This is where the richness lives, so don't hold back on nuance. Each insight has:
   - **Headline**: the claim, in one sentence a CRO would repeat ("Our champion has left, and she was the only senior relationship").
   - **Explanation**: 2–4 sentences of rationale. What the evidence shows; why it matters for *this* renewal (timing, value, who decides); what's absent that should be there; how confident the conclusion is and why. Bring in your own context where it sharpens the point: the notice date, the engagement score threshold, what your CRM fields say.
   - **Evidence**: the events that prove the headline, strongest first. Every event uses the same format so the panel stays clean:
     - `title`: what happened, in one line ("Quarterly call declined").
     - `date` and `kind` (shown as the date on the right and an icon on the left).
     - `narrative`: one or two sentences covering who was involved, what happened, and what it tells us. Write it as prose; don't split it into fields. When it reports what someone said, attribute it and say it's from a summary: "Backstory's summary of the Oct 27 call: the client's head of operations said every vendor will be reviewed after the merger."
     - `quote`: only for text that is **verbatim**, with the speaker. Backstory's tools return summaries, not the text of emails or transcripts, and SalesAI paraphrases even inside quotation marks, so today there is normally no quote. Never put a summary or a SalesAI answer in `quote`; never invent or tidy one.
3. **Driver**: when the area is the primary or a secondary driver, say so inside the first insight's explanation, in plain words, and whether it's one of the tracked churn drivers ("This is the main reason Contoso is rated Critical, and it's one of the churn drivers the team tracks."). No separate line or badge.

## The shape of a Low area

1. **Finding**: one line saying why the area looks healthy, specific to the account: "Engagement score steady at 8; no complaints in 90 days", not "No issues".
2. **One insight** on the healthy side:
   - **Headline**: the reassuring claim ("Usage is strong and steady").
   - **Explanation**: one or two sentences on what the evidence shows and why it lowers the risk for this renewal. When the area leans healthy on an absence, say what absence means here ("A merger would normally surface in the news or in conversation; neither shows one.").
   - **Evidence**: only real events. When there's **healthy evidence** (a reply, a meeting held, a score reading, a renewal call with the decision-maker), show it as evidence, strongest first.
   - When the area looks healthy because something is **absent** (no price talk, no news of a merger), there's no evidence list: the explanation names what was looked at and over what window ("No mention of price, budget or other vendors in 90 days of email, meetings and Salesforce notes."). Never write the check itself up as an evidence event.
3. Don't invent a positive to fill the slot. If the only support is an absence, say so plainly in the explanation.

Every area's reasoning sits under the same label, "Why we believe this". The area's rating sets its one marker, shown before each insight (an alert icon in the severity colour for Critical, High and Medium; a check icon for Low). Insights in a flagged area argue the risk; an insight in a Low area argues the health. When healthy evidence lowered a flagged area's rating by a level (framework.md §3), include it as one of that area's insights.

## Principles

1. **No claim without a dated source.** An email, meeting or call with its date, a news item, an engagement score reading with its month, a field change.
2. **Depth over volume.** Two well-explained insights beat five thin ones. Pick the events that carry the argument, and spend the words on what they mean.
3. **Observed facts and interpretation stay apart.** Event titles and quotes state what was seen or said; headlines, explanations and narratives carry the interpretation.
4. **Attribute what people said, and check who said it.** The most persuasive evidence is what the client said. It reaches us through Backstory's summaries, so write it as attributed paraphrase in the narrative, naming the speaker and the email, meeting or call. Before using it, check the speaker against the account's client contacts and your own company's staff: the summaries sometimes swap buyer and seller. Statements from a filing, news or SalesAI are never the client speaking to you. Prefer account-level activity: activity is sometimes matched to the wrong opportunity (a renewal meeting filed under a new-sale opportunity), so use opportunity-level activity to add detail, not as the only source.
4a. **Dates.** Every event has a date. When a source gives only a period (an undated news item, a weekly digest), use the span ("Nov 2–9", "2026-10") and never invent a day.
5. **Missing data is stated, not hidden, and still rated.** There's no "couldn't be assessed": each area's definition (framework.md §1) says whether missing data leans healthy or toward risk. Say what was missing and what was checked.
6. **People by name and title only.** No email addresses, phone numbers or personal details. `get_engaged_people` returns email addresses: drop them before writing anything.
7. **Know what Backstory can't see before calling something quiet.** Absence of activity is evidence only where Backstory would have captured it:
   - **Executive contact:** some executives keep their email out of Backstory and log client conversations as Salesforce notes or tasks, which Backstory doesn't capture. Before rating Relationship depth or Engagement momentum on silence, check for them: in the account's activity in Backstory, by asking SalesAI about recent executive contact, and, when a Salesforce connector is available, in the account's Salesforce notes and tasks directly. If an executive is in contact, say so and rate accordingly. If the check can't rule out unseen contact, the area is `medium` at most (framework.md §3).
   - **Personal email domains:** clients who use Gmail, Yahoo, AOL or similar addresses aren't captured. When an account's contacts use them, the areas that depend on email are rated `medium` at most on silence, with the capture gap named in the explanation, rather than "gone quiet".
   - **Calls:** call activity comes through the Backstory MCP like any other activity; call notes or recordings logged in Salesforce count too, read from Backstory's activity or from Salesforce when connected.

## Writing

- Plain, compact, specific. Short sentences; no filler, no hedging stacks ("may potentially").
- Use the team's own renewal vocabulary: renewal pool, notice date, account owner, customer success, engagement score, sentiment.
- Don't build arguments on contract mechanics that aren't confirmed for that contract: auto-renewal, or notice periods for price increases.
- Dates as "Nov 6"; ages as "21 days ago"; money as "$185K".
- Mark anything inferred by SalesAI or web search as such (`source`), and confirm consequential SalesAI claims against the activity itself.

## Recent activity

Show the last `recentActivityDays` days. If there's nothing in that window, show the most recent activity with its age ("No activity in the last 7 days. Most recent: Oct 21, 26 days ago"). The gap is evidence for Relationship gone quiet.

## Conflicts

Write a conflict line whenever your CRM data and Backstory's evidence disagree (framework.md §4). Conflicts are among the most useful lines in the brief: they show where the rep's view and the evidence part ways.
