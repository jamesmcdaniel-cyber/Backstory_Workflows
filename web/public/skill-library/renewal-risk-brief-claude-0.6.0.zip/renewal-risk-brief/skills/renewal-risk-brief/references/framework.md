# Risk framework

How every account is assessed. The overall risk call is built from six areas of account health; each area gets a status, a one-line finding and the evidence behind it. This is the analysis standard. The thresholds come from `settings.json → thresholds`. Treat the checks as what to look for, not a scoring formula: judgment matters, and every judgment must be traceable to evidence.

## 1. The six areas

Five areas carry one of the tracked churn drivers (★, §2). The sixth, Renewal readiness, is Backstory's addition. Every area is defined the same way: what it covers, the question it answers, the risk evidence by strength, the healthy evidence, the absences that reassure, which way missing data leans, and what belongs in another area. The strength of the evidence sets the area's rating (§3). Thresholds come from `settings.json → thresholds`.

**Two-way contact** means the client replied, attended or initiated. Rep emails with no reply don't count. Backstory's activity comes as summaries, often weekly digests that don't say who replied, so count only what the summary shows: a meeting held with client attendees, a call with the client, or an email the summary attributes to a named client contact. Check every name against the account's client contacts and your own company's staff first: the summaries sometimes swap buyer and seller.

### Client business health (`business_health`) ★ Customer M&A or restructuring

- **Covers:** changes in the client's own business that could remove the need, the budget or the person who decides, however well you serve them.
- **Question:** Is anything changing at the client that could put the subscription under review?
- **Decisive:** an announced merger, acquisition, wind-down or business closure that moves or removes the renewal decision; the client says the subscription is under review because of it.
- **Strong:** restructuring or layoffs in the team that uses the product; a new executive who owns the budget or the decision **arriving** (a departure is Relationship depth when that person was a contact); a strategy shift away from what the product supports; vendor or tool budgets being consolidated.
- **Parent companies:** news about the client's parent counts only when it reaches the entity you serve (its budget, its team or who decides). Otherwise it's at most early evidence.
- **Early:** falling revenue or weak results; a hiring freeze; rumours or passing mentions of change.
- **Healthy:** growth, new business lines or markets; hiring in the team that uses the product; expanding use.
- **Reassuring absence:** no news or mention of M&A, restructuring or leadership change in the last `businessNewsLookbackMonths` months.
- **No data:** leans healthy (`low`). The explanation says what was searched (company news, the web, conversations with your team) and over what window. For private companies with little press coverage, say so.
- **Not here:** one key person leaving is Relationship depth, unless it's part of a restructuring. Budget cuts the client raises with you are Commercial.

### Value and satisfaction (`value_satisfaction`) ★ Low value or dissatisfaction

- **Covers:** whether the client uses the product and finds it worth paying for.
- **Question:** Are they using the product, and are they happy with it?
- **Decisive:** the client says the product isn't used or useful, or asks to cut seats or products because of value; a steep fall in the engagement score together with a complaint.
- **Strong:** engagement score at or below `engagementScoreLow`, or a drop of `engagementScoreDrop`+ points against the prior reading; an explicit complaint or an unresolved support issue.
- **Early:** the score slipping by one or two points; mild dissatisfaction; only one or two active users.
- **Healthy:** a score of `engagementScoreHealthy` or more, steady or rising; the client cites results from the product, joins training or product sessions, or asks for specialist help or new use cases; positive feedback.
- **Reassuring absence:** no complaints or support issues in the last `complaintLookbackDays` days.
- **No data:** the engagement score is an **optional** field. A score missing on this account while others have one leans risk (`medium`: "no usage recorded"). If no score field is mapped, or the score can't be read for the whole run, rate from conversations only and say so; with no complaints, that's `low`.
- **Sentiment** (optional field) adjusts only this area (§4): a current red rating moves a `medium` rating to `high`; green never clears evidence of a problem; a rating older than `sentimentStaleDays` is noted as stale and doesn't adjust. Without a sentiment field, nothing adjusts.
- **Not here:** price objections are Commercial; silence is Engagement momentum.

### Relationship depth (`relationship_depth`) ★ Key user or champion gone

- **Covers:** how broad and senior your relationships at the client are.
- **Question:** Who do we know there, how senior are they, and would the renewal survive one person leaving?
- **Decisive:** the champion or main user has left with no replacement contact; a new decision-maker who has never engaged with your team is reviewing vendors.
- **Strong:** single-threaded (one client contact in two-way activity over `singleThreadedLookbackDays` days); no contact with the budget holder; a previously engaged key contact gone silent.
- **Early:** all contacts junior; the champion's role has changed; a new decision-maker not yet met, with no sign of a review.
- **Healthy:** several engaged contacts, including the decision-maker; a senior contact in the last 90 days; specialists or support staff with their own relationships at the client.
- **Reassuring absence:** no bounced emails and no mention of departures.
- **No data:** no engaged contacts leans risk: `high` inside the readiness window (`readinessStartDays` before the renewal date), `medium` before it, never `critical`. When a capture gap could explain it, `medium` at most. With no captured activity at all, follow §3, "No captured contact".
- **Not here:** how often we talk is Engagement momentum.

### Engagement momentum (`engagement_momentum`) ★ Relationship gone quiet

- **Covers:** whether two-way contact keeps pace with what the renewal needs.
- **Question:** Is the client still talking to us, and is it slowing down?
- **Decisive:** past the client notice date, with no two-way contact for `quietDaysNearRenewal` days or more and the account owner's outreach unanswered. This is the only case where silence alone is `critical`.
- **Strong:** no two-way contact for `quietDaysDefault` days (`quietDaysNearRenewal` when the renewal is under `nearRenewalDays` away); outreach unanswered; meetings declined or cancelled.
- **Early:** contact frequency falling against the prior period; slower replies; most activity one-way.
- **Healthy:** two-way contact in the last `healthyContactDays` days; meetings held; the client initiates.
- **Reassuring absence:** no declined or cancelled meetings.
- **No data:** with no captured activity at all, the rating comes from §3, "No captured contact": it depends on whether Backstory could see the contact, the engagement score (when one is mapped) and time to renewal. A client using the product heavily but not answering sales emails can be healthy: usage, when you can measure it, says more than sales contact.
- **Not here:** who we talk to is Relationship depth; whether the renewal itself is being discussed is Renewal readiness.

### Commercial and competitive (`commercial`) ★ Commercial pushback

- **Covers:** anything threatening the price, the budget or the choice of your product.
- **Question:** Is anything threatening the price or the decision to renew?
- **Decisive:** cancellation or non-renewal language; a formal request to downsize the subscription; a competitor already chosen.
- **Strong:** pushback **tied to a threat to the renewal**: the client links price to cutting seats or products, to not renewing, or to a budget cut or freeze that hits this spend; active evaluation of another vendor, an in-house build or an AI tool.
- **Early:** ordinary negotiation: questions about price, a discount request, pushback on a price increase with no threat attached, procurement getting involved, a competitor mentioned in passing. Late-stage renewals are negotiated as a matter of course, so this alone is never more than `medium`.
- **Recency:** commercial evidence older than `commercialRecencyDays` (45) counts one level lower, unless it was never resolved.
- **Boundary examples:** "Can you do better on price?" is early. "We need 10% off or we'll drop the analytics add-on" is strong. "Budget is frozen for next year; we're reviewing all subscriptions" is decisive if it names your subscription, strong if it doesn't. A competitor's trial running in parallel is strong.
- **Healthy:** budget confirmed; pricing accepted; interest in adding seats or products.
- **Reassuring absence:** no discussion of price, budget or alternatives in the lookback window.
- **No data:** leans healthy (`low`), stated as an absence; the explanation names the window and sources looked at.
- **Not here:** dissatisfaction with the product itself is Value and satisfaction.

### Renewal readiness (`renewal_readiness`), Backstory's addition

The final stretch before the renewal: the readiness window opens `readinessStartDays` (120 by default) before the renewal date, and the renewal should be confirmed before the client notice date (the optional notice date field where it's mapped and set, otherwise the renewal date minus `clientNoticeDays`). Earlier lifecycle steps (onboarding, value reviews, mid-term check-ins) aren't assessed: they need a year of dated activity, and the Backstory MCP's activity tools reach back 90 days.

- **Covers:** whether the renewal itself is being actively worked, with the person who decides, in the final stretch before the renewal date.
- **Question:** Is this renewal being worked with the decision-maker in time for the notice date?
- **Decisive:** past the client notice date, with no renewal proposal sent and no renewal conversation with the client.
- **Strong:** inside the readiness window with no renewal conversation with the decision-maker.
- **Early:** the renewal is being discussed, but not with the decision-maker, or without a dated next step.
- **Healthy:** a renewal conversation with the decision-maker since the readiness window opened; the renewal proposal sent; a dated next step before the notice date.
- **Reassuring absence:** before the readiness window opens, "not yet due" (`low`); the explanation gives the date it opens.
- **No data:** inside the readiness window, silence on the renewal leans risk. When a capture gap could explain it, `medium` at most.
- **Not here:** general contact frequency is Engagement momentum; price pushback in renewal talks is Commercial.

## 2. The tracked churn drivers

The five starred labels are the default churn drivers in `settings.json → churnDrivers`. Edit that list to use your own team's names for why clients churn; keep one per starred area. Use the labels exactly, wherever they apply, marked as tracked drivers in the data (`tracked: true`).

1. Customer M&A or restructuring
2. Low value or dissatisfaction
3. Key user or champion gone
4. Relationship gone quiet
5. Commercial pushback

When a finding doesn't fit a tracked driver, name the specific check instead (`tracked: false`), for example "Single-threaded relationship", "Renewal not yet raised", "No contact with budget holder".

## 3. Area severity

Each area is rated on the same scale as the account levels, so the badges read consistently across the page. **Every area is rated: there's no "couldn't be assessed".** Each area's definition (§1) says which way missing data leans.

| Severity | When |
|---|---|
| `critical` | Decisive risk evidence for the area (§1) |
| `high` | Strong risk evidence |
| `medium` | Early risk evidence, or strong evidence offset by healthy evidence, or a risk reading that a capture gap could explain |
| `low` | Only healthy evidence or reassuring absences |

**Combining evidence:**
- Healthy evidence can lower a rating by **one level** (for example `high` to `medium`), with both sides shown in the insights. It never clears decisive evidence.
- **Capture gaps cap at `medium`.** When the absence of activity could be explained by what Backstory can't see (an executive's own email, a personal email domain), the area is `medium` at most, and the explanation says so (evidence-guidelines.md, principle 7).

### No captured contact

When an account has **no captured activity** in the 90-day window (no email, meeting or call summary at all), silence can mean a quiet but happy client or a client slipping away. Decide which with this table, never by feel, so every run reads the same situation the same way. `assemble.py` checks it. When no engagement score field is mapped, every account counts as "missing" in this table.

| Situation | Reading | Engagement momentum | Relationship depth |
|---|---|---|---|
| **Backstory can't see the contact:** the account owner has no captured activity anywhere in the run (mailbox probably not connected), the client's contacts use personal email domains, or the account is covered by an executive who logs contact by hand in Salesforce (Backstory doesn't capture manual Salesforce notes) | Blind spot | `medium` at most, gap named | `medium` at most, gap named |
| Visible, engagement score healthy (`engagementScoreHealthy` or more), before the readiness window | Quiet but using the product | `low` | as its own rules, never `critical` |
| Visible, score healthy, inside the readiness window | Renewal not yet being worked | `medium` | as its own rules, never `critical` |
| Visible, score middling (between `engagementScoreLow` and `engagementScoreHealthy`) | Unclear | `medium` | as its own rules, never `critical` |
| Visible, score low (`engagementScoreLow` or below), falling (`engagementScoreDrop`+), or missing | Silence and low usage | `high` | as its own rules, never `critical` |

Silence alone is never `critical` here: with nothing captured, there's no unanswered outreach to point to. Record `activity.captured`, `activity.outreachSeen` and any `captureGap` in the account file (data-schema.md). When a Salesforce connector adds executive notes or tasks, count them as captured activity.

**Every area carries evidence, whatever its rating.** Areas rated `critical`, `high` or `medium` are **flagged** and carry 1–3 insights on the risk. Areas rated `low` carry **one insight** on why the area looks healthy: a real healthy event shown as evidence, or, when the conclusion rests on an absence, an explanation naming what was looked at and over what window, with no evidence list. The rating sets one marker per area, risk or healthy: it shapes the writing, and the page shows it before each insight.

## 4. How your CRM data is weighed

Backstory's read of conversations and activity leads. Your CRM fields add what Backstory can't see. Every field below is optional: when it isn't mapped, the rule that uses it simply doesn't apply.

- **Engagement score can raise risk on its own** in Value and satisfaction: at or below `engagementScoreLow`, or a drop of `engagementScoreDrop`+ points against the prior reading, is enough for `high` (or `critical` with a steep drop). It measures product usage, which Backstory cannot observe. Set the three score thresholds on your score's own scale.
- **Sentiment only adjusts, and only Value and satisfaction.** A current red rating moves Value and satisfaction from `medium` to `high` when the area already has risk evidence of its own. It never flags an area alone (a `low` area stays `low`), never makes an area `critical`, and never changes another area or the account level directly: the level moves only if Value and satisfaction then sets it. Amber doesn't adjust. A rating older than `sentimentStaleDays` doesn't adjust; it's noted as stale. A green rating never clears a risk that the evidence shows. Whenever sentiment and the evidence disagree, write a conflict line. **With no sentiment date** (the date isn't mapped, or is empty), sentiment is shown but never adjusts: its age can't be judged.
- **Conflicts are shown, not resolved silently.** Whenever your CRM data and Backstory's evidence disagree, write a conflict line, for example "Sentiment green (set Sep 12), but no reply from the client in 54 days." Always date CRM values; stale ratings are part of the story.
- **The team's forecast, the manager note and (when mapped) the at-risk reason are compared, never used to set a level.** The forecast owners set the forecast and any manager note; an at-risk reason may be filled automatically. The page shows the forecast next to Backstory's level in the ranked table and both in the CRM view tab (§8). Write a conflict line when they disagree with the evidence (for example marked Commit while the main contact has left).
- **Capture gaps are not silence.** Executives who keep their email out of Backstory and log client conversations in Salesforce by hand, and clients on personal email domains (Gmail, Yahoo, AOL and similar), aren't captured. See evidence-guidelines.md before rating an area on the absence of activity. Backstory doesn't capture manual Salesforce notes, so contact logged that way is invisible unless a Salesforce connector is available.

## 5. Risk levels

**Corroborated.** An account's level comes from its six area ratings, but one signal alone never sets it: a second flagged area has to back it up. One strong signal on its own puts the account a level lower. The judgment happens when rating each area (§3); the level then follows from these rules, so anyone can check it, and the build script rejects a level that doesn't match.

**Flagged** means an area rated `critical`, `high` or `medium`.

| Level | Rule | Leadership response |
|---|---|---|
| **Critical** | An area rated `critical` and at least one other flagged area. **Or** an area rated `critical` on the client's own words (below), even alone | A leader steps in this week |
| **High** | Not Critical, and: an area rated `critical` with no other flagged area; or two areas rated `high`; or one area rated `high` and at least one rated `medium` | A leader steps in before the client notice date (or within two weeks if it has passed) |
| **Medium** | One area rated `high` and every other area `low`; or one or more areas rated `medium` | The account owner acts; leadership informed |
| **Low** | All six areas `low` | No action |

**The client's own words.** A `critical` area stands alone when the decisive evidence is the client itself saying the renewal is threatened: it will cancel or not renew; it wants to cut seats or products; the subscription is under review; it has chosen another vendor; the product isn't used. Mark that area `clientStated: true` (data-schema.md). Backstory's tools return summaries, not the text of emails or transcripts, so the client's words are a statement a summary **attributes to a named client contact**, from an email, meeting or call:
- check the speaker is one of the client's contacts, not your own staff (the summaries sometimes swap sides);
- the statement is about this renewal or subscription, not your company in general;
- prefer it when two summaries carry it (the account's and the renewal opportunity's activity);
- **never** from news, a filing (an 8-K is the company speaking to investors, not to you), the web or SalesAI alone.

Cite it as an evidence event from the activity, attributed and marked as a summary (evidence-guidelines.md). The build rejects `clientStated` without such an event. Decisive evidence that isn't the client speaking (a merger announced in the press, a bounced email, silence past the notice date) needs a second flagged area like any other.

**Say why in the assessment.** The assessment names the areas behind the level, so the rule can be read: "Critical: the client has asked to drop two products, and the renewal hasn't been discussed with the decision-maker." For a High account with an uncorroborated `critical` area, say that the rest of the account looks healthy.

**Expect a bell curve.** Across the whole book, most accounts should be Medium, fewer High and Low, and only a few Critical. The ratings come from the evidence, never from a quota, but a skewed distribution usually means the areas were rated too strictly or too loosely: check it after rating every account (SKILL.md, step 4; `settings.json → calibration`).

**Timing doesn't set the level.** In a short renewal window many client notice dates have passed or fall within weeks, so timing can't tell accounts apart. It's still used to rank accounts within a level (§7) and to set action deadlines (actions.md).

**Rating an area `critical` versus `high`:** `critical` needs direct, recent evidence that the renewal itself is threatened, for example a bounced email from the only senior contact, the client saying it will cut or review the subscription, or a merger that moves the decision elsewhere. Strong evidence of a problem that hasn't yet reached the renewal (silence, a falling score, a single contact) is `high`; silence is `critical` only past the client notice date with outreach unanswered (§1, Engagement momentum). Rate each area on its own evidence: never raise one area because others are flagged, since the level rules already count them.

Don't assume a renewal is secured from contract mechanics (auto-renewal, notice terms, price-increase rules) unless they're confirmed for that contract. Judge the renewal from the evidence.

## 6. Drivers

- **Primary driver:** the area most responsible for the level. It must be rated `critical` or `high`. Label it with the tracked churn driver when one applies.
- **Secondary drivers:** up to two more, from areas rated `critical`, `high` or `medium`. The page doesn't badge drivers inside the breakdown: weave it into the first insight's explanation instead ("This is the main reason Contoso is rated Critical, and it's one of the churn drivers the team tracks.").
- **Driver summary:** one short line (aim for 60 characters) saying what's wrong in the primary driver area, shown under the area name in the ranked table. It's the line a leader reads to decide whether to open the account, so make it concrete and specific to the account: "Champion left; no senior contact since September", "Benchmarking an AI tool after a 4% increase". Not a restatement of the area name, and no hedging.
- The assessment (2–3 sentences) explains the level in plain language: what is happening, why it matters for this renewal, and the time pressure.

## 7. Ranking

1. Level: Critical, then High.
2. Within a level: renewal value at stake, largest first.
3. Ties: the earlier client notice date first.

Rank across all regions and list every Critical and High account. Medium and Low accounts are analysed and counted, and appear in the monthly chart's totals, but aren't listed. When regions are available, the page's region filter shows each region's accounts in the same order.

## 8. Comparison with the team's forecast

The team's own forecast says where the forecast owners already see risk. By default it's Salesforce's standard Forecast Category (`ForecastCategoryName`); values below the top one (Best Case and Pipeline, below Commit) count as at risk, following `settings.json → crmForecast.atRiskRule`. The brief shows that view next to Backstory's, so leaders can see where the two agree and where Backstory sees risk the forecast hasn't flagged. The forecast is optional: without it, the page leaves the comparison out.

- **Read the scale from the instance.** Before analysing, read the forecast values actually used (data-collection.md §2). Record them in `meta.crmForecast.values`, highest confidence first, each with `atRisk` set by `crmForecast.atRiskRule`. Never hardcode or invent values. If you can't tell which values count as at risk, treat every value below the top one as at risk and say so in your report.
- **Per account**, set `crmView.forecast.value` to the forecast of the renewal opportunity that matters most: the least confident one when there are several. The build script works out whether the forecast flags the account from the scale.
- **Write `crmView.comparison`**: up to three lines (about 250 characters), shown under the team forecast badge with no other label, so the first words must say how the two views relate: "Both see risk." when the forecast flags it; "Backstory sees risk the forecast doesn't." when it doesn't; "No forecast is set for this renewal." when it's empty. Then say where they align or diverge, in the team's terms where possible: the manager note, the at-risk reason when it's mapped, and what Backstory's evidence adds or contradicts.
- **Coverage:** `coverage.notFlaggedByForecast` counts every Critical and High account, shown or not, that the forecast doesn't flag (including those with no forecast), with their renewal value.
- Accounts the forecast flags that Backstory rates Medium or Low are counted in the chart but not listed.
