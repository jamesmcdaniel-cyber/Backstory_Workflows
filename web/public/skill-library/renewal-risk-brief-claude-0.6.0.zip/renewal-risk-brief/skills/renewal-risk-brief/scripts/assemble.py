#!/usr/bin/env python3
"""Assemble data.json from the renewal population and one analysis file per account, deterministically.

Usage: assemble.py <population.json> <accounts-dir> --out data.json [--rechecked "what was re-checked"]

Claude (and its subagents) write one file per account, accounts/<id>.json, holding only the judgment: the six area
ratings with their evidence, the captured-activity facts, and, for accounts that come out Critical or High, the write-up
and actions (data-schema.md, "Account analysis file"). This script does everything countable:

  - checks the "no captured contact" decision table (framework.md §3) on accounts with no captured activity;
  - sets each account's level from its areas with the corroboration rules (framework.md §5);
  - fills renewal dates, notice dates, value, region, owners and the CRM fields from population.json;
  - ranks the Critical and High accounts and builds coverage, the monthly pool and the top risk area;
  - checks the level distribution (settings `calibration`). If it's off, it lists the boundary accounts to re-check and
    exits 2; after re-checking them against the evidence, run again with --rechecked "<note>".

Exit codes: 0 written; 1 problems to fix in the account files (listed); 2 written, but calibration needs a re-check.
Then run build_brief.py on the output.
"""
import datetime
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import build_brief as bb  # noqa: E402

SETTINGS = os.path.join(HERE, "..", "settings.json")
SEV = {"low": 0, "medium": 1, "high": 2, "critical": 3}
NAME = {v: k for k, v in SEV.items()}
FULL_KEYS = ("primaryDriver", "assessment", "actions", "recentActivity", "people")


def score_band(es, th):
    """healthy, middling or low, from the account's engagement score (when mapped) and its prior reading."""
    v, p = (es or {}).get("value"), (es or {}).get("previous")
    if v is None:
        return "low"
    if v <= th.get("engagementScoreLow", 4) or (p is not None and p - v >= th.get("engagementScoreDrop", 3)):
        return "low"
    if v >= th.get("engagementScoreHealthy", 6):
        return "healthy"
    return "middling"


def no_contact_rule(pa, an, connected, th):
    """framework.md §3, "No captured contact". Returns (expected engagement_momentum, cap for relationship_depth, reason)."""
    gap = an.get("captureGap")
    if gap or not connected:
        why = gap or "the account owner has no captured activity anywhere in this run (mailbox likely not connected)"
        return None, "medium", f"capture gap ({why}): Engagement momentum and Relationship depth are Medium at most"
    band = score_band((pa.get("crm") or {}).get("engagementScore"), th)
    ready = (pa.get("renewal") or {}).get("inReadiness")
    if band == "healthy":
        return ("medium" if ready else "low"), "high", f"no contact captured, engagement score healthy, {'inside' if ready else 'before'} the readiness window"
    if band == "middling":
        return "medium", "high", "no contact captured, engagement score middling"
    return "high", "high", "no contact captured, engagement score low, falling or missing"


def boundary(areas):
    """True when lowering one flagged area by a step would change the account's level."""
    lvl = bb.expected_level(areas)
    for i, a in enumerate(areas):
        s = a.get("status")
        if SEV.get(s, 0) > 0:
            alt = [dict(x) for x in areas]
            alt[i]["status"] = NAME[SEV[s] - 1]
            if bb.expected_level(alt) != lvl:
                return True
    return False


def main():
    args = sys.argv[1:]
    if len(args) < 2 or "--out" not in args:
        print(__doc__)
        sys.exit(1)
    pop_path, acc_dir = args[0], args[1]
    out = args[args.index("--out") + 1]
    rechecked = args[args.index("--rechecked") + 1] if "--rechecked" in args else None

    with open(SETTINGS, encoding="utf-8") as f:
        settings = json.load(f)
    with open(pop_path, encoding="utf-8") as f:
        pop = json.load(f)
    th = settings.get("thresholds", {})
    errs, warns = [], []

    analyses = {}
    for pa in pop["accounts"]:
        p = os.path.join(acc_dir, f"{pa['id']}.json")
        if not os.path.exists(p):
            errs.append(f"{pa['name']}: no analysis file {p}")
            continue
        with open(p, encoding="utf-8") as f:
            analyses[pa["id"]] = json.load(f)
    if errs:
        print("\n".join(errs))
        sys.exit(1)

    owners_seen = {}
    for pa in pop["accounts"]:
        cap = ((analyses[pa["id"]].get("activity") or {}).get("captured")) or 0
        owners_seen[pa.get("owner")] = owners_seen.get(pa.get("owner"), 0) + cap

    scale = {v["value"]: v["atRisk"] for v in pop["crmForecast"].get("values") or []}
    rows, shown = [], []
    for pa in pop["accounts"]:
        an = analyses[pa["id"]]
        n = pa["name"]
        areas = an.get("areas") or []
        st = {a.get("key"): a.get("status") for a in areas}
        if [a.get("key") for a in areas] != bb.AREAS or any(s not in SEV for s in st.values()):
            errs.append(f"{n}: areas must be the six area keys in order, each rated critical, high, medium or low")
            continue
        act = an.get("activity") or {}
        if not isinstance(act.get("captured"), int):
            errs.append(f"{n}: activity.captured (number of captured activities in 90 days) is required")
            continue
        if act["captured"] == 0:
            connected = owners_seen.get(pa.get("owner"), 0) > 0
            want_em, rel_cap, why = no_contact_rule(pa, an, connected, th)
            em, rel = st["engagement_momentum"], st["relationship_depth"]
            if want_em is not None and em != want_em:
                errs.append(f"{n}: Engagement momentum is {em}, but with {why} it must be {want_em} (framework.md §3)")
            if want_em is None and SEV[em] > SEV["medium"]:
                errs.append(f"{n}: Engagement momentum is {em}, but with {why}")
            if SEV[rel] > SEV[rel_cap]:
                errs.append(f"{n}: Relationship depth is {rel}, but with {why.split(':')[0]} it can be {rel_cap} at most (framework.md §3)")
        level = bb.expected_level(areas)
        rows.append((pa, an, level))

    for pa, an, level in rows:
        if level in bb.SHOWN_LEVELS:
            missing = [k for k in FULL_KEYS if not an.get(k)]
            if missing:
                errs.append(f"{pa['name']}: comes out {level}, so it needs the full write-up; missing {', '.join(missing)}")
    if errs:
        print("Fix these in the account files, then run again:")
        print("\n".join(f"  - {e}" for e in errs))
        sys.exit(1)

    regions = pop["scope"]["regions"]
    for pa, an, level in rows:
        if level not in bb.SHOWN_LEVELS:
            continue
        b = pa.get("crm") or {}
        acct = {
            "id": pa["id"], "name": pa["name"], "region": pa.get("region") if regions else None, "territory": pa.get("territory"), "tier": pa.get("tier"),
            "owner": pa.get("owner") or "Unknown", "clientServicesOwner": pa.get("clientServicesOwner"), "level": level,
            "renewal": {k: pa["renewal"][k] for k in ("date", "noticeDate", "value", "overdue")},
            "primaryDriver": an["primaryDriver"], "secondaryDrivers": an.get("secondaryDrivers") or [],
            "assessment": an["assessment"], "actions": an["actions"], "areas": an["areas"],
            "conflicts": an.get("conflicts") or [], "recentActivity": an["recentActivity"], "people": an["people"],
            "relatedAccounts": an.get("relatedAccounts") or [],
            "crmView": {
                "forecast": {"value": b.get("forecast")}, "comparison": an.get("comparison") or "",
                "opportunities": [{"name": o["name"], "date": o["date"], "value": o["value"], "forecast": o.get("forecast"),
                                   "atRiskReason": o.get("atRiskReason")} for o in pa.get("opportunities") or []],
                "sentiment": b.get("sentiment") or {"value": None, "date": None, "note": None},
                "engagementScore": b.get("engagementScore") or {"value": None, "asOf": None, "previous": None, "previousAsOf": None},
                "managerNote": b.get("managerNote"),
                "source": pop["sources"]["crmFields"],
            },
        }
        shown.append(acct)
    shown.sort(key=lambda a: (bb.LEVEL_RANK[a["level"]], -a["renewal"]["value"], a["renewal"]["noticeDate"]))

    by_level = {lv: 0 for lv in ("critical", "high", "medium", "low")}
    pool, by_region = {}, {r: {"reviewed": 0, "reviewedValue": 0, "critical": 0, "high": 0, "shown": 0} for r in regions}
    for pa, an, level in rows:
        by_level[level] += 1
        reg = pa.get("region") if regions else None
        k = (reg, pa["renewal"]["date"][:7], level, (pa.get("crm") or {}).get("forecast"))
        e = pool.setdefault(k, [0, 0])
        e[0] += 1
        e[1] += pa["renewal"]["value"]
        if reg in by_region:
            br = by_region[reg]
            br["reviewed"] += 1
            br["reviewedValue"] += pa["renewal"]["value"]
            if level in bb.SHOWN_LEVELS:
                br[level] += 1
                br["shown"] += 1
    not_flagged = [a for a in shown if not scale.get(a["crmView"]["forecast"]["value"])]
    drivers = {}
    for a in shown:
        d = drivers.setdefault(a["primaryDriver"]["area"], [0, 0])
        d[0] += 1
        d[1] += a["renewal"]["value"]
    top = max(drivers.items(), key=lambda x: (x[1][0], x[1][1])) if drivers else None
    coverage = {
        "reviewed": len(rows), "reviewedValue": sum(pa["renewal"]["value"] for pa, _, _ in rows), "shown": len(shown),
        "byLevel": by_level, "atStakeValue": sum(a["renewal"]["value"] for a in shown),
        "notFlaggedByForecast": {"count": len(not_flagged), "value": sum(a["renewal"]["value"] for a in not_flagged)},
        "byRegion": by_region, "topArea": {"key": top[0], "count": top[1][0]} if top else None,
        "pool": [{"region": k[0], "month": k[1], "level": k[2], "forecast": k[3], "count": v[0], "value": v[1]} for k, v in sorted(pool.items(), key=lambda x: (x[0][1], str(x[0][0]), x[0][2]))],
    }

    try:
        from zoneinfo import ZoneInfo
        now = datetime.datetime.now(ZoneInfo(settings.get("company", {}).get("timezone") or "UTC"))
    except Exception:  # noqa: BLE001
        now = datetime.datetime.now().astimezone()
    data = {
        "meta": {
            "company": settings.get("company", {}).get("name"), "title": settings.get("company", {}).get("briefTitle", "Renewal risk brief"),
            "asOf": pop["asOf"], "builtAt": now.isoformat(timespec="seconds"),
            "scope": {k: pop["scope"][k] for k in ("regions", "windowStart", "windowEnd", "tiers", "excludeAccountTypes")},
            "sources": pop["sources"], "crmForecast": pop["crmForecast"],
        },
        "coverage": coverage,
        "accounts": shown,
    }
    with open(out, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print(f"wrote {out}: {len(rows)} reviewed; {by_level['critical']} Critical, {by_level['high']} High, {by_level['medium']} Medium, {by_level['low']} Low")

    cal = bb.calibration(coverage, settings)
    if cal and not rechecked:
        print("Calibration needs a re-check before publishing:")
        for w in cal:
            print(f"  - {w}")
        bnd = [pa["name"] + f" ({level})" for pa, an, level in rows if level in ("critical", "high", "medium") and boundary(an["areas"])]
        print("Boundary accounts (one area a step lower would change the level). Re-check each against the evidence;")
        print("change a rating only where the evidence supports it, then run again with --rechecked \"<what you re-checked>\":")
        for b in bnd[:40]:
            print(f"  - {b}")
        sys.exit(2)
    if cal:
        print(f"Calibration still off after re-check ({rechecked}); report the final distribution.")
    sys.exit(0)


if __name__ == "__main__":
    main()
