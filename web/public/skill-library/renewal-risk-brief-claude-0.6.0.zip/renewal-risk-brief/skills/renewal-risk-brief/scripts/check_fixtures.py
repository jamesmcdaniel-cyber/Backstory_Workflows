#!/usr/bin/env python3
"""Robustness check for the renewal risk brief.

Usage: check_fixtures.py [--out DIR]

Builds a set of awkward data cases, derived from examples/sample-data.json, and checks each one is
accepted or rejected as expected. With --out, writes every built page to DIR for visual review
(open each at desktop and phone widths). Also syntax-checks the built page's scripts when Node is
available. Exits 1 if any case behaves unexpectedly.

Run it after any change to the template, the build script or the data schema.
"""
import copy
import datetime
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import build_brief  # noqa: E402

SAMPLE = os.path.join(HERE, "..", "examples", "sample-data.json")


def load():
    with open(SAMPLE, encoding="utf-8") as f:
        d = json.load(f)
    d.pop("_about", None)
    return d


def recount(d):
    """Make coverage consistent with the accounts listed: rebuild the pool's Critical and High rows from them,
    keep the sample's Medium and Low rows, and recount the totals from the pool."""
    a = d["accounts"]
    c = d["coverage"]
    regions = d["meta"]["scope"].get("regions") or []
    rest = [p for p in c.get("pool", []) if p["level"] in ("medium", "low")]
    if not regions:
        for p in rest:
            p["region"] = None
    rows = {}
    for x in a:
        k = (x.get("region") if regions else None, x["renewal"]["date"][:7], x["level"], x["crmView"]["forecast"]["value"])
        e = rows.setdefault(k, [0, 0])
        e[0] += 1
        e[1] += x["renewal"]["value"]
    c["pool"] = [{"region": k[0], "month": k[1], "level": k[2], "forecast": k[3], "count": v[0], "value": v[1]} for k, v in rows.items()] + rest
    c["shown"] = len(a)
    c["reviewed"] = sum(p["count"] for p in c["pool"])
    c["reviewedValue"] = sum(p["value"] for p in c["pool"])
    c["byLevel"] = {lv: sum(p["count"] for p in c["pool"] if p["level"] == lv) for lv in ("critical", "high", "medium", "low")}
    c["atStakeValue"] = sum(x["renewal"]["value"] for x in a)
    for r, e in c.get("byRegion", {}).items():
        e["shown"] = sum(1 for x in a if x.get("region") == r)
        e["reviewed"] = sum(p["count"] for p in c["pool"] if p["region"] == r)
        e["critical"] = sum(1 for x in a if x.get("region") == r and x["level"] == "critical")
        e["high"] = sum(1 for x in a if x.get("region") == r and x["level"] == "high")
    return d


def no_regions(d):
    d["meta"]["scope"]["regions"] = []
    d["coverage"]["byRegion"] = {}
    for a in d["accounts"]:
        a["region"] = None
    return recount(d)


def case_empty():
    d = load()
    d["accounts"] = []
    d["coverage"].update(topArea=None, notFlaggedByForecast={"count": 0, "value": 0})
    return recount(d)


def case_single():
    d = load()
    d["accounts"] = d["accounts"][:1]
    d["coverage"].update(topArea={"key": "business_health", "count": 1}, notFlaggedByForecast={"count": 0, "value": 0})
    return recount(d)


def case_long_text():
    d = load()
    a = d["accounts"][1]
    a["name"] = "Contoso International Holdings (North America) LLC – Enterprise Platform Services Division"
    a["owner"] = "Maximiliana Example-Montgomery-Placeholder"
    a["assessment"] = a["assessment"] * 3
    a["actions"][0]["title"] = ("CRO reaches the CTO and the incoming head of analytics to re-establish a senior "
                                "relationship and confirm who owns the platform budget before the Dec 3 notice date")
    a["actions"][0]["steps"] = a["actions"][0]["steps"] * 2
    ar = a["areas"][2]
    ar["finding"] = ("The main user appears to have left; see https://www.contoso.example.com/news/"
                     "leadership-changes-2026/announcements/analytics-team-update-october-final-version")
    ar["insights"][0]["explanation"] = ar["insights"][0]["explanation"] * 3
    ar["insights"] = ar["insights"] * 2
    return d


def case_backstory_only():
    d = load()
    d["meta"]["sources"] = {"renewalList": "backstory", "crmFields": "unavailable"}
    d["meta"]["crmForecast"] = {"field": None, "values": []}
    no_regions(d)
    for a in d["accounts"]:
        a["tier"] = None
        a["crmView"] = {"forecast": {"value": None},
                        "comparison": "The CRM fields weren't available for this run, so there is nothing to compare yet.",
                        "opportunities": [],
                        "sentiment": {"value": None, "date": None, "note": None},
                        "engagementScore": {"value": None, "asOf": None, "previous": None, "previousAsOf": None},
                        "source": "unavailable"}
        a["conflicts"] = []
    for p in d["coverage"]["pool"]:
        p["forecast"] = None
    d["coverage"]["notFlaggedByForecast"] = {"count": len(d["accounts"]), "value": d["coverage"]["atStakeValue"]}
    return d


def case_special_chars():
    d = load()
    a = d["accounts"][0]
    a["name"] = "O'Example & Søn Co <Partners> “Ltd”"
    a["owner"] = "Zoë D'Sample-Núñez"
    a["assessment"] = "Text with </script><script>window.__injected=1</script> and <b>tags</b> & ampersands must show as plain text."
    a["areas"][0]["insights"][0]["evidence"][1]["quote"] = {"speaker": "Test", "text": None}
    a["areas"][0]["insights"][0]["evidence"][1]["quote"]["text"] = "We'll \"revisit\" this </script> after the close — maybe."
    a["actions"][0]["title"] = "Call the CTO re: <merger> & next steps"
    return d


def case_sparse():
    d = load()
    for a in d["accounts"]:
        a["clientServicesOwner"] = None
        a["tier"] = None
        a["people"] = []
        a["recentActivity"] = {"mode": "mostRecent", "note": None, "items": []}
        a["relatedAccounts"] = []
        a["conflicts"] = []
        a["crmView"]["opportunities"] = []
        a["crmView"]["sentiment"] = {"value": None, "date": None, "note": None}
        a["crmView"]["engagementScore"] = {"value": None, "asOf": None, "previous": None, "previousAsOf": None}
        for x in a["actions"]:
            x["talkingPoints"] = []
    return no_regions(d)


def case_empty_region():
    d = load()
    d["meta"]["scope"]["regions"].append("Middle East")
    d["coverage"]["byRegion"]["Middle East"] = {"reviewed": 0, "reviewedValue": 0, "critical": 0, "high": 0, "shown": 0}
    return d


def bad_wrong_region():
    d = load()
    d["accounts"][0]["region"] = "Antarctica"
    return d


def bad_unknown_forecast():
    d = load()
    d["accounts"][0]["crmView"]["forecast"]["value"] = "Probably fine"
    return d


def bad_missing_comparison():
    d = load()
    d["accounts"][0]["crmView"]["comparison"] = ""
    return d


def case_many_in_region():
    d = load()
    base = d["accounts"][-1]
    for i in range(25):
        extra = copy.deepcopy(base)
        extra["id"], extra["name"] = f"001-EXTRA-{i:02d}", f"Extra Account {i + 1}"
        extra["renewal"]["value"] = 50000 - i * 1000
        d["accounts"].append(extra)
    for a in d["accounts"]:
        a["region"] = "North America"
    d["coverage"]["notFlaggedByForecast"]["count"] = sum(1 for a in d["accounts"] if a["crmView"]["forecast"]["value"] in (None, "Commit"))
    return recount(d)


def bad_pool_mismatch():
    d = load()
    p = next(p for p in d["coverage"]["pool"] if p["level"] == "critical")
    p["value"] += 50000
    return d


def bad_unlisted_high():
    d = load()
    d["accounts"].pop()
    d["coverage"]["shown"] -= 1
    return d


def bad_low_without_evidence():
    d = load()
    d["accounts"][0]["areas"][1]["insights"] = []
    return d


def bad_no_data_status():
    d = load()
    d["accounts"][1]["areas"][0]["status"] = "no_data"
    return d


def bad_level_mismatch():
    d = load()
    d["accounts"][3]["areas"][1]["status"] = "critical"
    return d


def bad_missing_insights():
    d = load()
    d["accounts"][0]["areas"][0]["insights"] = []
    return d


def bad_unknown_move():
    d = load()
    d["accounts"][0]["actions"][0]["move"] = "send_flowers"
    return d


def bad_out_of_order():
    d = load()
    a = d["accounts"]
    a[3], a[4] = a[4], a[3]
    return d


def bad_contact_email():
    d = load()
    d["accounts"][0]["people"][0]["title"] = "CTO, someone@example.com"
    return d


def bad_action_without_title():
    d = load()
    d["accounts"][0]["actions"][0]["title"] = ""
    return d



def bad_level_uncorroborated():
    d = load()
    a = next(x for x in d["accounts"] if x["name"].startswith("Tailspin"))
    next(ar for ar in a["areas"] if ar["key"] == "renewal_readiness")["status"] = "low"
    return d


def bad_client_stated_on_high():
    d = load()
    a = next(x for x in d["accounts"] if x["level"] == "high")
    next(ar for ar in a["areas"] if ar["status"] == "high")["clientStated"] = True
    return d


def case_calibration():
    d = load()
    for p in d["coverage"]["pool"]:
        if p["level"] == "medium":
            p["level"] = "low"
    return recount(d)



def case_leader_overload():
    d = load()
    for a in d["accounts"][:5]:
        a["actions"][0].update(who="CRO", by="2026-11-19")
    return d


def case_other_move():
    d = load()
    d["accounts"][0]["actions"][1]["move"] = "other"
    return d



def case_salesforce_complement():
    d = load()
    d["meta"]["sources"]["crmFields"] = "mixed"
    for a in d["accounts"][:3]:
        a["crmView"]["source"] = "salesforce"
    return d


# framework.md §5: (area statuses, clientStated on the critical area, expected level)
LEVEL_RULES = [
    (["critical", "low", "low", "low", "low", "low"], False, "high"),
    (["critical", "low", "low", "low", "low", "low"], True, "critical"),
    (["critical", "medium", "low", "low", "low", "low"], False, "critical"),
    (["high", "low", "low", "low", "low", "low"], False, "medium"),
    (["high", "medium", "low", "low", "low", "low"], False, "high"),
    (["high", "high", "low", "low", "low", "low"], False, "high"),
    (["medium", "medium", "medium", "low", "low", "low"], False, "medium"),
    (["low"] * 6, False, "low"),
]


def level_rules_ok():
    bad = []
    for st, stated, want in LEVEL_RULES:
        areas = [{"status": x, **({"clientStated": True} if stated and x == "critical" else {})} for x in st]
        got = build_brief.expected_level(areas)
        if got != want:
            bad.append(f"{'/'.join(st)}{' (client stated)' if stated else ''}: got {got}, expected {want}")
    return bad


CASES = [
    ("sample", load, "pass"),
    ("empty", case_empty, "pass"),
    ("single", case_single, "pass"),
    ("long-text", case_long_text, "warn"),
    ("backstory-only", case_backstory_only, "pass"),
    ("special-chars", case_special_chars, "pass"),
    ("sparse", case_sparse, "pass"),
    ("empty-region", case_empty_region, "pass"),
    ("many-in-region", case_many_in_region, "warn"),
    ("level-mismatch", bad_level_mismatch, "fail"),
    ("missing-insights", bad_missing_insights, "fail"),
    ("unknown-move", bad_unknown_move, "fail"),
    ("out-of-order", bad_out_of_order, "fail"),
    ("contact-email", bad_contact_email, "fail"),
    ("action-without-title", bad_action_without_title, "fail"),
    ("wrong-region", bad_wrong_region, "fail", "is not one of meta.scope.regions"),
    ("unknown-forecast", bad_unknown_forecast, "fail", "is not in meta.crmForecast.values"),
    ("missing-comparison", bad_missing_comparison, "fail", "comparison missing"),
    ("pool-mismatch", bad_pool_mismatch, "fail", "coverage.pool"),
    ("unlisted-high", bad_unlisted_high, "fail", "every Critical and High account must be listed"),
    ("low-without-insight", bad_low_without_evidence, "fail", "low area needs exactly one insight"),
    ("no-data-status", bad_no_data_status, "fail", "no_data' is no longer used"),
    ("level-uncorroborated", bad_level_uncorroborated, "fail", "doesn't follow from its areas"),
    ("client-stated-on-high", bad_client_stated_on_high, "fail", "clientStated"),
    ("calibration", case_calibration, "warn"),
    ("leader-overload", case_leader_overload, "warn"),
    ("other-move", case_other_move, "pass"),
    ("salesforce-complement", case_salesforce_complement, "pass"),
]


# ---- Pipeline: population.py and assemble.py, end to end ----------------------------------------------------------

AS_OF = "2026-11-17"
FMAP = {
    "opportunity": {"id": "id", "name": "name", "accountId": "acc", "accountName": "accName", "type": "type", "stage": "stage",
                    "renewalDate": "start", "closeDate": "close", "createdDate": "created", "amount": "amount",
                    "renewingProducts": "items", "isClosed": "closed", "owner": "owner", "forecast": "fc",
                    "atRiskReason": "arr", "nextStep": "next", "noticeDate": "notice", "annualizedAmount": "ann",
                    "managerNote": "mnote", "managerNoteDate": "mnoted"},
    "account": {"name": "accName", "tier": "tier", "region": "region", "status": "status", "type": "atype",
                "annualContractValue": "acv", "owner": "owner", "engagementScore": "score", "territory": "terr", "testAccount": "test"},
    "values": {"renewalType": ["Renewal"], "tiers": ["Enterprise", "Mid-market"], "clientStatus": ["Customer"],
               "excludeTypes": ["Partner", "Internal"],
               "forecastScale": [{"value": "Commit", "atRisk": False}, {"value": "Best Case", "atRisk": True}]},
}


def rec(i, acc, **kw):
    r = {"id": f"o{i}", "name": f"Opp {i}", "acc": acc, "accName": f"Account {acc}", "type": "Renewal", "stage": "Negotiation",
         "start": "2027-01-15", "close": "2027-01-10", "created": "2026-02-20", "amount": 50000, "items": ["Core Platform"], "closed": False,
         "owner": "Owner One", "fc": "Best Case", "tier": "Mid-market", "region": "North America", "status": "Customer", "atype": "Customer",
         "acv": 50000, "score": 7, "terr": "New York", "test": False}
    r.update(kw)
    return r


RECORDS = [
    rec(1, "A", notice="2026-11-20", mnote="Push for two years", mnoted="2026-11-10"), rec(13, "A", start="2027-02-01", created="2026-03-05", amount=10000, name="Opp 13 renewal add-on"),
    rec(2, "A", type="Upsell", items=[], created="2026-10-01", name="Upsell"),
    rec(3, "B", closed=True), rec(4, "C", start="2026-10-01", created="2025-11-10"), rec(5, "D", start="2026-06-01"),
    rec(6, "E", tier="SMB"), rec(7, "F", atype="Partner"), rec(8, "G", amount=None, acv=30000),
    rec(9, "H", amount=None, acv=None), rec(10, "I", type="New Business", created="2026-02-20"),
    rec(11, "J", start="2027-04-01"), rec(12, "K", status="Former customer"),
    rec(14, "L", test=True), rec(15, "M", amount=None, ann=40000, acv=None, terr="UK", region=None),
]


def run(script, *args):
    r = subprocess.run([sys.executable, os.path.join(HERE, script), *args], capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


def write(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f)


def pop_checks(work):
    out, bad = [], []
    rp, fp, pp = (os.path.join(work, n) for n in ("records.json", "fmap.json", "pop.json"))
    write(rp, RECORDS)
    write(fp, FMAP)
    code, log = run("population.py", rp, fp, "--as-of", AS_OF, "--out", pp)
    p = json.load(open(pp)) if code == 0 else {}
    acc = {a["id"]: a for a in p.get("accounts", [])}
    rep = p.get("report", {})
    want = {"accounts A, C, G, M": set(acc) == {"A", "C", "G", "M"},
            "A uses the notice date field": acc.get("A", {}).get("renewal", {}).get("noticeDate") == "2026-11-20",
            "A carries the manager note": (acc.get("A", {}).get("crm", {}).get("managerNote") or {}).get("text") == "Push for two years",
            "M falls back to annualized amount": acc.get("M", {}).get("renewal", {}).get("value") == 40000,
            "A sums its two renewals, not the upsell": acc.get("A", {}).get("renewal", {}).get("value") == 60000,
            "C is overdue": acc.get("C", {}).get("renewal", {}).get("overdue") is True,
            "G falls back to the account's annual contract value": acc.get("G", {}).get("renewal", {}).get("value") == 30000,
            "one type disagreement (I)": len(rep.get("typeDisagreements", [])) == 1,
            "one account with several renewals (A)": len(rep.get("severalRenewals", [])) == 1,
            "drops: closed, past, tier, excluded type, no value, after window, not a customer":
                all(rep.get("dropped", {}).get(k) == 1 for k in ("closed", "renewal date more than 90 days past", "tier out of scope", "test account",
                    "excluded account type", "no amount or annual contract value", "renews after the window", "not a current customer"))}
    bad += [k for k, v in want.items() if not v]
    out.append(("population", not bad, "; ".join(bad) or f"{len(acc)} accounts, drops and fallbacks as expected"))

    # fallbacks: no type field, no tier field
    fm2 = json.loads(json.dumps(FMAP))
    fm2["opportunity"]["type"] = None
    fm2["account"]["tier"] = None
    write(fp, fm2)
    code, log = run("population.py", rp, fp, "--as-of", AS_OF, "--out", pp)
    p2 = json.load(open(pp)) if code == 0 else {}
    ids = {a["id"] for a in p2.get("accounts", [])}
    ok = code == 0 and "A" in ids and "E" in ids and len(p2["report"]["fallbacks"]) >= 2 and "I" in ids
    out.append(("population-fallbacks", ok, f"exit {code}; accounts {sorted(ids)}"))

    # region worked out from territory when Region isn't mapped
    fm4 = json.loads(json.dumps(FMAP))
    fm4["account"]["region"] = None
    fm4["values"]["territoryRegion"] = {"New York": "North America"}
    write(fp, fm4)
    code, _ = run("population.py", rp, fp, "--as-of", AS_OF, "--out", pp)
    p4 = json.load(open(pp)) if code == 0 else {}
    a4 = {a["id"]: a for a in p4.get("accounts", [])}
    ok = code == 0 and a4.get("A", {}).get("region") == "North America" and a4.get("M", {}).get("region") == "No region" \
        and p4["scope"]["regions"] == ["North America", "No region"] and p4["report"].get("territoriesWithoutRegion") == ["UK"]
    out.append(("region-from-territory", ok, f"exit {code}; regions {p4.get('scope', {}).get('regions')}; unmapped {p4.get('report', {}).get('territoriesWithoutRegion')}"))

    # nothing identifies a renewal: exit 3
    fm3 = json.loads(json.dumps(fm2))
    for k in ("createdDate", "renewingProducts", "name"):
        fm3["opportunity"][k] = None
    write(fp, fm3)
    code, _ = run("population.py", rp, fp, "--as-of", AS_OF, "--out", pp)
    out.append(("population-no-signal", code == 3, f"exit {code}"))

    # Backstory's record tools return display dates ("Nov 20, 2026"): same result as ISO dates
    def to_display(v):
        if isinstance(v, str) and len(v) >= 10 and v[4] == "-" and v[7] == "-":
            d = datetime.date.fromisoformat(v[:10])
            return d.strftime("%b ") + str(d.day).zfill(2) + d.strftime(", %Y")
        return v

    def walk(o):
        if isinstance(o, dict):
            return {k: walk(x) for k, x in o.items()}
        if isinstance(o, list):
            return [walk(x) for x in o]
        return to_display(o)

    write(fp, FMAP)
    write(rp, walk(RECORDS))
    code, _ = run("population.py", rp, fp, "--as-of", AS_OF, "--out", pp)
    p5 = json.load(open(pp)) if os.path.exists(pp) else {}
    ids5 = {a["id"] for a in p5.get("accounts", [])}
    ok = code == 0 and ids5 == set(acc) and "no renewal date" not in p5.get("report", {}).get("dropped", {})
    out.append(("population-display-dates", ok, f"exit {code}; accounts {sorted(ids5)}"))
    write(rp, RECORDS)

    # records fetched but none kept: exit 3, never an empty brief
    write(rp, [{**r, **{k: None for k in ("start", "close")}} for r in RECORDS])
    code, _ = run("population.py", rp, fp, "--as-of", AS_OF, "--out", pp)
    out.append(("population-none-kept", code == 3, f"exit {code}"))
    write(rp, RECORDS)

    # standard fields only: no IsClosed (the stage decides), no renewal date field (the close date), and no tier, region,
    # status, test flag or exclusions: the optional fields are skipped and nothing counts as a fallback
    fm6 = {"opportunity": {k: FMAP["opportunity"][k] for k in ("id", "name", "accountId", "accountName", "type", "stage",
                                                              "closeDate", "createdDate", "amount", "owner")},
           "account": {"name": "accName"}, "values": {"renewalType": ["Renewal"]}}
    write(fp, fm6)
    write(rp, [{**r, "stage": "Closed Won"} if r["id"] == "o3" else r for r in RECORDS])
    code, _ = run("population.py", rp, fp, "--as-of", AS_OF, "--out", pp)
    p6 = json.load(open(pp)) if code == 0 else {}
    a6 = {a["id"]: a for a in p6.get("accounts", [])}
    rep6 = p6.get("report", {})
    ok = code == 0 and set(a6) == {"A", "C", "D", "E", "F", "J", "K", "L"} and rep6.get("dropped", {}).get("closed") == 1 \
        and rep6.get("fallbacks") == [] and p6["scope"]["regions"] == [] and a6["C"]["opportunities"][0]["dateSource"] == "close"
    out.append(("population-standard-only", ok, f"exit {code}; accounts {sorted(a6)}; fallbacks {rep6.get('fallbacks')}"))
    write(rp, RECORDS)

    # count check against last week
    write(fp, FMAP)
    prev = os.path.join(work, "prev.json")
    write(prev, {"coverage": {"reviewed": 10}})
    code, _ = run("population.py", rp, fp, "--as-of", AS_OF, "--out", pp, "--previous", prev)
    out.append(("population-count-check", code == 4, f"exit {code} (4 accounts vs 10 last week)"))
    return out


def sample_population(d, extra):
    """population.json and account files rebuilt from the sample: its listed accounts plus `extra` Medium and Low ones."""
    m = d["meta"]
    accts, files = [], {}
    for a in d["accounts"]:
        r = dict(a["renewal"])
        r.update(overdue=False, inReadiness=True)
        b = a["crmView"]
        accts.append({"id": a["id"], "name": a["name"], "region": a["region"], "territory": a.get("territory"), "tier": a["tier"], "owner": a["owner"],
                      "clientServicesOwner": a["clientServicesOwner"], "renewal": r, "opportunities": b["opportunities"],
                      "crm": {"forecast": b["forecast"]["value"], "sentiment": b["sentiment"], "engagementScore": b["engagementScore"],
                              "managerNote": b.get("managerNote")}})
        f = {k: a[k] for k in ("id", "areas", "primaryDriver", "secondaryDrivers", "assessment", "actions", "conflicts",
                               "recentActivity", "people", "relatedAccounts")}
        f.update(comparison=b["comparison"], activity={"captured": 6, "outreachSeen": True, "lastTwoWay": "2026-11-02"}, captureGap=None)
        files[a["id"]] = f
    for i, (lvl, captured, score, gap) in enumerate(extra):
        aid = f"X{i:03d}"
        st = ["low"] * 6
        if lvl == "medium":
            st[1] = "medium"
        accts.append({"id": aid, "name": f"Extra {i}", "region": m["scope"]["regions"][i % 3], "tier": "Mid-market", "owner": f"Owner {i % 3}",
                      "clientServicesOwner": None, "opportunities": [],
                      "renewal": {"date": "2027-01-04", "noticeDate": "2026-11-05", "value": 30000, "overdue": False, "inReadiness": True},
                      "crm": {"forecast": "Commit", "sentiment": {"value": None, "date": None, "note": None},
                              "engagementScore": {"value": score, "asOf": "2026-10", "previous": None, "previousAsOf": None}}})
        files[aid] = {"id": aid, "areas": [{"key": k, "status": s, "finding": "Screened."} for k, s in zip(build_brief.AREAS, st)],
                      "activity": {"captured": captured, "outreachSeen": captured > 0, "lastTwoWay": None}, "captureGap": gap}
    pop = {"asOf": m["asOf"], "scope": dict(m["scope"], overdueDays=90), "crmForecast": m["crmForecast"], "sources": m["sources"],
           "accounts": accts, "report": {}}
    return pop, files


def assemble_case(work, name, extra, edit=None, *flags):
    d = load()
    pop, files = sample_population(d, extra)
    if edit:
        edit(pop, files)
    case = os.path.join(work, name)
    os.makedirs(os.path.join(case, "accounts"), exist_ok=True)
    write(os.path.join(case, "pop.json"), pop)
    for k, v in files.items():
        write(os.path.join(case, "accounts", k + ".json"), v)
    dp = os.path.join(case, "data.json")
    code, log = run("assemble.py", os.path.join(case, "pop.json"), os.path.join(case, "accounts"), "--out", dp, *flags)
    return code, log, dp, d


def asm_checks(work, out_dir):
    out = []
    bell = [("medium", 4, 5, None)] * 55 + [("low", 4, 7, None)] * 32
    code, log, dp, d = assemble_case(work, "asm", bell)
    ok, detail = code == 0, f"exit {code}"
    if ok:
        got = json.load(open(dp))
        errs, _ = build_brief.build(dp, os.path.join(out_dir or work, "pipeline.html"), quiet=True)
        same = [a["id"] for a in got["accounts"]] == [a["id"] for a in d["accounts"]] and \
            [a["level"] for a in got["accounts"]] == [a["level"] for a in d["accounts"]]
        ok = not errs and same and got["coverage"]["byLevel"] == {"critical": 3, "high": 6, "medium": 55, "low": 32}
        detail = errs[0] if errs else ("levels, order and coverage match the sample" if ok else "levels, order or coverage differ from the sample")
    out.append(("assemble-sample", ok, detail))

    code, log, _, _ = assemble_case(work, "asm-cal", [("low", 4, 7, None)] * 87)
    code2, _, _, _ = assemble_case(work, "asm-cal2", [("low", 4, 7, None)] * 87, None, "--rechecked", "boundary accounts re-checked")
    out.append(("assemble-calibration", code == 2 and "Boundary accounts" in log and code2 == 0, f"exit {code}, then {code2} with --rechecked"))

    def quiet_healthy(pop, files):  # no contact captured, owner connected, score 7, before the readiness window -> momentum must be low
        pop["accounts"][-1]["renewal"]["inReadiness"] = False
        files[pop["accounts"][-1]["id"]]["areas"][3]["status"] = "medium"
    code, log, _, _ = assemble_case(work, "asm-quiet", bell[:-1] + [("low", 0, 7, None)], quiet_healthy)
    out.append(("no-contact-healthy", code == 1 and "must be low" in log, f"exit {code}"))

    def gap_high(pop, files):  # capture gap -> momentum Medium at most
        files[pop["accounts"][-1]["id"]]["areas"][3]["status"] = "high"
    code, log, _, _ = assemble_case(work, "asm-gap", bell[:-1] + [("low", 0, 7, "personal_domain")], gap_high)
    out.append(("no-contact-gap", code == 1 and "capture gap" in log, f"exit {code}"))

    def promoted(pop, files):  # an extra account whose areas give High, without its write-up
        files[pop["accounts"][-1]["id"]]["areas"][2]["status"] = "high"
        files[pop["accounts"][-1]["id"]]["areas"][3]["status"] = "medium"
    code, log, _, _ = assemble_case(work, "asm-writeup", bell, promoted)
    out.append(("high-without-write-up", code == 1 and "full write-up" in log, f"exit {code}"))
    return out


def pipeline_checks(out_dir):
    work = tempfile.mkdtemp()
    try:
        return pop_checks(work) + asm_checks(work, out_dir)
    finally:
        shutil.rmtree(work)


def js_ok(html_path):
    node = shutil.which("node")
    if not node:
        return None
    with open(html_path, encoding="utf-8") as f:
        scripts = re.findall(r"<script>(.*?)</script>", f.read(), re.S)
    with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False, encoding="utf-8") as t:
        t.write("\n".join(scripts))
    r = subprocess.run([node, "--check", t.name], capture_output=True, text=True)
    os.unlink(t.name)
    return r.returncode == 0


def main():
    out = None
    if "--out" in sys.argv:
        out = sys.argv[sys.argv.index("--out") + 1]
        os.makedirs(out, exist_ok=True)
    work = tempfile.mkdtemp()
    failures = 0
    rule_errs = level_rules_ok()
    failures += bool(rule_errs)
    print(f"{'FAIL' if rule_errs else 'ok  '} {'level-rules':22} {len(LEVEL_RULES)} corroboration cases  {'; '.join(rule_errs)[:90]}")
    for name, make, expect, *want in CASES:
        data_path = os.path.join(work, name + ".json")
        with open(data_path, "w", encoding="utf-8") as f:
            json.dump(make(), f, ensure_ascii=False)
        html_path = os.path.join(out or work, name + ".html")
        errs, warns = build_brief.build(data_path, html_path)
        got = "fail" if errs else ("warn" if warns else "pass")
        ok = got == expect or (expect == "pass" and got == "warn")
        if ok and want and not any(want[0] in e for e in errs):
            ok = False
        if want and errs:
            errs = [e for e in errs if want[0] in e] or errs
        js = js_ok(html_path) if not errs else None
        if js is False:
            ok = False
        failures += not ok
        detail = errs[0] if errs else (f"{len(warns)} warnings" if warns else "")
        print(f"{'ok  ' if ok else 'FAIL'} {name:22} expected {expect:4}  got {got:4}  {'' if js is None else ('js ok' if js else 'JS SYNTAX ERROR')}  {detail[:90]}")
    shutil.rmtree(work)
    pipe = pipeline_checks(out)
    for name, ok, detail in pipe:
        failures += not ok
        print(f"{'ok  ' if ok else 'FAIL'} {name:22} {detail[:110]}")
    total = len(CASES) + 1 + len(pipe)
    print(f"\n{total - failures}/{total} cases behaved as expected" + (f"; pages in {out}" if out else ""))
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    main()
