# Evaluation rubric

A shared definition of a good brief, for judging runs before relying on them and whenever the instructions change. Run the plugin several times on the same data (aim for 5+). A change is an improvement only if it raises the scores without making runs less consistent.

Score each criterion **2** (meets), **1** (partly), **0** (misses). Criteria marked **gate** must score 2 for the brief to ship.

## A. Correct population and ranking
1. **gate** Every renewal in scope was analysed, up to `population.maxReviewed` (the largest): the in-scope count matches an independent count of renewals in the window, regions and tiers at or above `population.minRenewalValue`, and the renewals over the cap are reported with their count and value.
2. **gate** No account appears that is out of scope (wrong region, tier, type, closed or outside the window).
3. Accounts are ranked by level, then value, then notice date; every Critical and High account is listed, covering every region found; the monthly chart's pool matches the coverage totals.
3b. The team's forecast values and regions (when configured) were read from the instance, not assumed; each comparison line matches the account's forecast and evidence.

## B. Sound risk calls
4. **gate** Every area rated Critical, High or Medium cites dated evidence that actually supports it (spot-check against Backstory activity).
5. Area ratings match the framework (§3): a reviewer reading the evidence would rate each area the same, and the account level follows from the area ratings by the corroboration rules (framework.md §5).
6. The primary driver is the area most responsible for the level; the tracked churn driver names (`settings.json → churnDrivers`) are used exactly where they apply.
7. The CRM's data is weighed correctly: the engagement score raises risk only past the thresholds; sentiment never creates a risk alone, and a current red rating only moves Value and satisfaction from Medium to High; the at-risk reason and the forecast never set the level.
8. Conflicts between the CRM fields and the evidence are surfaced where they exist.
9. Every area is rated, with evidence, including Low areas: one insight with a real healthy event as evidence, or, for a reassuring absence, an explanation naming what was looked at and over what window (no evidence box for the check itself). Missing data leans the way the area's definition says (framework.md §1); capture gaps cap the area at Medium.

## C. Useful actions
10. Each Critical and High account has one primary action that deals with its primary driver, plus at most two supporting actions. Actions come from the evidence and build on what's already planned (no duplicate of a meeting already booked); the moves in settings are used where they fit and `other` where they don't; nothing commits your company to a price or term; no leader has more than `brief.maxLeaderActionsPerWeek` actions due in one week.
11. Who and by-when are concrete: real owners from the account record in Backstory, roles for leaders, dates before the right notice date (or this week if passed), never after the renewal.
12. The "why" ties the move to the account's evidence, not generic advice.

## D. Writing
13. The assessment explains the level in 2–3 plain sentences a CRO can read in 10 seconds.
14. Findings and evidence are compact and specific; observed facts are kept apart from interpretation.
15. **gate** No invented people, dates, amounts or quotes; no email addresses or phone numbers; no forecasting language.

## E. Consistency across runs
16. The same data produces the same levels for at least 9 of 10 accounts across runs.
17. The same data produces the same top 10 (order may vary only within ties).

## Automated checks

Before judging content, run `python3 scripts/check_fixtures.py`. It confirms the template still handles empty, long, sparse, special-character and Backstory-only data, and that invalid data is rejected.

## Test scenarios

Keep a fixture for each, and check the expected behaviour.

| Scenario | Expected |
|---|---|
| Main user's email bounces; no other contact | Relationship depth rated Critical, so the account is Critical; primary ★ Key user or champion gone; executive outreach |
| No reply in 60 days and a single contact, but no decisive signal; notice in 10 days | High, not Critical: timing doesn't set the level; ranked early within High because of the notice date |
| Engagement score drops from 8 to 3; activity otherwise healthy; sentiment green | At least High on ★ Low value or dissatisfaction; conflict line on sentiment |
| Sentiment red but strong two-way activity and score 7 | Not raised above Medium on sentiment alone |
| Client says it's "reviewing all software vendors" after a merger | ★ Customer M&A or restructuring, Risk |
| Private client, no news, web search empty | Client business health Low, with the news and web check as its evidence and the thin coverage stated |
| Client on a personal email domain, no captured replies in 60 days | Engagement momentum Medium at most, with the capture gap named, not High on silence |
| Renewal 100 days away, no renewal conversation yet | Renewal readiness High (inside the readiness window, `readinessStartDays` before the renewal, with no conversation with the decision-maker) |
| Engagement score 7, steady, no complaints | Value and satisfaction Low, with the score reading as its evidence |
| Tier field configured but not in Backstory, no Salesforce connector | Run continues without the tier filter; `population.minRenewalValue` (when set) and `population.maxReviewed` still apply; the report names the field and the fallback first |
| Opportunity type not in Backstory or Salesforce | Renewals identified where at least two signals agree (created `population.autoCreatedGapDays` before the renewal date, renewing products, "Renewal" in the name); the report says so first |
| An account has a renewal and an upsell opportunity open | Only the renewal counts; the upsell's value isn't added |
| Typed as new business but created on the renewal schedule with renewing products | Type kept; the opportunity is listed in the report as a disagreement |
| Tier field configured but not in Backstory, Salesforce connector available | Tier read from Salesforce; the run continues; the report says so first |
| Forecast field not in Backstory, no Salesforce connector | Brief builds without the team's forecast (no column values, no pills); the report names the missing field first |
| Only the standard fields configured (no tier, region, status, sentiment, score or notice date fields) | Run completes on Type, CloseDate, Amount, StageName, owner and account name plus Backstory activity; one list with no region filter; notice dates from `clientNoticeDays`; no fallback warnings for fields that were never configured |
| Salesforce connector available, every field in Backstory | Backstory's data is used; Salesforce only cross-checks the renewal count and adds executive notes and tasks |
| Salesforce counts 5 more renewals than Backstory's list | The 5 are found by Salesforce id and added through Backstory; the report names the difference |
| No Salesforce connector | Run completes on Backstory alone; never asks the user to connect one |
| Scheduled run, renewal count 40% below last week's | Nothing published; both counts reported |
| Interactive run, 2,500 renewals fetched, 112 at or above the value floor, cap 40 | No question asked: one line relays the counts, the floor and "Reviewed the 40 largest of 112 in scope; 72 (total …) not reviewed this run"; the run continues |
| `preview_records` says to stop and wait for the user to confirm the count | The run doesn't wait: it fetches, relays the count and how Backstory read the query, and continues |
| In-scope count outside `population.expectedCount` (exit 6) | Interactive: stops and asks with the count and the range. Scheduled: nothing published |
| A renewal with no amount or annual value | Kept, listed as value unknown, never dropped by the floor |
| The population looks large | Never asks for a value threshold, tier or region: the settings and the cap decide |
| Account owner already has a renewal meeting booked with the CTO on Thursday | The primary action prepares or strengthens that meeting; no separate leader call |
| Client now uses only one product line | An action outside the six moves (`other`), such as reviewing the product mix with the client, with no price promised |
| CRO would get executive outreach on six accounts due the same week | CRO keeps the four that matter most; the rest go to sales leaders |
| One area High, the other five Low | Account Medium, not listed |
| No activity captured, owner connected, engagement score 7, renewal in 5 months | Engagement momentum Low ("quiet but using the product"); never Critical |
| No activity captured, client on a personal email domain | Engagement momentum and Relationship depth Medium at most, gap named |
| Client asks for a discount in the renewal negotiation | Commercial Medium (ordinary negotiation), not High |
| "We need 10% off or we'll drop the analytics add-on" | Commercial High: pushback tied to a cut |
| A filing (8-K) or SalesAI answer is the only source of a client statement | Not `clientStated`; no quote marks; the build rejects `clientStated` without an email, meeting or call event |
| What a client said | Attributed paraphrase in the narrative ("Backstory's summary of the Oct 27 call: …"), speaker checked against the client's contacts; no `quote` |
| Renewal still open 3 weeks past its date | In the brief, marked overdue |
| 40 actions would fall on the same Thursday | Spread by rank: Critical primary actions within two business days, High by Thursday, supporting actions after |
| Record search turns the date range into "this year" | Page re-run with a simpler query; population.py does the filtering; noted in the report |
| Engagement momentum High and Renewal readiness Medium | Account High |
| Merger announced in the press (Business health Critical), everything else Low | Account High, with the assessment saying the rest of the account looks healthy |
| Client emails that it will drop two products, everything else Low | Account Critical on the client's own words (`clientStated`) |
| Critical and High are 40% of the book, or Medium isn't the largest group | Calibration warning; boundary accounts re-checked against the evidence; ratings changed only where the evidence supports it; final distribution reported |
| No Critical or High accounts | Empty state with the reviewed count |
| Scheduled weekly run, Backstory MCP unreachable | Nothing published; last week's brief stays; a short note on what blocked the run |
| Scheduled weekly run with no brief link | Stops without creating a new artifact; says the schedule needs the link |
| First run on the configured scope | Ends by offering the weekly Monday 8 am refresh (`settings.json → schedule`); creates nothing without a yes |
