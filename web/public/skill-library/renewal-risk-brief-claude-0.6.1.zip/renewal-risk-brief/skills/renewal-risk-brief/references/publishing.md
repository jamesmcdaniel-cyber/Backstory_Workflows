# Building and publishing

The page is never designed per run. It's `assets/brief-template.html` filled with validated data. Every run updates the same brief, so leaders keep one link.

## Build

```
python3 <skill>/scripts/build_brief.py data.json brief.html
```

The script:
- checks the template is the approved one (its fingerprint in `assets/brief-template.sha256`). If it reports the template has changed, restore the shipped file. **Never run `--accept-template` during a brief run**: it exists only for maintainers who changed the template on purpose and re-ran the tests;
- validates `data.json` against data-schema.md. If it prints problems, fix the data and rebuild;
- prints **warnings** when text runs long (assessments, findings, explanations, titles, steps). The page still builds, but tighten the flagged text and rebuild: the brief should stay skimmable;
- stamps the plugin version into the page footer.

Never hand-edit `brief.html` or the template.

**No-script path** (only if the environment can't run Python, and only as a last resort: ask for code execution to be turned on first). Then you must do the scripts' work by hand, following their rules exactly: the population filters and fallbacks (data-collection.md §0–§1a), the value floor and the cap (`population.minRenewalValue`, `population.maxReviewed`), the level rules and the "No captured contact" table (framework.md §3, §5), ranking and coverage (data-schema.md). Then read the template, replace the single placeholder `/*__DATA__*/null` with the JSON (escape every `</` as `<\/`), check the data against the "Rules the build script enforces" yourself, and tell the user the brief was built without the scripts' checks.

## Last week's brief

Before building the population, read the brief at the target link (or the file at `output.filePath`) when there is one, and save it in the run folder as `previous.html`. `population.py --previous previous.html` compares the in-scope renewal count with it, and your report back compares levels with it: accounts new to Critical or High, accounts that dropped off, level changes. The brief embeds its own data, so no separate history file is needed.

## Publish to the same place

The target comes from the request first (a scheduled run always names the brief's link), then from `output` in settings:

0. **The request gives the brief's link**: update that artifact in place.
1. **`output.artifactUrl` is set** and the environment can update an artifact by its link: publish `brief.html` to that link, updating it in place.
2. **`output.filePath` is set** (for example a file in a shared folder synced to this machine): overwrite that file with `brief.html`. The shared link to the file stays the same.
3. **Neither is set** (first run): publish `brief.html` as a new artifact (or save it where the user asks). Then give the user the link, and tell them to include it when they ask for the next run ("refresh the renewal risk brief at <link>"). The weekly schedule (SKILL.md, step 8) carries the link in its own prompt. Don't ask anyone to edit `settings.json`: it sits inside the installed plugin, and an update replaces it.

**Scheduled runs never create a new artifact.** With no target, they stop and say so. If the run can't finish, they publish nothing, so last week's brief stays in place.

Within a single conversation, republishing the same file path also updates the same artifact.

The page is self-contained: data, styles and scripts are inline, and it makes no data calls when viewed. Its only external request is for web fonts, with system fonts as the fallback. It can be shared as an artifact link or as a file.

The previous week's brief is replaced. If the environment keeps version history, earlier briefs remain there.

## After publishing, tell the user
- The link or file location, and the run date.
- Accounts analysed and shown, per region; Critical and High counts and value at stake; how many of them the team's forecast doesn't flag (`coverage.notFlaggedByForecast`; all from `coverage`).
- The field values read from the instance: regions, tiers, excluded account types, closed stages, and the forecast scale with the values treated as at risk (only for the fields configured in `settings.json → fields`).
- First, any configured CRM field that Backstory didn't return, and where each came from instead (Salesforce, when connected) or what the brief did without it.
- Whether a Salesforce connector was used, what for, and any difference between its renewal count and Backstory's.
- The renewals in scope, those below the value floor and those over the cap (not reviewed this run, with their count and total value), and any with value unknown.
- Anything else that limited the run: record-search filters that were substituted, fallbacks, accounts excluded, tool errors, accounts that couldn't be assessed.

This is the only place for run notes: the page itself never shows banners, warnings or notes about how the run went.

## Changing the experience
Only when asked. Edit `assets/brief-template.html` and `ux-spec.md` together, then:
1. Run `python3 scripts/check_fixtures.py --out <dir>`: every case must behave as expected.
2. Open the built pages in `<dir>` at desktop and phone widths and click through every tab.
3. Run `python3 scripts/build_brief.py --accept-template` to record the new template as approved.
4. Bump the version in `.claude-plugin/plugin.json` and the skill's metadata.
