#!/usr/bin/env python3
"""Build the renewal risk brief from a data JSON file and the bundled template.

Usage: build_brief.py <data.json> <out.html>
       build_brief.py --accept-template   (maintainers only: record an intentionally changed template)

The template (assets/brief-template.html) is the source of truth for layout, behaviour and visual design.
This script:
  - checks the template is the approved one (its SHA-256 matches assets/brief-template.sha256);
  - validates the data's structure against references/data-schema.md, and exits 1 with a list of problems;
  - prints non-blocking warnings when text runs long (the brief should stay skimmable);
  - works out, for each account, whether the team's forecast flags it (from the forecast scale the run recorded);
  - adds the move labels, the tracked churn drivers, the display limits and the plugin version, and embeds the data in the template.
"""
import datetime
import hashlib
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.join(HERE, "..")
TEMPLATE = os.path.join(SKILL, "assets", "brief-template.html")
SETTINGS = os.path.join(SKILL, "settings.json")
PLACEHOLDER = "/*__DATA__*/null"
TEMPLATE_HASH = os.path.join(SKILL, "assets", "brief-template.sha256")
PLUGIN_JSON = os.path.join(SKILL, "..", "..", ".claude-plugin", "plugin.json")

# Soft limits: longer text still builds, with a warning, so Claude can tighten it.
LIMITS = {"driverSummary": 70, "comparison": 300, "assessment": 450, "finding": 170, "headline": 140, "explanation": 750, "narrative": 420,
          "title": 95, "objective": 260, "why": 300, "step": 220, "talkingPoint": 240}
MAX_INSIGHTS, MAX_EVIDENCE, MAX_STEPS = 3, 4, 6

AREAS = ["business_health", "value_satisfaction", "relationship_depth",
         "engagement_momentum", "commercial", "renewal_readiness"]
STATUSES = {"critical", "high", "medium", "low"}
SHOWN_LEVELS = {"critical", "high"}
LEVEL_RANK = {"critical": 0, "high": 1}
SEVERITY_RANK = {"critical": 0, "high": 1, "medium": 2, "low": 3}
EV_SOURCES = {"activity", "news", "salesforce", "salesai", "web"}
EV_KINDS = {"email", "meeting", "call", "news", "score", "field", "web", "other"}
PEOPLE_STATUS = {"engaged", "quiet", "one_way", "left"}
SENTIMENT = {None, "green", "amber", "red"}
RECENT_MODES = {"last7", "mostRecent"}
LIST_SOURCES = {"backstory"}
FIELD_SOURCES = {"backstory_fields", "salesforce", "mixed", "unavailable"}
DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def is_date(v):
    return isinstance(v, str) and bool(DATE.match(v))


def forecast_scale(meta):
    """{value: atRisk} from meta.crmForecast.values, as recorded by the run from the instance."""
    return {v.get("value"): v.get("atRisk") for v in ((meta.get("crmForecast") or {}).get("values") or [])}


def forecast_flagged(account, scale):
    """True when the team's forecast flags the account at risk, False when it doesn't, None when no forecast is set."""
    v = ((account.get("crmView") or {}).get("forecast") or {}).get("value")
    return None if v is None else bool(scale.get(v))


POOL_LEVELS = ("critical", "high", "medium", "low")
MONTH = re.compile(r"^\d{4}-\d{2}$")


def expected_level(areas):
    """framework.md §5: one signal alone never sets the level; a second flagged area must back it up."""
    st = [a.get("status") for a in areas]
    crit, high, med = st.count("critical"), st.count("high"), st.count("medium")
    flagged = crit + high + med
    stated = any(a.get("status") == "critical" and a.get("clientStated") is True for a in areas)
    if crit and (stated or flagged >= 2):
        return "critical"
    if crit or high >= 2 or (high and med):
        return "high"
    if high or med:
        return "medium"
    return "low"


def calibration(c, settings):
    """Warn when the book's distribution is far from the expected bell curve (framework.md §5)."""
    cal = settings.get("calibration") or {}
    bl = c.get("byLevel") or {}
    total = sum(bl.get(k, 0) for k in ("critical", "high", "medium", "low"))
    if total < cal.get("minReviewed", 20):
        return []
    out = []
    share = lambda k: bl.get(k, 0) / total
    lo, hi = cal.get("flaggedShare", [0.08, 0.30])
    f = share("critical") + share("high")
    if not lo <= f <= hi:
        out.append(f"Critical and High are {f:.0%} of the {total} renewals reviewed, outside the expected {lo:.0%}-{hi:.0%}. Re-check the ratings at the boundary against the evidence")
    if share("critical") > cal.get("criticalShareMax", 0.10):
        out.append(f"Critical is {share('critical'):.0%} of renewals reviewed, above the expected {cal.get('criticalShareMax', 0.10):.0%}. Check each Critical rests on decisive evidence")
    if bl.get("critical", 0) > bl.get("high", 0):
        out.append("More Critical than High accounts. Check each Critical rests on decisive evidence")
    if cal.get("mediumLargest", True) and bl.get("medium", 0) < max(bl.get(k, 0) for k in ("critical", "high", "low")):
        out.append("Medium isn't the largest group. Expect most renewals to be Medium; check whether early signals were missed or over-rated")
    return out


def leader_load(accounts, settings):
    """actions.md: warn when one person or role has more actions due in one week than settings allow."""
    cap = settings.get("brief", {}).get("maxLeaderActionsPerWeek", 4)
    load = {}
    for a in accounts:
        for x in a.get("actions") or []:
            if not (x.get("who") and is_date(x.get("by"))):
                continue
            y, w, _ = datetime.date.fromisoformat(x["by"]).isocalendar()
            who = (x.get("role") or x["who"]).strip()
            key = (who.lower(), y, w)
            e = load.setdefault(key, [who, x["by"], 0])
            e[2] += 1
    return [f"{who} has {n} actions due the week of {by}; above {cap}, move the lower-priority ones to a sales leader or the account owner"
            for who, by, n in load.values() if n > cap]


def validate_pool(c, accts, regions, scale):
    """coverage.pool: the whole renewal pool, aggregated without account names, for the monthly chart."""
    errs = []
    pool = c.get("pool")
    if not isinstance(pool, list):
        return ["coverage.pool must be a list of {region, month, level, forecast, count, value} rows"]
    tot_n, tot_v, by_level, by_region, ch = 0, 0, {}, {}, {}
    for i, row in enumerate(pool):
        lab = f"coverage.pool[{i}]"
        if not isinstance(row, dict):
            errs.append(f"{lab} must be an object")
            continue
        if row.get("level") not in POOL_LEVELS:
            errs.append(f"{lab}: level {row.get('level')!r} must be one of {list(POOL_LEVELS)}")
        if not isinstance(row.get("month"), str) or not MONTH.match(row["month"]):
            errs.append(f"{lab}: month must be YYYY-MM (the renewal date's month)")
        if regions and row.get("region") not in regions:
            errs.append(f"{lab}: region {row.get('region')!r} is not one of meta.scope.regions")
        if not regions and row.get("region") is not None:
            errs.append(f"{lab}: region must be null when meta.scope.regions is empty")
        if row.get("forecast") is not None and row.get("forecast") not in scale:
            errs.append(f"{lab}: forecast {row.get('forecast')!r} is not in meta.crmForecast.values")
        n, v = row.get("count"), row.get("value")
        if not isinstance(n, int) or n < 1 or not isinstance(v, (int, float)) or v < 0:
            errs.append(f"{lab}: count must be a positive integer and value a non-negative number")
            continue
        tot_n += n
        tot_v += v
        by_level[row.get("level")] = by_level.get(row.get("level"), 0) + n
        rr = by_region.setdefault(row.get("region"), [0, 0])
        rr[0] += n
        rr[1] += v
        if row.get("level") in SHOWN_LEVELS:
            k = (row.get("region"), row.get("month"))
            e = ch.setdefault(k, [0, 0])
            e[0] += n
            e[1] += v
    if errs:
        return errs
    if tot_n != c.get("reviewed"):
        errs.append(f"coverage.pool counts add up to {tot_n}, but coverage.reviewed is {c.get('reviewed')}")
    rv = c.get("reviewedValue") or 0
    if abs(tot_v - rv) > max(1000, 0.01 * rv):
        errs.append(f"coverage.pool values add up to {tot_v:,.0f}, but coverage.reviewedValue is {rv:,.0f}")
    bl = c.get("byLevel") or {}
    for lv in POOL_LEVELS:
        if by_level.get(lv, 0) != (bl.get(lv) or 0):
            errs.append(f"coverage.pool has {by_level.get(lv, 0)} {lv} accounts, but coverage.byLevel.{lv} is {bl.get(lv) or 0}")
    for r, e in (c.get("byRegion") or {}).items():
        got = by_region.get(r, [0, 0])
        if isinstance(e, dict) and e.get("reviewed") is not None and got[0] != e["reviewed"]:
            errs.append(f"coverage.pool has {got[0]} accounts in {r}, but coverage.byRegion[{r!r}].reviewed is {e['reviewed']}")
    want = {}
    for a in accts:
        k = (a.get("region") if regions else None, ((a.get("renewal") or {}).get("date") or "")[:7])
        e = want.setdefault(k, [0, 0])
        e[0] += 1
        e[1] += (a.get("renewal") or {}).get("value") or 0
    for k in set(want) | set(ch):
        g, w_ = ch.get(k, [0, 0]), want.get(k, [0, 0])
        if g[0] != w_[0] or abs(g[1] - w_[1]) > 1:
            errs.append(f"coverage.pool Critical and High rows for {k[0] or 'all regions'}, {k[1]} ({g[0]} accounts, {g[1]:,.0f}) "
                        f"don't match the listed accounts ({w_[0]}, {w_[1]:,.0f})")
    return errs


def validate(d, settings):
    errs = []
    for k in ("meta", "coverage", "accounts"):
        if k not in d:
            errs.append(f"missing top-level key: {k}")
    if errs:
        return errs
    m, c, accts = d["meta"], d["coverage"], d["accounts"]
    move_keys = {mv["key"] for mv in settings.get("moves", [])}

    for k in ("company", "title", "asOf", "builtAt", "scope", "sources", "crmForecast"):
        if k not in m:
            errs.append(f"meta missing {k}")
    if "asOf" in m and not is_date(m["asOf"]):
        errs.append("meta.asOf must be YYYY-MM-DD")
    src = m.get("sources") or {}
    if src.get("renewalList") not in LIST_SOURCES:
        errs.append(f"meta.sources.renewalList must be one of {sorted(LIST_SOURCES)}")
    if src.get("crmFields") not in FIELD_SOURCES:
        errs.append(f"meta.sources.crmFields must be one of {sorted(FIELD_SOURCES)}")
    regions = (m.get("scope") or {}).get("regions")
    if not isinstance(regions, list):
        errs.append("meta.scope.regions must be a list of the region values found (empty when region couldn't be read)")
        regions = []
    fv = (m.get("crmForecast") or {}).get("values")
    if not isinstance(fv, list):
        errs.append("meta.crmForecast.values must be a list (empty when forecast confidence couldn't be read)")
        fv = []
    for v in fv:
        if not isinstance(v, dict) or not v.get("value") or not isinstance(v.get("atRisk"), bool):
            errs.append("meta.crmForecast.values entries need a value and atRisk (true/false)")
    scale = forecast_scale(m)

    for k in ("reviewed", "reviewedValue", "shown", "byLevel", "atStakeValue", "notFlaggedByForecast", "byRegion", "topArea", "pool"):
        if k not in c:
            errs.append(f"coverage missing {k}")
    if not isinstance(accts, list):
        return errs + ["accounts must be a list"]
    nob = c.get("notFlaggedByForecast") or {}
    if not isinstance(nob.get("count"), int) or not isinstance(nob.get("value"), (int, float)):
        errs.append("coverage.notFlaggedByForecast needs a count and a value")
    else:
        bl = c.get("byLevel") or {}
        need = (bl.get("critical") or 0) + (bl.get("high") or 0)
        shown_not = sum(1 for a in accts if forecast_flagged(a, scale) is not True)
        if nob["count"] > need:
            errs.append(f"coverage.notFlaggedByForecast.count ({nob['count']}) can't exceed the Critical and High count ({need})")
        if nob["count"] < shown_not:
            errs.append(f"coverage.notFlaggedByForecast.count ({nob['count']}) is lower than the {shown_not} shown accounts the team's forecast doesn't flag")
    br = c.get("byRegion")
    if not isinstance(br, dict):
        errs.append("coverage.byRegion must be an object keyed by region")
        br = {}
    for r in regions:
        e = br.get(r)
        if not isinstance(e, dict) or not isinstance(e.get("reviewed"), int) or not isinstance(e.get("shown"), int):
            errs.append(f"coverage.byRegion[{r!r}] needs reviewed and shown counts")
        elif e["shown"] != sum(1 for a in accts if a.get("region") == r):
            errs.append(f"coverage.byRegion[{r!r}].shown ({e['shown']}) must equal the shown accounts in that region")
    ta = c.get("topArea")
    if ta is not None and (ta.get("key") not in AREAS or not isinstance(ta.get("count"), int)):
        errs.append("coverage.topArea needs an area key and a count")
    if c.get("shown") != len(accts):
        errs.append(f"coverage.shown ({c.get('shown')}) must equal the number of accounts ({len(accts)})")
    blv = c.get("byLevel") or {}
    if len(accts) != (blv.get("critical") or 0) + (blv.get("high") or 0):
        errs.append(f"every Critical and High account must be listed: byLevel counts {(blv.get('critical') or 0) + (blv.get('high') or 0)}, accounts list {len(accts)}")
    errs += validate_pool(c, accts, regions, scale)

    seen, prev = set(), None
    for a in accts:
        n = a.get("name") or a.get("id") or "?"
        for k in ("id", "name", "owner", "level", "renewal", "primaryDriver", "assessment", "actions",
                  "areas", "conflicts", "recentActivity", "people", "relatedAccounts", "crmView"):
            if k not in a or a[k] in (None, "") and k not in ("conflicts", "relatedAccounts"):
                errs.append(f"{n}: missing {k}")
        if a.get("id") in seen:
            errs.append(f"{n}: duplicate id {a.get('id')}")
        seen.add(a.get("id"))
        lvl = a.get("level")
        if regions and a.get("region") not in regions:
            errs.append(f"{n}: region {a.get('region')!r} is not one of meta.scope.regions")
        if lvl not in SHOWN_LEVELS:
            errs.append(f"{n}: level {lvl!r} can't be shown (only critical or high)")

        r = a.get("renewal") or {}
        for k in ("date", "noticeDate"):
            if r.get(k) in (None, ""):
                errs.append(f"{n}: renewal.{k} missing")
        if "value" not in r or (r["value"] is not None and (isinstance(r["value"], bool) or not isinstance(r["value"], (int, float)))):
            errs.append(f"{n}: renewal.value must be a number, or null when no value field was available")
        if a.get("territory") is not None and not isinstance(a.get("territory"), str):
            errs.append(f"{n}: territory must be text or null")
        mn = (a.get("crmView") or {}).get("managerNote")
        if mn is not None and not (isinstance(mn, dict) and mn.get("text") and (mn.get("date") is None or is_date(mn.get("date")))):
            errs.append(f"{n}: crmView.managerNote needs text and a YYYY-MM-DD date (or null)")
        if "overdue" in r and not isinstance(r["overdue"], bool):
            errs.append(f"{n}: renewal.overdue must be true or false")
        for k in ("date", "noticeDate"):
            if r.get(k) and not is_date(r[k]):
                errs.append(f"{n}: renewal.{k} must be YYYY-MM-DD")

        # ranking: level, then value desc, then notice date asc
        key = (LEVEL_RANK.get(lvl, 9), -(r.get("value") or 0), r.get("noticeDate") or "9999")
        if prev is not None and key < prev:
            errs.append(f"{n}: out of order (rank by level, then value, then earlier notice date)")
        prev = key

        areas = a.get("areas") or []
        keys = [ar.get("key") for ar in areas]
        if keys != AREAS:
            errs.append(f"{n}: areas must be exactly {AREAS} in that order (got {keys})")
        status = {}
        for ar in areas:
            k = ar.get("key")
            status[k] = ar.get("status")
            if ar.get("status") == "no_data":
                errs.append(f"{n}/{k}: status 'no_data' is no longer used; rate the area and say which way missing data leans (framework.md §1)")
            elif ar.get("status") not in STATUSES:
                errs.append(f"{n}/{k}: status {ar.get('status')!r} invalid")
            if not ar.get("finding"):
                errs.append(f"{n}/{k}: finding missing")
            dr = ar.get("driver")
            if dr is not None and (not dr.get("label") or not isinstance(dr.get("tracked"), bool)):
                errs.append(f"{n}/{k}: driver needs label and tracked (true/false)")
            flagged = ar.get("status") in ("critical", "high", "medium")
            ins = ar.get("insights") or []
            if flagged and not ins:
                errs.append(f"{n}/{k}: flagged area needs at least one insight")
            if ar.get("status") == "low" and len(ins) != 1:
                errs.append(f"{n}/{k}: low area needs exactly one insight explaining why it looks healthy (got {len(ins)})")
            for x in ins:
                if not x.get("headline") or not x.get("explanation"):
                    errs.append(f"{n}/{k}: insight needs a headline and an explanation")
                if flagged and not x.get("evidence"):
                    errs.append(f"{n}/{k}: insight '{x.get('headline')}' needs at least one evidence event")
                for e in x.get("evidence") or []:
                    for f in ("date", "title", "narrative"):
                        if not e.get(f):
                            errs.append(f"{n}/{k}: evidence event missing {f}")
                    if e.get("kind") not in EV_KINDS:
                        errs.append(f"{n}/{k}: evidence kind {e.get('kind')!r} invalid")
                    if e.get("source") not in EV_SOURCES:
                        errs.append(f"{n}/{k}: evidence source {e.get('source')!r} invalid")
                    q = e.get("quote")
                    if q is not None and not (isinstance(q, dict) and q.get("text")):
                        errs.append(f"{n}/{k}: quote needs text")

        for ar in areas:
            if "clientStated" in ar and (not isinstance(ar["clientStated"], bool) or (ar["clientStated"] and ar.get("status") != "critical")):
                errs.append(f"{n}/{ar.get('key')}: clientStated is true/false and only true on a critical area")
            elif ar.get("clientStated") is True:
                evs = [e for x in ar.get("insights") or [] for e in x.get("evidence") or []]
                if not any(e.get("source") == "activity" and e.get("kind") in ("email", "meeting", "call") for e in evs):
                    errs.append(f"{n}/{ar.get('key')}: clientStated needs the client's statement as evidence from an email, meeting or call "
                                f"(source activity); news, filings and SalesAI don't count (framework.md §5)")
        if all(status.get(k) in SEVERITY_RANK for k in AREAS) and lvl in SEVERITY_RANK:
            exp = expected_level(areas)
            if exp != lvl:
                errs.append(f"{n}: level {lvl} doesn't follow from its areas; the corroboration rules give {exp} (framework.md §5)")

        if not (a.get("primaryDriver") or {}).get("summary"):
            errs.append(f"{n}: primaryDriver needs a summary (the one-line why shown in the table)")
        pd_ = a.get("primaryDriver") or {}
        if pd_.get("area") not in AREAS or not pd_.get("label") or not isinstance(pd_.get("tracked"), bool):
            errs.append(f"{n}: primaryDriver needs a valid area, label and tracked")
        elif status.get(pd_["area"]) not in ("critical", "high"):
            errs.append(f"{n}: primary driver area {pd_['area']} must be rated critical or high")
        sec = a.get("secondaryDrivers") or []
        if len(sec) > 2:
            errs.append(f"{n}: at most 2 secondary drivers")
        for s in sec:
            if s.get("area") not in AREAS or not s.get("label") or not isinstance(s.get("tracked"), bool):
                errs.append(f"{n}: secondary driver needs a valid area, label and tracked")
            elif status.get(s["area"]) not in ("critical", "high", "medium"):
                errs.append(f"{n}: secondary driver area {s['area']} must be rated critical, high or medium")

        acts = a.get("actions") or []
        if not 1 <= len(acts) <= 3:
            errs.append(f"{n}: needs 1 to 3 actions (one primary plus up to two supporting)")
        if sum(1 for x in acts if x.get("primary") is True) != 1:
            errs.append(f"{n}: exactly one action must be primary")
        elif acts and not acts[0].get("primary"):
            errs.append(f"{n}: the primary action must be listed first")
        for x in acts:
            if x.get("move") not in move_keys | {"other"}:
                errs.append(f"{n}: move {x.get('move')!r} not in settings.json moves; use 'other' when none of them fits")
            for k in ("title", "who", "why", "objective"):
                if not x.get(k):
                    errs.append(f"{n}: action missing {k}")
            if not x.get("steps"):
                errs.append(f"{n}: action {x.get('move')} needs at least one step")
            if not is_date(x.get("by")):
                errs.append(f"{n}: action.by must be YYYY-MM-DD")

        ra = a.get("recentActivity") or {}
        if ra.get("mode") not in RECENT_MODES:
            errs.append(f"{n}: recentActivity.mode must be last7 or mostRecent")
        for p in a.get("people") or []:
            if not p.get("name") or p.get("status") not in PEOPLE_STATUS:
                errs.append(f"{n}: person needs name and a valid status")
            if re.search(r"@|\+?\d[\d\s().-]{7,}", (p.get("name") or "") + (p.get("title") or "")):
                errs.append(f"{n}: people entries must not contain emails or phone numbers")
        b = a.get("crmView") or {}
        if (b.get("sentiment") or {}).get("value") not in SENTIMENT:
            errs.append(f"{n}: crmView.sentiment.value must be green, amber, red or null")
        if b.get("source") not in FIELD_SOURCES:
            errs.append(f"{n}: crmView.source invalid")
        fc = b.get("forecast")
        if not isinstance(fc, dict):
            errs.append(f"{n}: crmView.forecast must be an object with a value (null when not set)")
        elif fc.get("value") is not None and fc["value"] not in scale:
            errs.append(f"{n}: forecast {fc['value']!r} is not in meta.crmForecast.values")
        if not b.get("comparison"):
            errs.append(f"{n}: crmView.comparison missing (one or two sentences on how Backstory's read compares with the CRM fields)")
        for o in b.get("opportunities") or []:
            if not o.get("name"):
                errs.append(f"{n}: each crmView.opportunities entry needs a name")
            if o.get("forecast") is not None and o["forecast"] not in scale:
                errs.append(f"{n}: opportunity forecast {o['forecast']!r} is not in meta.crmForecast.values")

    return errs


def warnings(d):
    w = []
    def chk(label, text, key):
        if text and len(text) > LIMITS[key]:
            w.append(f"{label}: {key} is {len(text)} characters (aim for under {LIMITS[key]})")
    for a in d.get("accounts", []):
        n = a.get("name", "?")
        chk(n, (a.get("primaryDriver") or {}).get("summary"), "driverSummary")
        chk(n, a.get("assessment"), "assessment")
        chk(n, (a.get("crmView") or {}).get("comparison"), "comparison")
        for ar in a.get("areas") or []:
            k = f"{n}/{ar.get('key')}"
            chk(k, ar.get("finding"), "finding")
            ins = ar.get("insights") or []
            if len(ins) > MAX_INSIGHTS:
                w.append(f"{k}: {len(ins)} insights (aim for {MAX_INSIGHTS} or fewer)")
            for x in ins:
                chk(k, x.get("headline"), "headline")
                chk(k, x.get("explanation"), "explanation")
                if len(x.get("evidence") or []) > MAX_EVIDENCE:
                    w.append(f"{k}: an insight has {len(x['evidence'])} evidence events (aim for {MAX_EVIDENCE} or fewer)")
                for e in x.get("evidence") or []:
                    chk(k, e.get("narrative"), "narrative")
        for x in a.get("actions") or []:
            k = f"{n}/action"
            for f in ("title", "objective", "why"):
                chk(k, x.get(f), f)
            if len(x.get("steps") or []) > MAX_STEPS:
                w.append(f"{k}: {len(x['steps'])} steps (aim for {MAX_STEPS} or fewer)")
            for st in x.get("steps") or []:
                chk(k, st, "step")
            for t in x.get("talkingPoints") or []:
                chk(k, t, "talkingPoint")
    return w


def template_sha():
    with open(TEMPLATE, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def build(data_path, out_path, quiet=False):
    """Validate and build. Returns (errors, warnings); writes out_path only when there are no errors."""
    with open(TEMPLATE_HASH, encoding="utf-8") as f:
        expected = f.read().strip()
    if template_sha() != expected:
        return (["assets/brief-template.html differs from the approved template. Restore the shipped file; "
                 "never edit the template during a run (see references/publishing.md)."], [])
    with open(data_path, encoding="utf-8") as f:
        data = json.load(f)
    with open(SETTINGS, encoding="utf-8") as f:
        settings = json.load(f)
    errs = validate(data, settings)
    if errs:
        return errs, []
    warns = warnings(data)
    cap = settings.get("brief", {}).get("warnShownPerRegion", 30)
    per = {}
    for a in data["accounts"]:
        per[a.get("region")] = per.get(a.get("region"), 0) + 1
    for r, n in per.items():
        if n > cap:
            warns.append(f"{r or 'All regions'}: {n} Critical and High accounts listed; above {cap} the table gets hard to skim. Check the ratings are calibrated")
    warns += [f"Calibration: {w}" for w in calibration(data["coverage"], settings)]
    warns += leader_load(data["accounts"], settings)
    data["_moveLabels"] = {mv["key"]: mv["label"] for mv in settings.get("moves", [])}
    data["_churnDrivers"] = [d.get("label") for d in settings.get("churnDrivers", []) if isinstance(d, dict) and d.get("label")]
    data["_sentimentStaleDays"] = settings.get("thresholds", {}).get("sentimentStaleDays", 90)
    scale = forecast_scale(data["meta"])
    for a in data["accounts"]:
        a.setdefault("crmView", {})["_flagged"] = forecast_flagged(a, scale)
    try:
        with open(PLUGIN_JSON, encoding="utf-8") as f:
            data["_version"] = json.load(f).get("version")
    except OSError:
        data["_version"] = None
    with open(TEMPLATE, encoding="utf-8") as f:
        tpl = f.read()
    if tpl.count(PLACEHOLDER) != 1:
        return ["template placeholder missing or duplicated"], warns
    js = json.dumps(data, ensure_ascii=False).replace("</", "<\\/").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(tpl.replace(PLACEHOLDER, js))
    return [], warns


def main():
    if sys.argv[1:] == ["--accept-template"]:
        with open(TEMPLATE_HASH, "w", encoding="utf-8") as f:
            f.write(template_sha() + "\n")
        print("recorded the current template as approved")
        return
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    errs, warns = build(sys.argv[1], sys.argv[2])
    if errs:
        print("Data does not match the schema:" if not errs[0].startswith("assets/") else "Template check failed:")
        for e in errs:
            print(" -", e)
        sys.exit(1)
    if warns:
        print("Warnings (built anyway; consider tightening):")
        for w in warns:
            print(" -", w)
    with open(sys.argv[1], encoding="utf-8") as f:
        d = json.load(f)
    print(f"built {sys.argv[2]}: {len(d['accounts'])} accounts shown of {d['coverage']['reviewed']} reviewed")


if __name__ == "__main__":
    main()
