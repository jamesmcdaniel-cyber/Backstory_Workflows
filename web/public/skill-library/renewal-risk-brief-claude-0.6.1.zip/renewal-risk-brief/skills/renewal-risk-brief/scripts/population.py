#!/usr/bin/env python3
"""Build the renewal population from the opportunity records Claude fetched, deterministically.

Usage: population.py <records.json> <field-map.json> --as-of YYYY-MM-DD --out population.json [--previous <brief.html|data.json>]
                     [--settings <settings.json>]

Claude fetches broadly (data-collection.md §1) and saves every opportunity record it got, as returned, in one JSON list
(records.json). It writes field-map.json: where each field lives in those records (a dotted path) and which values mean
what (data-schema.md, "field-map.json"). This script does everything countable:

  - decides which opportunities are renewals, checking the type against the other signals (data-collection.md §1a);
  - applies the scope: open renewals dated from `scope.overdueDays` before today through `scope.windowEnd`
    (or `scope.windowDays` ahead), and, only where those fields are configured, the tiers, customer statuses and
    account types in scope; optional fields that aren't mapped are skipped;
  - uses each key field's fallback when a field isn't mapped or is empty, and records it;
  - groups renewals by account (summing renewals only, never upsells), works out notice and readiness dates;
  - leaves out renewals below `population.minRenewalValue` (the renewal value the brief shows); a renewal with no
    value is kept and listed as "value unknown", never dropped;
  - reviews at most `population.maxReviewed` renewals: the largest by value, ties broken by the sooner renewal date.
    The rest go in population.json as "not reviewed this run" (`notReviewed`), with their count and total value;
  - checks the in-scope count (after the floor, before the cap) against `population.expectedCount`, and against last
    week's brief when --previous is given.

--settings reads a copy of settings.json instead of the skill's own: a test run's one-run overrides, and the tests.

Writes population.json and prints a short report. Exit codes: 0 ok; 3 no renewal can be identified (nothing to analyse);
4 the count moved by more than settings `population.maxCountChange` against last week (on a scheduled run: publish nothing);
6 the in-scope count is outside settings `population.expectedCount` (on a scheduled run: publish nothing). Exit 3 also
when records came back but none was kept as an in-scope renewal. When 4 and 6 both apply, the exit is 4; both are reported.
"""
import datetime
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SETTINGS = os.path.join(HERE, "..", "settings.json")
DATE = re.compile(r"^\d{4}-\d{2}-\d{2}")


def get(rec, path):
    """Read a dotted path ('Account.Name') from a record; None when the path is unset or missing."""
    if not path or rec is None:
        return None
    cur = rec
    for part in path.split("."):
        if isinstance(cur, dict):
            cur = cur.get(part)
        else:
            return None
    if isinstance(cur, str):
        cur = cur.strip()
        if cur == "":
            return None
    return cur


# Backstory's record tools return display dates ("Nov 28, 2026"), not ISO dates.
DISPLAY_DATE_FORMATS = ("%b %d, %Y", "%B %d, %Y", "%b %d %Y", "%d %b %Y", "%m/%d/%Y")


def as_date(v):
    if not isinstance(v, str):
        return None
    s = v.strip()
    if DATE.match(s):
        try:
            return datetime.date.fromisoformat(s[:10])
        except ValueError:
            return None
    for fmt in DISPLAY_DATE_FORMATS:
        try:
            return datetime.datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


def as_num(v):
    if isinstance(v, bool) or v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    try:
        return float(str(v).replace(",", "").replace("$", ""))
    except ValueError:
        return None


def norm(v):
    return str(v).strip().lower() if v is not None else None


def truthy(v):
    if isinstance(v, bool):
        return v
    if isinstance(v, (list, dict)):
        return len(v) > 0
    if isinstance(v, (int, float)):
        return v != 0
    if isinstance(v, str):
        return v.strip().lower() not in ("", "false", "no", "0", "none", "null")
    return v is not None


def money(v):
    a = abs(v)
    if a >= 1e6:
        return f"${v / 1e6:.1f}M"
    if a >= 1e3:
        return f"${v / 1e3:.0f}K"
    return f"${v:,.0f}"


def prior_in_scope(cov):
    """Last week's in-scope count: coverage.inScope (before the cap), else coverage.reviewed (briefs without a cap)."""
    n = cov.get("inScope")
    return n if isinstance(n, int) else cov["reviewed"]


def previous_count(path):
    """Last week's in-scope count, from its data.json or from the data embedded in last week's brief.html."""
    with open(path, encoding="utf-8") as f:
        txt = f.read()
    try:
        return prior_in_scope(json.loads(txt)["coverage"])
    except (ValueError, KeyError, TypeError, AttributeError):
        pass
    i = txt.find('"coverage"')
    if i < 0:
        return None
    start = txt.rfind("{", 0, i)
    while start >= 0:
        try:
            obj, _ = json.JSONDecoder().raw_decode(txt[start:].replace("<\\/", "</"))
            return prior_in_scope(obj["coverage"])
        except (ValueError, KeyError, TypeError, AttributeError):
            start = txt.rfind("{", 0, start)
    return None


def review_limits(pop):
    """population.minRenewalValue, maxReviewed and expectedCount, checked. Each is None when not set."""
    floor, cap, expected = pop.get("minRenewalValue"), pop.get("maxReviewed"), pop.get("expectedCount")
    errs = []
    if floor is not None and (isinstance(floor, bool) or not isinstance(floor, (int, float)) or floor < 0):
        errs.append("population.minRenewalValue must be a number of 0 or more, or null")
    if cap is not None and (isinstance(cap, bool) or not isinstance(cap, int) or cap < 1):
        errs.append("population.maxReviewed must be a whole number of 1 or more, or null")
    if expected is not None and not (isinstance(expected, list) and len(expected) == 2
                                     and all(isinstance(x, int) and not isinstance(x, bool) and x >= 0 for x in expected)
                                     and expected[0] <= expected[1]):
        errs.append("population.expectedCount must be [min, max] (whole numbers, min <= max), or null")
    if errs:
        print("Settings problem:\n" + "\n".join(f"  - {e}" for e in errs))
        sys.exit(1)
    return floor, cap, expected


def main():
    args = sys.argv[1:]
    if len(args) < 2 or "--as-of" not in args or "--out" not in args:
        print(__doc__)
        sys.exit(1)
    rec_path, map_path = args[0], args[1]
    as_of = datetime.date.fromisoformat(args[args.index("--as-of") + 1])
    out = args[args.index("--out") + 1]
    prev = args[args.index("--previous") + 1] if "--previous" in args else None
    settings_path = args[args.index("--settings") + 1] if "--settings" in args else SETTINGS

    with open(settings_path, encoding="utf-8") as f:
        settings = json.load(f)
    with open(rec_path, encoding="utf-8") as f:
        records = json.load(f)
    if isinstance(records, dict):
        records = records.get("records") or records.get("data") or []
    with open(map_path, encoding="utf-8") as f:
        fm = json.load(f)

    sc, th, pop = settings.get("scope", {}), settings.get("thresholds", {}), settings.get("population", {})
    opp, acc, val = fm.get("opportunity", {}), fm.get("account", {}), fm.get("values", {})
    if sc.get("windowEnd"):
        window_end = datetime.date.fromisoformat(sc["windowEnd"])
    else:
        window_end = as_of + datetime.timedelta(days=int(sc.get("windowDays", 120)))
    overdue_days = int(sc.get("overdueDays", 90))
    window_start = as_of - datetime.timedelta(days=overdue_days)
    floor, cap, expected = review_limits(pop)
    notice_days = int(th.get("clientNoticeDays", 60))
    ready_days = int(th.get("readinessStartDays", 120))
    gap = pop.get("autoCreatedGapDays")
    gap_lo, gap_hi = gap if isinstance(gap, list) and len(gap) == 2 else (None, None)
    terr_map = {norm(k): v for k, v in {**(pop.get("territoryRegionMap") or {}), **(val.get("territoryRegion") or {})}.items()}

    renewal_vals = {norm(v) for v in val.get("renewalType") or []}
    tier_vals = {norm(v) for v in val.get("tiers") or []}
    status_vals = {norm(v) for v in val.get("clientStatus") or []}
    closed_stages = {norm(v) for v in val.get("closedStages") or []}
    excl_vals = {norm(v) for v in val.get("excludeTypes") or []}
    scale = val.get("forecastScale") or []
    rank = {norm(s.get("value")): i for i, s in enumerate(scale)}

    def present(path):
        return bool(path) and any(get(r, path) is not None for r in records)

    has = {k: present(p) for k, p in list(opp.items()) + [("acct." + k, p) for k, p in acc.items()]}
    fallbacks, notes, dropped, disagreements, multi = [], [], {}, [], []

    def drop(reason):
        dropped[reason] = dropped.get(reason, 0) + 1

    def missing(key, path_key):
        """A field the field map points at but no record carries: a fallback. A field left null is simply skipped (a note)."""
        return bool(path_key) and not has.get(key)

    gap_txt = f"created {gap_lo}-{gap_hi} days ahead, " if gap_lo is not None else ""
    if not has.get("type") or not renewal_vals:
        fallbacks.append(f"Opportunity type not available: renewals identified where the other signals agree ({gap_txt}renewing products, 'Renewal' in the name)")
    if missing("renewalDate", opp.get("renewalDate")):
        fallbacks.append("Renewal date field returned no values: the close date is used as the renewal date")
    elif not opp.get("renewalDate"):
        notes.append("Renewal date: the close date (no renewal date field set)")
    if not has.get("amount"):
        fallbacks.append("Amount not available: the annualized amount, else the account's annual contract value, is used as the renewal value")
    use_tiers = bool(has.get("acct.tier") and tier_vals)
    if tier_vals and not has.get("acct.tier"):
        fallbacks.append("Tier not available: no tier filter")
    elif not use_tiers:
        notes.append("No tier filter")
    region_from_territory = not has.get("acct.region") and has.get("acct.territory") and bool(terr_map)
    if region_from_territory:
        (fallbacks if acc.get("region") else notes).append("Region: each account's region is worked out from its territory (population.territoryRegionMap)")
    elif not has.get("acct.region"):
        (fallbacks if acc.get("region") else notes).append("Region not available" + (" and no territory-to-region map" if has.get("acct.territory") else "") + ": no region filter; every account shows in one list")
    if missing("noticeDate", opp.get("noticeDate")):
        fallbacks.append(f"Notice date field returned no values: the notice date is the renewal date minus {notice_days} days")
    elif not opp.get("noticeDate"):
        notes.append(f"Notice date: the renewal date minus {notice_days} days (no notice date field set)")
    if status_vals and not has.get("acct.status"):
        fallbacks.append("Account status not available: every account with an open renewal is kept")
    if excl_vals and not has.get("acct.type"):
        fallbacks.append("Account type not available: renewals worth $0 and accounts named internal or test are left out")
    elif not excl_vals:
        notes.append("No account types excluded: renewals worth $0 and accounts named internal or test are left out")
    if not has.get("isClosed") and has.get("stage"):
        notes.append("Closed opportunities identified by stage" + (" (values.closedStages)" if closed_stages else " (stages starting 'Closed')"))
    measurable = [s for s in ("createdDate", "renewingProducts", "name") if has.get(s) and (s != "createdDate" or gap_lo is not None)]
    if not (has.get("type") and renewal_vals) and not measurable:
        print("No renewal can be identified: neither the opportunity type nor any other signal is available.")
        sys.exit(3)

    accounts = {}
    for r in records:
        if has.get("isClosed"):
            closed = truthy(get(r, opp.get("isClosed")))
        else:
            stage = norm(get(r, opp.get("stage")))
            closed = stage is not None and (stage in closed_stages if closed_stages else stage.startswith("closed"))
        if closed:
            drop("closed")
            continue
        name = get(r, opp.get("name")) or ""
        rdate, close = as_date(get(r, opp.get("renewalDate"))), as_date(get(r, opp.get("closeDate")))
        date, date_src = (rdate, "renewal date") if rdate else (close, "close")
        created = as_date(get(r, opp.get("createdDate")))
        signals = {
            "createdAhead": (created is not None and date is not None and gap_lo <= (date - created).days <= gap_hi) if has.get("createdDate") and gap_lo is not None else None,
            "renewingProducts": truthy(get(r, opp.get("renewingProducts"))) if has.get("renewingProducts") else None,
            "nameSaysRenewal": ("renew" in name.lower()) if has.get("name") else None,
        }
        hits = sum(1 for v in signals.values() if v)
        known = sum(1 for v in signals.values() if v is not None)
        if has.get("type") and renewal_vals:
            is_renewal = norm(get(r, opp.get("type"))) in renewal_vals
            if (is_renewal and known >= 2 and hits == 0) or (not is_renewal and hits >= 2):
                disagreements.append({"opportunity": name, "id": get(r, opp.get("id")), "type": get(r, opp.get("type")),
                                      "signals": {k: v for k, v in signals.items() if v is not None}})
        else:
            is_renewal = hits >= min(2, known)
        if not is_renewal:
            drop("not a renewal (new business or upsell)")
            continue
        if date is None:
            drop("no renewal date")
            continue
        if date > window_end:
            drop("renews after the window")
            continue
        if date < window_start:
            drop(f"renewal date more than {overdue_days} days past")
            continue

        if truthy(get(r, acc.get("testAccount"))):
            drop("test account")
            continue
        a_type = norm(get(r, acc.get("type")))
        a_name = get(r, acc.get("name")) or get(r, opp.get("accountName")) or ""
        amount = as_num(get(r, opp.get("amount")))
        annualized = as_num(get(r, opp.get("annualizedAmount")))
        acv = as_num(get(r, acc.get("annualContractValue")))
        value = next((v for v in (amount, annualized, acv) if v is not None), None)
        value_src = "amount" if amount is not None else ("annualized amount" if annualized is not None else ("annual contract value" if acv is not None else None))
        # No amount, annualized amount or annual contract value: kept, and listed as "value unknown" (never dropped silently).
        if excl_vals and a_type in excl_vals:
            drop("excluded account type")
            continue
        if not (excl_vals and has.get("acct.type")):
            if value == 0 or re.search(r"\b(internal|test)\b", a_name, re.I):
                drop("internal, test or $0 account (fallback)")
                continue
        tier = get(r, acc.get("tier"))
        if tier is not None and use_tiers and norm(tier) not in tier_vals:
            drop("tier out of scope")
            continue
        status = get(r, acc.get("status"))
        if status is not None and status_vals and norm(status) not in status_vals:
            drop("not a current customer")
            continue

        aid = str(get(r, opp.get("accountId")) or a_name)
        territory = get(r, acc.get("territory"))
        region = get(r, acc.get("region"))
        if region is None and territory is not None:
            region = terr_map.get(norm(territory))
        a = accounts.setdefault(aid, {
            "id": aid, "name": a_name, "region": region, "territory": territory, "tier": tier,
            "owner": get(r, acc.get("owner")) or get(r, opp.get("owner")),
            "clientServicesOwner": get(r, acc.get("clientServices")), "rollup": get(r, acc.get("rollup")),
            "opportunities": [],
            "crm": {
                "sentiment": {"value": norm(get(r, acc.get("sentiment"))), "date": (get(r, acc.get("sentimentDate")) or None) and str(get(r, acc.get("sentimentDate")))[:10], "note": get(r, acc.get("sentimentNote"))},
                "engagementScore": {"value": as_num(get(r, acc.get("engagementScore"))), "asOf": get(r, acc.get("engagementScoreAsOf")),
                                    "previous": as_num(get(r, acc.get("engagementScorePrevious"))), "previousAsOf": get(r, acc.get("engagementScorePreviousAsOf"))},
            },
        })
        a["opportunities"].append({
            "id": get(r, opp.get("id")), "name": name, "date": date.isoformat(), "dateSource": date_src, "value": value,
            "valueSource": value_src,
            "noticeDate": (lambda d: d.isoformat() if d else None)(as_date(get(r, opp.get("noticeDate")))),
            "managerNote": get(r, opp.get("managerNote")),
            "managerNoteDate": (lambda d: d.isoformat() if d else None)(as_date(get(r, opp.get("managerNoteDate")))),
            "forecast": get(r, opp.get("forecast")), "atRiskReason": get(r, opp.get("atRiskReason")), "nextStep": get(r, opp.get("nextStep")),
            "owner": get(r, opp.get("owner")),
        })

    out_accts = []
    for a in accounts.values():
        ops = sorted(a["opportunities"], key=lambda o: o["date"])
        if len(ops) > 1:
            multi.append({"account": a["name"], "opportunities": [o["name"] for o in ops]})
        d0 = datetime.date.fromisoformat(ops[0]["date"])
        fcs = [o["forecast"] for o in ops if o["forecast"] is not None]
        fc = max(fcs, key=lambda v: rank.get(norm(v), -1)) if fcs else None
        sc_ = a["crm"]["engagementScore"]
        for k in ("value", "previous"):
            if sc_[k] is not None and float(sc_[k]).is_integer():
                sc_[k] = int(sc_[k])
        noted = [o for o in ops if o.get("managerNote")]
        if noted:
            last = max(noted, key=lambda o: o.get("managerNoteDate") or "")
            a["crm"]["managerNote"] = {"text": last["managerNote"], "date": last.get("managerNoteDate")}
        else:
            a["crm"]["managerNote"] = None
        known = [o["value"] for o in ops if o["value"] is not None]
        a["renewal"] = {
            "date": d0.isoformat(),
            "noticeDate": ops[0].get("noticeDate") or (d0 - datetime.timedelta(days=notice_days)).isoformat(),
            "noticeSource": "notice date field" if ops[0].get("noticeDate") else f"renewal date minus {notice_days} days",
            "value": sum(known) if known else None,
            "valueUnknown": len(known) < len(ops),
            "overdue": d0 < as_of,
            "inReadiness": (d0 - datetime.timedelta(days=ready_days)) <= as_of,
        }
        a["crm"]["forecast"] = fc
        a["opportunities"] = ops
        if all(v is None for v in a["crm"]["sentiment"].values()):
            a["crm"]["sentiment"] = {"value": None, "date": None, "note": None}
        out_accts.append(a)

    # After every other scope rule: the value floor, then the cap (data-collection.md §1, step 6).
    below = [a for a in out_accts if floor is not None and not a["renewal"]["valueUnknown"] and a["renewal"]["value"] < floor]
    below_ids = {a["id"] for a in below}
    in_scope = [a for a in out_accts if a["id"] not in below_ids]
    # Largest first, ties by the sooner renewal date; a renewal with no value at all comes after every valued one.
    in_scope.sort(key=lambda a: (a["renewal"]["value"] is None, -(a["renewal"]["value"] or 0), a["renewal"]["date"], a["id"]))
    out_accts = in_scope[:cap] if cap is not None else in_scope
    over = in_scope[len(out_accts):]
    reviewed_ids = {a["id"] for a in out_accts}
    unknown = [{"id": a["id"], "account": a["name"], "value": a["renewal"]["value"], "reviewed": a["id"] in reviewed_ids}
               for a in in_scope if a["renewal"]["valueUnknown"]]
    not_reviewed = {
        "count": len(over), "value": sum(a["renewal"]["value"] or 0 for a in over),
        "valueUnknown": sum(1 for a in over if a["renewal"]["valueUnknown"]),
        "reason": "not reviewed this run (population.maxReviewed)",
        "renewals": [{"id": a["id"], "name": a["name"], "region": a["region"], "territory": a["territory"],
                      "date": a["renewal"]["date"], "value": a["renewal"]["value"], "valueUnknown": a["renewal"]["valueUnknown"],
                      "overdue": a["renewal"]["overdue"]} for a in over],
    }
    cap_line = (f"Reviewed the {len(out_accts)} largest of {len(in_scope)} in scope; {len(over)} (total {money(not_reviewed['value'])}"
                + (f", {not_reviewed['valueUnknown']} of them value unknown" if not_reviewed["valueUnknown"] else "")
                + ") not reviewed this run (population.maxReviewed)") if over else None

    region_order = sc.get("regionOrder") or []
    found = []
    for a in out_accts:
        if a["region"] is not None and a["region"] not in found:
            found.append(a["region"])
    regions = [r for r in region_order if r in found] + [r for r in found if r not in region_order]
    if not has.get("acct.region") and not region_from_territory:
        regions = []
        for a in out_accts:
            a["region"] = None
    unmapped = sorted({str(a["territory"]) for a in out_accts if a["region"] is None and a.get("territory") is not None})
    if regions and any(a["region"] is None for a in out_accts):
        for a in out_accts:
            if a["region"] is None:
                a["region"] = "No region"
        regions.append("No region")

    report = {
        "fetched": len(records), "kept": sum(len(a["opportunities"]) for a in out_accts), "accounts": len(out_accts),
        "inScope": len(in_scope), "belowFloor": len(below), "overCap": len(over), "reviewed": len(out_accts),
        "overdue": sum(1 for a in out_accts if a["renewal"]["overdue"]),
        "floor": {"minRenewalValue": floor, "count": len(below), "value": sum(a["renewal"]["value"] for a in below)},
        "cap": {"maxReviewed": cap, "line": cap_line},
        "valueUnknown": unknown,
        "dropped": dropped, "fallbacks": fallbacks, "notes": notes, "typeDisagreements": disagreements, "severalRenewals": multi,
        "noticeFromField": sum(1 for a in out_accts if a["renewal"]["noticeSource"] == "notice date field"),
        "territoriesWithoutRegion": unmapped if regions else [],
    }
    code = 0
    if records and not in_scope:
        # Records came back but none survived as an in-scope renewal: never let the run go on to an empty brief.
        code = 3
    if expected is not None and code != 3:
        ok = expected[0] <= len(in_scope) <= expected[1]
        report["rangeCheck"] = {"expected": expected, "inScope": len(in_scope), "ok": ok}
        if not ok:
            code = 6
    if prev:
        p = previous_count(prev)
        report["countCheck"] = {"previous": p, "current": len(in_scope)}
        lim = float(pop.get("maxCountChange", 1 / 3))
        if p:
            ok = abs(len(in_scope) - p) / p <= lim
            report["countCheck"]["ok"] = ok
            if not ok and code != 3:
                code = 4

    result = {
        "asOf": as_of.isoformat(),
        "scope": {"regions": regions, "windowStart": window_start.isoformat(), "windowEnd": window_end.isoformat(),
                  "overdueDays": overdue_days, "tiers": sorted({a["tier"] for a in out_accts if a["tier"]}),
                  "excludeAccountTypes": val.get("excludeTypes") or []},
        "crmForecast": {"field": opp.get("forecastLabel") or ("Forecast Category" if has.get("forecast") else None),
                        "values": scale if has.get("forecast") else []},
        "sources": {"renewalList": "backstory", "crmFields": fm.get("crmFieldsSource", "backstory_fields")},
        "accounts": out_accts,
        "notReviewed": not_reviewed,
        "report": report,
    }
    with open(out, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(f"{len(records)} records fetched; {len(in_scope)} renewal accounts in scope; {len(out_accts)} reviewed "
          f"({report['kept']} renewal opportunities, {report['overdue']} overdue)")
    for k, n in sorted(dropped.items(), key=lambda x: -x[1]):
        print(f"  dropped {n}: {k}")
    if floor is not None:
        print(f"  value floor {money(floor)} (population.minRenewalValue): {len(below)} below it left out"
              + (f" (total {money(report['floor']['value'])})" if below else ""))
    if unknown:
        print(f"  {len(unknown)} renewals with value unknown, kept and listed (report.valueUnknown): "
              + ", ".join(u["account"] or u["id"] for u in unknown[:10]) + (" ..." if len(unknown) > 10 else ""))
    if cap_line:
        print(f"  {cap_line}")
    elif cap is not None:
        print(f"  all {len(in_scope)} in scope reviewed (population.maxReviewed {cap})")
    for fb in fallbacks:
        print(f"  FALLBACK: {fb}")
    for nt in notes:
        print(f"  note: {nt}")
    if disagreements:
        print(f"  {len(disagreements)} opportunities where the type and the other renewal signals disagree (type kept; listed in population.json)")
    if multi:
        print(f"  {len(multi)} accounts with more than one renewal in the window (summed; check none is an upsell)")
    print(f"  notice date from the notice date field on {report['noticeFromField']} of {len(out_accts)} accounts")
    if report["territoriesWithoutRegion"]:
        print(f"  territories with no region (accounts left without a region): {', '.join(report['territoriesWithoutRegion'])}")
    if "countCheck" in report:
        cc = report["countCheck"]
        print(f"  count check: {cc['current']} in scope vs {cc['previous']} last week" + ("" if cc.get("ok", True) else " -- CHANGED BY MORE THAN THE LIMIT"))
    if "rangeCheck" in report:
        rc = report["rangeCheck"]
        print(f"  expected count: {rc['inScope']} in scope, expected {rc['expected'][0]}-{rc['expected'][1]} (population.expectedCount)"
              + ("" if rc["ok"] else " -- OUTSIDE THE EXPECTED RANGE"))
    if code == 4:
        print("Exit 4: the in-scope count moved by more than population.maxCountChange against last week. Scheduled run: publish nothing. Interactive run: show both counts and ask whether to go on.")
    if code == 6:
        print("Exit 6: the in-scope count is outside population.expectedCount. Scheduled run: publish nothing. Interactive run: show the count, the expected range and the drop reasons, and ask whether to go on.")
    if code == 3:
        print("No renewal in scope: records were fetched but none was kept. Check the drop reasons and the value floor above (an unreadable date format shows as 'no renewal date') before analysing or publishing.")
    sys.exit(code)


if __name__ == "__main__":
    main()
